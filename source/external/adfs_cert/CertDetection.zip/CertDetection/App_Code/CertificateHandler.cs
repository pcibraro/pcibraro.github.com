﻿using System;
using System.Web;

public class CertificateHandler : IHttpHandler
{

    public void ProcessRequest(HttpContext context)
    {
        context.Response.ContentType = "application/javascript";

        if (context.Request.ClientCertificate.IsPresent)
        {
            context.Response.Write("if(typeof(certificateCallback) == 'function') { (certificateCallback) (true); }");
        }
        else
        {
            context.Response.Write("if(typeof(certificateCallback) == 'function') { (certificateCallback) (false); }");
        }
        
    }

    public bool IsReusable
    {
        get
        {
            return false;
        }
    }

}