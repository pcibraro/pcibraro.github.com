﻿window.certificateCallback = function (cert) {
    var url;
    if (cert) {
        url = "auth/sslclient/" + window.location.search;
        document.location.href = url;
    }
};