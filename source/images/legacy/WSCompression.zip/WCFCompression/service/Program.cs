using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;

namespace Microsoft.ServiceModel.Samples
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ServiceHost host = new ServiceHost(typeof(CalculatorService), new Uri[] { new Uri("http://localhost:8080/servicemodelsamples/calc") });
                              
                host.Open();
                
                Console.WriteLine("Listening....");
                Console.ReadLine();

                host.Close();
                host.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString()); 
            }
        }

    }
}
