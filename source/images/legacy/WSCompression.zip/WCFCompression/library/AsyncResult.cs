//-----------------------------------------------------------------------------
// <copyright file="AsyncResult.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
//-----------------------------------------------------------------------------

using System;
using System.ServiceModel;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
    abstract class AsyncResult : IAsyncResult
    {
        AsyncCallback callback;
        object state;
        bool completedSynchronously;
        bool endCalled;
        Exception exception;
        bool isCompleted;
        ManualResetEvent manualResetEvent;

        protected AsyncResult(AsyncCallback callback, object state)
        {
            this.callback = callback;
            this.state = state;
        }

        public object AsyncState
        {
            get { return state; }
        }

        public WaitHandle AsyncWaitHandle
        {
            get
            {
                if (manualResetEvent != null)
                {
                    return manualResetEvent;
                }

                lock (ThisLock)
                {
                    if (manualResetEvent == null)
                    {
                        manualResetEvent = new ManualResetEvent(isCompleted);
                    }
                }

                return manualResetEvent;
            }
        }

        public bool CompletedSynchronously
        {
            get { return completedSynchronously; }
        }

        public bool IsCompleted
        {
            get { return isCompleted; }
        }

        object ThisLock
        {
            get { return this; }
        }

        protected void Complete(bool completedSynchronously)
        {
            if (isCompleted)
            {
                throw new InvalidOperationException("AsyncResults can only be completed once.");
            }
            ManualResetEvent manualResetEvent = null;
            this.completedSynchronously = completedSynchronously;

            if (completedSynchronously)
            {
                // If we completedSynchronously, then there's no chance that the manualResetEvent was created so
                // we don't need to worry about a race
                this.isCompleted = true;
                if (this.manualResetEvent != null)
                {
                    throw new InvalidOperationException("No ManualResetEvent should be created for a synchronous AsyncResult.");
                }
            }
            else
            {
                lock (ThisLock)
                {
                    this.isCompleted = true;
                    manualResetEvent = this.manualResetEvent;
                }
            }

            try
            {
                if (callback != null)
                {
                    callback(this);
                }
                if (manualResetEvent != null)
                {
                    manualResetEvent.Set();
                }
            }
            catch (Exception unhandledException)
            {
                // The callback raising an exception is equivalent to Main raising an exception w/out a catch.
                // Queue it onto another thread and throw it there to ensure that there's no other handler in 
                // place and the default unhandled exception behavior occurs.

                // Because the stack trace gets lost on a rethrow, we're wrapping it in a generic exception
                // so the stack trace is preserved.
                unhandledException = new Exception("AsyncCallbackException", unhandledException);
                ThreadPool.UnsafeQueueUserWorkItem(new WaitCallback(RaiseUnhandledException), unhandledException);
            }
        }

        protected void Complete(bool completedSynchronously, Exception exception)
        {
            this.exception = exception;
            Complete(completedSynchronously);
        }

        protected static void End(AsyncResult asyncResult)
        {
            if (asyncResult == null)
            {
                throw new ArgumentNullException("asyncResult");
            }

            if (asyncResult.endCalled)
            {
                throw new InvalidOperationException("Async object already ended.");
            }

            asyncResult.endCalled = true;

            if (!asyncResult.isCompleted)
            {
                using (WaitHandle waitHandle = asyncResult.AsyncWaitHandle)
                {
                    waitHandle.WaitOne();
                }
            }

            if (asyncResult.exception != null)
            {
                throw asyncResult.exception;
            }
        }

        void RaiseUnhandledException(object o)
        {
            Exception exception = (Exception)o;
            throw exception;
        }
    }
}
