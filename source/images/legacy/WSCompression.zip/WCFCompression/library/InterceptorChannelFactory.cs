
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;
using System.Diagnostics;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
    class NullMessageInterceptor : IMessageInterceptor
    {
        public void ProcessSend(ref Message message)
        {
        }

        public void ProcessReceive(ref Message message)
        {
        }
    }

    class InterceptorChannelFactory<TChannel> : ChannelFactoryBase<TChannel>
    {
        IMessageInterceptor interceptor;
        IChannelFactory<TChannel> innerChannelFactory;

        public InterceptorChannelFactory(IMessageInterceptor interceptor, IDefaultCommunicationTimeouts timeouts)
            : base(timeouts)
        {
            if (interceptor == null)
            {
                this.interceptor = new NullMessageInterceptor();
            }
            else
            {
                this.interceptor = interceptor;
            }
        }

        internal IChannelFactory<TChannel> InnerChannelFactory
        {
            get { return this.innerChannelFactory; }
            set { this.innerChannelFactory = value; }
        }

        public IMessageInterceptor Interceptor
        {
            get { return interceptor; }
        }

        public override MessageVersion MessageVersion
        {
            get { return this.innerChannelFactory.MessageVersion; }
        }

        public override string Scheme
        {
            get { return this.innerChannelFactory.Scheme; }
        }

        protected override void OnOpen(TimeSpan timeout)
        {
            this.innerChannelFactory.Open(timeout);
        }

        protected override IAsyncResult OnBeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.innerChannelFactory.BeginOpen(timeout, callback, state);
        }

        protected override void OnEndOpen(IAsyncResult result)
        {
            this.innerChannelFactory.EndOpen(result);
        }

        protected override void OnClose(TimeSpan timeout)
        {
            this.innerChannelFactory.Close(timeout);
        }

        protected override IAsyncResult OnBeginClose(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.innerChannelFactory.BeginClose(timeout, callback, state);
        }

        protected override void OnEndClose(IAsyncResult result)
        {
            this.innerChannelFactory.EndClose(result);
        }

        protected override TChannel OnCreateChannel(EndpointAddress remoteAddress, Uri via)
        {
            TChannel innerChannel = this.InnerChannelFactory.CreateChannel(remoteAddress, via);
            if (typeof(TChannel) == typeof(IOutputChannel))
            {
                return (TChannel)(object)new InterceptorOutputChannel(this, this.interceptor, (IOutputChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IRequestChannel))
            {
                return (TChannel)(object)new InterceptorRequestChannel(this, this.interceptor, (IRequestChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IDuplexChannel))
            {
                return (TChannel)(object)new InterceptorDuplexChannel(this, (IDuplexChannel)innerChannel, this.interceptor);
            }
            else if (typeof(TChannel) == typeof(IOutputSessionChannel))
            {
                return (TChannel)(object)new InterceptorOutputSessionChannel(this, this.interceptor, (IOutputSessionChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IRequestSessionChannel))
            {
                return (TChannel)(object)new InterceptorRequestSessionChannel(this, this.interceptor, 
                    (IRequestSessionChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IDuplexSessionChannel))
            {
                return (TChannel)(object)new InterceptorDuplexSessionChannel(this, (IDuplexSessionChannel)innerChannel, this.interceptor);
            }
            throw new ArgumentException("Channel type is not supported.", "TChannel");
        }

        class InterceptorOutputChannel : InterceptorChannelBase<IOutputChannel>, IOutputChannel
        {
            public InterceptorOutputChannel(ChannelFactoryBase factory, IMessageInterceptor interceptor, IOutputChannel innerChannel)
                : base(factory, innerChannel, interceptor)
            {
            }

            public EndpointAddress RemoteAddress
            {
                get { return this.InnerChannel.RemoteAddress; }
            }

            public Uri Via
            {
                get { return this.InnerChannel.Via; }
            }

            public IAsyncResult BeginSend(Message message, AsyncCallback callback, object state)
            {
                ThrowIfDisposedOrNotOpen();
                return new SendAsyncResult<IOutputChannel>(this, message, callback, state);
            }

            public IAsyncResult BeginSend(Message message, TimeSpan timeout, AsyncCallback callback, object state)
            {
                ThrowIfDisposedOrNotOpen();
                return new SendAsyncResult<IOutputChannel>(this, message, timeout, callback, state);
            }

            public void EndSend(IAsyncResult result)
            {
                SendAsyncResult<IOutputChannel>.End(result);
            }

            public void Send(Message message)
            {
                ThrowIfDisposedOrNotOpen();
                Interceptor.ProcessSend(ref message);
                if (message == null)
                {
                    OnDropMessage();
                }
                else
                {
                    this.InnerChannel.Send(message);
                }
            }

            public void Send(Message message, TimeSpan timeout)
            {
                ThrowIfDisposedOrNotOpen();
                Interceptor.ProcessSend(ref message);
                if (message == null)
                {
                    OnDropMessage();
                }
                else
                {
                    this.InnerChannel.Send(message, timeout);
                }
            }
        }

        class InterceptorRequestChannel : InterceptorChannelBase<IRequestChannel>, IRequestChannel
        {
            public InterceptorRequestChannel(ChannelFactoryBase factory, IMessageInterceptor interceptor, IRequestChannel innerChannel)
                : base(factory, innerChannel, interceptor)
            {
            }

            public EndpointAddress RemoteAddress
            {
                get { return this.InnerChannel.RemoteAddress; }
            }

            public Uri Via
            {
                get { return this.InnerChannel.Via; }
            }

            public IAsyncResult BeginRequest(Message message, AsyncCallback callback, object state)
            {
                ThrowIfDisposedOrNotOpen();
                return new RequestAsyncResult(this, message, callback, state);
            }

            public IAsyncResult BeginRequest(Message message, TimeSpan timeout, AsyncCallback callback, object state)
            {
                ThrowIfDisposedOrNotOpen();
                return new RequestAsyncResult(this, message, timeout, callback, state);
            }

            public Message EndRequest(IAsyncResult result)
            {
                return RequestAsyncResult.End(result);
            }

            public Message Request(Message message)
            {
                ThrowIfDisposedOrNotOpen();
                Interceptor.ProcessSend(ref message);
                if (message == null)
                {
                    OnDropMessage();
                    return Message.CreateMessage(MessageVersion.Soap12WSAddressing10, new DroppedMessageFault("Request Message dropped by interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                }
                else
                {
                    Message reply = this.InnerChannel.Request(message);
                    Interceptor.ProcessReceive(ref reply);

                    if (reply == null)
                    {
                        OnDropMessage();
                        return Message.CreateMessage(MessageVersion.Soap12WSAddressing10, new DroppedMessageFault("Reply Message dropped by the interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                    }
                    else
                    {
                        return reply;
                    }
                }
            }

            public Message Request(Message message, TimeSpan timeout)
            {
                ThrowIfDisposedOrNotOpen();
                Interceptor.ProcessSend(ref message);
                if (message == null)
                {
                    OnDropMessage();
                    return Message.CreateMessage(message.Version, new DroppedMessageFault("Request Message dropped by interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                }
                else
                {
                    Message reply = this.InnerChannel.Request(message, timeout);
                    Interceptor.ProcessReceive(ref reply);

                    if (reply == null)
                    {
                        OnDropMessage();
                        return Message.CreateMessage(message.Version, new DroppedMessageFault("Reply Message dropped by the interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                    }
                    else
                    {
                        return reply;
                    }
                }
            }
        }

        class InterceptorOutputSessionChannel : InterceptorOutputChannel, IOutputSessionChannel
        {
            IOutputSessionChannel innerSessionChannel;

            public InterceptorOutputSessionChannel(ChannelFactoryBase factory, IMessageInterceptor interceptor, IOutputSessionChannel innerChannel)
                : base(factory, interceptor, innerChannel)
            {
                this.innerSessionChannel = innerChannel;
            }

            public IOutputSession Session
            {
                get { return innerSessionChannel.Session; }
            }

            internal override void OnDropMessage()
            {
                Fault();
                innerSessionChannel.Abort();
            }
        }

        class InterceptorRequestSessionChannel : InterceptorRequestChannel, IRequestSessionChannel
        {
            IRequestSessionChannel innerSessionChannel;

            public InterceptorRequestSessionChannel(ChannelFactoryBase factory, IMessageInterceptor interceptor, 
                IRequestSessionChannel innerChannel)
                : base(factory, interceptor, innerChannel)
            {
                this.innerSessionChannel = innerChannel;
            }

            public IOutputSession Session
            {
                get { return innerSessionChannel.Session; }
            }

            internal override void OnDropMessage()
            {
                Fault();
                innerSessionChannel.Abort();
            }
        }
    }
}
