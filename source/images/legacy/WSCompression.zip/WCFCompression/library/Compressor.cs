using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace Microsoft.ServiceModel.Samples
{
    internal class Compressor
    {
        private const int BUFFER_LEN = 65536;

        private readonly CompressionMode _mode;
        private readonly CompressionLevel _level;

        public Compressor( CompressionMode mode, CompressionLevel level )
        {
            _mode = mode;
            _level = level;
        }

        private Stream GetOutputStream( Stream targetStream )
        {
            if ( _mode == CompressionMode.GZip )
            {
                return new GZipStream( targetStream, System.IO.Compression.CompressionMode.Compress );
            }
            else if ( _mode == CompressionMode.Deflate )
            {
                return new DeflateStream( targetStream, System.IO.Compression.CompressionMode.Compress );
            }
            else
            {
                throw new ArgumentOutOfRangeException( "_mode" );
            }
        }

        private Stream GetInputStream( Stream sourceStream )
        {
            if ( _mode == CompressionMode.GZip )
            {
                return new GZipStream( sourceStream, System.IO.Compression.CompressionMode.Decompress );
            }
            else if ( _mode == CompressionMode.Deflate )
            {
                return new DeflateStream( sourceStream, System.IO.Compression.CompressionMode.Decompress );
            }
            else
            {
                throw new ArgumentOutOfRangeException( "_mode" );
            }
        }

        public byte[] Compress( byte[] uncompressedData )
        {
            MemoryStream memStream = new MemoryStream( );

            Stream outputStream = GetOutputStream( memStream );
            outputStream.Write( uncompressedData, 0, uncompressedData.Length );
            outputStream.Close( );

            byte[] result = memStream.ToArray( );

            memStream.Dispose( );

            return result;
        }

        public byte[] Decompress( byte[] compressedData )
        {
            MemoryStream memStream = new MemoryStream( compressedData );
            Stream compressedStream = GetInputStream( memStream );

            MemoryStream outputStream = new MemoryStream( );
            byte[] buffer = new Byte[ BUFFER_LEN ];
            while ( true )
            {
                int length = compressedStream.Read( buffer, 0, buffer.Length );
                if ( length < 1 )
                    break;
                outputStream.Write( buffer, 0, length );
            }
            outputStream.Close( );
            
            byte[] result = outputStream.ToArray( );

            outputStream.Dispose( );
            memStream.Dispose( );

            return result;
        }

        public byte[] CompressString( string data )
        {
            return Compress( Encoding.UTF8.GetBytes( data ) );
        }

        public string DecompressString( byte[] data )
        {
            return Encoding.UTF8.GetString( Decompress( data ) );
        }
    }
}