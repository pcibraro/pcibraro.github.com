
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
    class InterceptorChannelBase<TChannel> : ChannelBase
        where TChannel : IChannel
    {
        TChannel innerChannel;
        IMessageInterceptor interceptor;

        protected InterceptorChannelBase(ChannelManagerBase manager, TChannel innerChannel, IMessageInterceptor interceptor)
            : base(manager)
        {
            this.innerChannel = innerChannel;
            this.interceptor = interceptor;
        }

        internal TChannel InnerChannel
        {
            get { return this.innerChannel; }
        }

        internal IMessageInterceptor Interceptor
        {
            get { return this.interceptor; }
        }

        protected override void OnAbort()
        {
            this.innerChannel.Abort();
        }

        protected override IAsyncResult OnBeginClose(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.innerChannel.BeginClose(timeout, callback, state);
        }

        protected override IAsyncResult OnBeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.innerChannel.BeginOpen(timeout, callback, state);
        }

        protected override void OnClose(TimeSpan timeout)
        {
            this.innerChannel.Close(timeout);
        }

        protected override void OnEndClose(IAsyncResult result)
        {
            this.innerChannel.EndClose(result);
        }

        protected override void OnEndOpen(IAsyncResult result)
        {
            this.innerChannel.EndOpen(result);
        }

        protected override void OnOpen(TimeSpan timeout)
        {
            this.innerChannel.Open(timeout);
        }

        internal virtual void OnDropMessage() { }
    }
}
