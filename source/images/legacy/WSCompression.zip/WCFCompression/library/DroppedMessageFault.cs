//
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.
//
using System;
using System.ServiceModel.Channels;
using System.Xml;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Microsoft.ServiceModel.Samples
{
    class DroppedMessageFault : MessageFault
    {
        FaultReason faultReason;
        FaultCode faultCode;

        public DroppedMessageFault(string reason)
        {
            faultReason = new FaultReason(reason);
            faultCode = new FaultCode("DroppedMessageFault");
        }

        public override FaultCode Code
        {
            get { return faultCode; }
        }
        
        public override bool HasDetail
        {
            get { return false; }
        }

        public override FaultReason Reason
        {
            get { return faultReason; }
        }

        protected override void OnWriteDetailContents(XmlDictionaryWriter writer)
        {
            throw new NotImplementedException("The method or operation is not implemented.");
        }
    }
}
