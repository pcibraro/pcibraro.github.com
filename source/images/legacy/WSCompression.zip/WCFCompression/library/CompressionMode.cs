using System;

namespace Microsoft.ServiceModel.Samples
{
    public enum CompressionMode
    {
        None = 0,
        GZip = 1,
        Deflate = 2,
    }
}