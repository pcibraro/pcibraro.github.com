using System;

namespace Microsoft.ServiceModel.Samples
{
    public enum CompressionLevel
    {
        Fast = 1,
        Normal = -1,
        Maximum = 9,
        NoCompression = 0
    }
}