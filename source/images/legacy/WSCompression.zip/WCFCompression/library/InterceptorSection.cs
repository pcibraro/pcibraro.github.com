
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;

using System.ServiceModel.Channels;
using System.Configuration;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using System.ComponentModel;

namespace Microsoft.ServiceModel.Samples
{
    class CompressionSection : BindingElementExtensionSection
    {
        public override Type BindingElementType
        {
            get { return typeof(InterceptorBindingElement); }
        }

        [ConfigurationProperty("compressionMode", DefaultValue = CompressionMode.GZip)]
        public CompressionMode CompressionMode
        {
            get { return (CompressionMode)base["compressionMode"]; }
        }

        [ConfigurationProperty("compressionLevel", DefaultValue = CompressionLevel.Normal)]
        public CompressionLevel CompressionLevel
        {
            get { return (CompressionLevel)base["compressionLevel"]; }
        }

        protected override BindingElement CreateBindingElement()
        {
            CompressionInterceptor interceptor = new CompressionInterceptor(CompressionLevel, CompressionMode);

            InterceptorBindingElement bindingElement = new InterceptorBindingElement(interceptor);
            return bindingElement;
        }
    }
}
