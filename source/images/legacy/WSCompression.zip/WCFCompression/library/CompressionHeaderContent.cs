using System;
using System.Globalization;
using System.Xml;

using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Text;
using System.IO;

namespace Microsoft.ServiceModel.Samples
{
    
    internal sealed class CompressionHeaderContent : IXmlSerializable
    {
        private CompressionMode _compressionMode;
        private CompressionLevel _compressionLevel;
        private CompressionMethod _compressionMethod;
        private ReferenceList _referenceList;
                
        public CompressionHeaderContent()
        {
        }

        public CompressionHeaderContent(CompressionMode compressionMode, CompressionLevel compressionLevel)
        {
            _compressionMode = compressionMode;
            _compressionLevel = compressionLevel;
            _compressionMethod = new CompressionMethod( compressionMode, compressionLevel );
        }

        public CompressionHeaderContent(XmlReader reader)
        {
            _compressionMode = CompressionMode.None;
            _compressionLevel = CompressionLevel.NoCompression;

            ReadXml(reader);
        }
        
        public CompressionMethod Method
        {
            get
            {
                return _compressionMethod;
            }
        }
        
        public CompressionMode Mode
        {
            get
            {
                return _compressionMode;
            }
        }

        public CompressionLevel Level
        {
            get
            {
                return _compressionLevel;
            }
        }

        public ReferenceList ReferenceList
        {
            get
            {
                if ( _referenceList == null )
                    _referenceList = new ReferenceList( );
                return _referenceList;
            }
        }
                        
        public static bool IsValidElement( XmlReader reader )
        {
            return (reader.LocalName == WSCompression.ElementNames.Compression && reader.NamespaceURI == WSCompression.NamespaceURI);
        }

        
                
        #region IXmlSerializable Members

        public System.Xml.Schema.XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(XmlReader reader)
        {
            _compressionMethod = null;
            _referenceList = null;

            reader.ReadStartElement();
 
            while (reader.MoveToContent() == XmlNodeType.Element)
            {
                if (ReferenceList.IsValidElement(reader))
                {
                    _referenceList = new ReferenceList(reader);
                }
                else if (CompressionMethod.IsValidElement(reader))
                {
                    _compressionMethod = new CompressionMethod(reader);
                }
                else
                {
                    throw new FaultException("An error was discovered processing the <Compression> header", new FaultCode("InvalidCompression", WSCompression.NamespaceURI));
                }
            }

            reader.ReadEndElement(); 

            if (_referenceList == null || _compressionMethod == null)
                throw new FaultException("An error was discovered processing the <Compression> header", new FaultCode("InvalidCompression", WSCompression.NamespaceURI));

            try
            {
                _compressionMode = CompressionMethod.GetCompressionMode(Method.Algorithm);
                _compressionLevel = CompressionMethod.GetCompressionLevel(Method.Level);
            }
            catch (ArgumentOutOfRangeException)
            {
                throw new FaultException("An unsupported compression algorithm was used", new FaultCode("UnsupportedAlgorithm", WSCompression.NamespaceURI));
            }

            if (ReferenceList.Count != 1)
                throw new FaultException("Referenced element not found in document", new FaultCode("ReferencedDataNotFound", WSCompression.NamespaceURI));
        }

        public void WriteXml(XmlWriter writer)
        {
            if (Method != null)
                Method.WriteXml(writer);

            if (_referenceList != null)
                _referenceList.WriteXml(writer);
        }

        #endregion
    }
}