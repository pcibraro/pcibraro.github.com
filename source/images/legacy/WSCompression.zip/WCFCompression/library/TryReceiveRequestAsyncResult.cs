//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//--------------------------------------------------------------------------
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
    class TryReceiveRequestAsyncResult : AsyncResult
    {
        Message message;
        IRequestContext context;
        TimeSpan timeout;
        InterceptorChannelBase<IReplyChannel> channel;

        public TryReceiveRequestAsyncResult(InterceptorChannelBase<IReplyChannel> channel, TimeSpan timeout, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.timeout = timeout;
            this.channel = channel;
            channel.InnerChannel.BeginTryReceiveRequest(timeout, new AsyncCallback(HandleCallback), null);
        }

        void HandleCallback(IAsyncResult asyncResult)
        {
            IRequestContext context;
            try
            {
                if (channel.InnerChannel.EndTryReceiveRequest(asyncResult, out context))
                {
                    if (context == null)
                    {
                        this.message = null;
                        this.context = null;

                        Complete(false);
                    }
                    else
                    {
                        Message result = context.RequestMessage;
                        
                        channel.Interceptor.ProcessReceive(ref result);
                        if (result == null)
                        {
                            channel.OnDropMessage();
                            asyncResult = channel.InnerChannel.BeginTryReceiveRequest(timeout, new AsyncCallback(HandleCallback), null);
                        }
                        else
                        {
                            this.message = result;
                            this.context = context;

                            Complete(false);
                        }
                    }
                }
                else
                {
                    Complete(false, new TimeoutException("Receive request timed out."));
                }
            }
            catch (Exception e)
            {
                Complete(false, e);
            }
        }

        public static Message End(IAsyncResult asyncResult, out IRequestContext context)
        {
            if (asyncResult == null)
            {
                throw new ArgumentNullException("asyncResult");
            }
            TryReceiveRequestAsyncResult replyResult = asyncResult as TryReceiveRequestAsyncResult;
            if (replyResult == null)
            {
                throw new ArgumentException("Invalid AsyncResult", "asyncResult");
            }
            AsyncResult.End(replyResult);

            context = replyResult.context;
            return replyResult.message;
        }
    }
}
