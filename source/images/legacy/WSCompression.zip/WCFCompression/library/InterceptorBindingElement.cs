
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;

using System.ServiceModel.Channels;
using System.ServiceModel;


namespace Microsoft.ServiceModel.Samples
{
    public class InterceptorBindingElement : BindingElement
    {
        IMessageInterceptor interceptor;

        public InterceptorBindingElement() { }

        public InterceptorBindingElement(IMessageInterceptor interceptor)
        {
            this.interceptor = interceptor;
        }

        protected InterceptorBindingElement(InterceptorBindingElement other)
            : base(other)
        {
            this.interceptor = other.interceptor;
        }

        public IMessageInterceptor Interceptor
        {
            get { return this.interceptor; }
            set { this.interceptor = value; }
        }

        public override IChannelFactory<TChannel> BuildChannelFactory<TChannel>(BindingContext context)
        {
            InterceptorChannelFactory<TChannel> result = new InterceptorChannelFactory<TChannel>(this.interceptor, context.Binding);
            result.InnerChannelFactory = context.BuildInnerChannelFactory<TChannel>();
            return result;
        }

        public override IChannelListener<TChannel> BuildChannelListener<TChannel>(BindingContext context)
        {
            InterceptorChannelListener<TChannel> result = new InterceptorChannelListener<TChannel>(this.interceptor, context.Binding);
            result.InnerChannelListener = context.BuildInnerChannelListener<TChannel>();
            return result;
        }

        public override BindingElement Clone()
        {
            return new InterceptorBindingElement(this);
        }

        public override T GetProperty<T>(BindingContext context)
        {
            return context.GetInnerProperty<T>();
        }
    }
}
