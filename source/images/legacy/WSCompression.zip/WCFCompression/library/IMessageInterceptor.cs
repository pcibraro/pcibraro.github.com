//
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.
//
namespace Microsoft.ServiceModel.Samples
{
    using System.ServiceModel;
    using System.ServiceModel.Channels;

    public interface IMessageInterceptor
    {
        void ProcessReceive(ref Message message);
        void ProcessSend(ref Message message);
    }
}