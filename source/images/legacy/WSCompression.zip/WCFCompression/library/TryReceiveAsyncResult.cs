//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//--------------------------------------------------------------------------
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
    class TryReceiveAsyncResult<TChannel> : AsyncResult
        where TChannel : IInputChannel
    {
        Message message;
        TimeSpan timeout;
        InterceptorChannelBase<TChannel> channel;

        public TryReceiveAsyncResult(InterceptorChannelBase<TChannel> channel, TimeSpan timeout, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.channel = channel;
            this.timeout = timeout;
            channel.InnerChannel.BeginTryReceive(timeout, new AsyncCallback(HandleCallback), null);
        }

        void HandleCallback(IAsyncResult asyncResult)
        {
            Message message;
            try
            {
                if (channel.InnerChannel.EndTryReceive(asyncResult, out message))
                {
                    if (message == null)
                    {
                        this.message = null;

                        Complete(false);
                    }
                    else
                    {
                        channel.Interceptor.ProcessReceive(ref message);

                        if (message == null)
                        {
                            channel.OnDropMessage();
                            asyncResult = channel.InnerChannel.BeginTryReceive(timeout, new AsyncCallback(HandleCallback), null);
                        }
                        else
                        {
                            this.message = message;

                            Complete(false);
                        }
                    }
                }
                else
                {
                    Complete(false, new TimeoutException("Receive request timed out."));
                }
            }
            catch (Exception e)
            {
                Complete(false, e);
            }
        }

        public static Message End(IAsyncResult asyncResult)
        {
            if (asyncResult == null)
            {
                throw new ArgumentNullException("asyncResult");
            }
            TryReceiveAsyncResult<TChannel> inputResult = asyncResult as TryReceiveAsyncResult<TChannel>;
            if (inputResult == null)
            {
                throw new ArgumentException("Invalid AsyncResult", "asyncResult");
            }
            AsyncResult.End(inputResult);

            return inputResult.message;
        }
    }
}
