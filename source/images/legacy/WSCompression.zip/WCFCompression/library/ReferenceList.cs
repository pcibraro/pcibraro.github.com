using System;
using System.Xml;
using System.Collections;

namespace Microsoft.ServiceModel.Samples
{
    /// <summary>
    /// List of references. This will link DataReference headers to the compressed data.
    /// </summary>
    public class ReferenceList
    {
        private ArrayList _refList;

        public ReferenceList( )
        {
            _refList = new ArrayList( );
        }

        public ReferenceList( XmlReader elementReader )
        {
            _refList = new ArrayList( );
            ReadXml( elementReader );
        }

        public static bool IsValidElement( XmlReader reader )
        {
            if ( reader == null )
                throw new ArgumentNullException("reader");

            return (reader.LocalName == WSCompression.ElementNames.ReferenceList && reader.NamespaceURI == WSCompression.NamespaceURI);
        }

        public void AddReference( string reference )
        {
            if ( String.IsNullOrEmpty( reference ) )
                throw new ArgumentNullException( "reference" );

            if ( reference.StartsWith( "#" ) )
                reference = reference.Substring( 1 );

            _refList.Add( reference );
        }

        public IEnumerator GetEnumerator( )
        {
            return _refList.GetEnumerator( );
        }

        public int Count
        {
            get
            {
                return _refList.Count;
            }
        }

        public string this[ int index ]
        {
            get { return ( string )_refList[ index ]; }
        }

        public static string GenerateNewReference( )
        {
            return "#CompressedContent-" + Guid.NewGuid( ).ToString( "D" );
        }

        public void ReadXml( XmlReader reader )
        {
            if ( reader == null )
                throw new ArgumentNullException("reader");

            reader.ReadStartElement(WSCompression.ElementNames.ReferenceList, WSCompression.NamespaceURI);

            while (reader.MoveToContent() == XmlNodeType.Element && 
                reader.LocalName == WSCompression.ElementNames.DataReference &&
                reader.NamespaceURI == WSCompression.NamespaceURI)
            {
                string reference = reader.GetAttribute(WSCompression.AttributeNames.Uri);
                if (!String.IsNullOrEmpty(reference))
                    AddReference(reference);

                reader.Read();
            }
        }

        public void WriteXml( XmlWriter writer )
        {
            if ( writer == null )
                throw new ArgumentNullException("writer");

            writer.WriteStartElement(WSCompression.Prefix, WSCompression.ElementNames.ReferenceList, WSCompression.NamespaceURI);

            foreach ( string reference in _refList )
            {
                writer.WriteStartElement(WSCompression.Prefix, WSCompression.ElementNames.DataReference, WSCompression.NamespaceURI); 
                if ( reference.StartsWith( "#" ) )
                {
                    writer.WriteAttributeString( WSCompression.AttributeNames.Uri, reference );
                }
                else
                {
                    writer.WriteAttributeString(WSCompression.AttributeNames.Uri, "#" + reference);
                }
                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        
    }
}