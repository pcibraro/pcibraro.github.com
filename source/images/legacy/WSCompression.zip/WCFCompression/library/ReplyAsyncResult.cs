//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//--------------------------------------------------------------------------
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
	class ReplyAsyncResult : AsyncResult
	{
        Message message;
        TimeSpan timeout;
        IRequestContext innerContext;
        InterceptorChannelBase<IReplyChannel> channel;

        public ReplyAsyncResult(InterceptorChannelBase<IReplyChannel> channel, Message message,
            TimeSpan timeout, IRequestContext innerContext, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.message = message;
            this.timeout = timeout;
            this.innerContext = innerContext;
            this.channel = channel;

            channel.Interceptor.ProcessSend(ref this.message);
            if (this.message == null)
            {
                channel.OnDropMessage();
                this.message = Message.CreateMessage(message.Version, new DroppedMessageFault("Reply Message dropped by interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                Complete(true);
            }
            else
            {
                innerContext.BeginReply(this.message, new AsyncCallback(HandleCallback), null);
            }
        }

        void HandleCallback(IAsyncResult asyncResult)
        {
            try
            {
                innerContext.EndReply(asyncResult);
                Complete(false);
            }
            catch (Exception e)
            {
                Complete(false, e);
            }
        }

        public new WaitHandle AsyncWaitHandle
        {
            get { return base.AsyncWaitHandle; }
        }

        public new bool IsCompleted
        {
            get { return base.IsCompleted; }
        }

        public new bool CompletedSynchronously
        {
            get { return base.CompletedSynchronously; }
        }

        public static void End(IAsyncResult result)
        {
            if (result == null)
            {
                throw new ArgumentNullException("result");
            }
            ReplyAsyncResult requestResult = result as ReplyAsyncResult;
            if (requestResult == null)
            {
                throw new ArgumentException("Invalid AsyncResult", "result");
            }
            AsyncResult.End(requestResult);
        }
	}
}
