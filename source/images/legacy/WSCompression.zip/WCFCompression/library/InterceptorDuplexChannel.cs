
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
    class InterceptorDuplexChannel : InterceptorChannelBase<IDuplexChannel>, IDuplexChannel
    {
        public InterceptorDuplexChannel(ChannelManagerBase manager, IDuplexChannel innerChannel, IMessageInterceptor interceptor)
            : base(manager, innerChannel, interceptor)
        {
        }

        public EndpointAddress LocalAddress
        {
            get { return this.InnerChannel.LocalAddress; }
        }

        public EndpointAddress RemoteAddress
        {
            get { return this.InnerChannel.RemoteAddress; }
        }

        public Uri Via
        {
            get { return this.InnerChannel.Via; }
        }

        public IAsyncResult BeginReceive(AsyncCallback callback, object state)
        {
            return this.BeginReceive(DefaultReceiveTimeout, callback, state);
        }

        public IAsyncResult BeginReceive(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.BeginTryReceive(timeout, callback, state);
        }

        public IAsyncResult BeginSend(Message message, AsyncCallback callback, object state)
        {
            return this.BeginSend(message, DefaultSendTimeout, callback, state);
        }

        public IAsyncResult BeginSend(Message message, TimeSpan timeout, AsyncCallback callback, object state)
        {
            ThrowIfDisposedOrNotOpen();
            return new SendAsyncResult<IDuplexChannel>(this, message, timeout, callback, state);
        }

        public Message EndReceive(IAsyncResult result)
        {
            Message message;
            this.EndTryReceive(result, out message);
            return message;
        }

        public void EndSend(IAsyncResult result)
        {
            SendAsyncResult<IDuplexChannel>.End(result);
        }

        public bool TryReceive(TimeSpan timeout, out Message message)
        {
            ThrowIfDisposedOrNotOpen();
            do
            {
                if (this.InnerChannel.TryReceive(timeout, out message))
                {
                    if (message == null)
                    {
                        return true;
                    }
                    else
                    {
                        Interceptor.ProcessReceive(ref message);
                        if (message == null)
                        {
                            OnDropMessage();
                        }
                    }
                }
                else
                {
                    return false;
                }
            } while (message == null);

            return true;
        }

        public IAsyncResult BeginTryReceive(TimeSpan timeout, AsyncCallback callback, object state)
        {
            ThrowIfDisposedOrNotOpen();
            return new TryReceiveAsyncResult<IDuplexChannel>(this, timeout, callback, state);
        }

        public bool EndTryReceive(IAsyncResult result, out Message message)
        {
            message = TryReceiveAsyncResult<IDuplexChannel>.End(result);
            return true;
        }

        public bool WaitForMessage(TimeSpan timeout)
        {
            return this.InnerChannel.WaitForMessage(timeout);
        }

        public IAsyncResult BeginWaitForMessage(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.InnerChannel.BeginWaitForMessage(timeout, callback, state);
        }

        public bool EndWaitForMessage(IAsyncResult result)
        {
            return this.InnerChannel.EndWaitForMessage(result);
        }

        public Message Receive()
        {
            return this.Receive(DefaultReceiveTimeout);
        }

        public Message Receive(TimeSpan timeout)
        {
            Message message;
            if (this.TryReceive(timeout, out message))
            {
                return message;
            }
            else
            {
                throw new TimeoutException("Receive timed out.");
            }
        }

        public void Send(Message message)
        {
            this.Send(message, DefaultSendTimeout);
        }

        public void Send(Message message, TimeSpan timeout)
        {
            ThrowIfDisposedOrNotOpen();
            Interceptor.ProcessSend(ref message);
            if (message == null)
            {
                OnDropMessage();
            }
            else
            {
                this.InnerChannel.Send(message, timeout);
            }
        }
    }


    class InterceptorDuplexSessionChannel : InterceptorDuplexChannel, IDuplexSessionChannel
    {
        IDuplexSessionChannel innerSessionChannel;

        public InterceptorDuplexSessionChannel(ChannelManagerBase manager, IDuplexSessionChannel innerChannel, IMessageInterceptor interceptor)
            : base(manager, innerChannel, interceptor)
        {
            this.innerSessionChannel = innerChannel;
        }

        public IDuplexSession Session
        {
            get { return innerSessionChannel.Session; }
        }

        internal override void OnDropMessage()
        {
            Fault();
            innerSessionChannel.Abort();
        } 
    }
}
