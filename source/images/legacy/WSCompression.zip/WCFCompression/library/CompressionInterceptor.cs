using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

using System.ServiceModel;
using System.ServiceModel.Channels;


namespace Microsoft.ServiceModel.Samples
{
	internal class CompressionInterceptor : IMessageInterceptor
	{
        CompressionLevel level;
        CompressionMode mode;

        public CompressionInterceptor(CompressionLevel level, CompressionMode mode)
        {
            this.level = level;
            this.mode = mode;
        }

        #region IMessageInterceptor Members

        public void ProcessReceive(ref System.ServiceModel.Channels.Message message)
        {
            message = Decompress(message);
        }

        public void ProcessSend(ref System.ServiceModel.Channels.Message message)
        {
            message = Compress(message);
        }

        #endregion

        public Message Compress(Message message)
        {
            if (message == null)
                throw new ArgumentNullException("message");

            CompressionHeaderContent compressionContent = new CompressionHeaderContent(this.mode, this.level);

            string compressedBodyURI = ReferenceList.GenerateNewReference();
            compressionContent.ReferenceList.AddReference(compressedBodyURI);

            XmlDocument document = new XmlDocument();

            document.Load(message.GetReaderAtBodyContents());

            XmlNode body = document.FirstChild;

            StringBuilder newMessageXml = new StringBuilder();

            XmlTextWriter xmlWriter = new XmlTextWriter(new StringWriter(newMessageXml));

            CompressedData compressedData = new CompressedData(compressionContent.Mode, compressionContent.Level, compressedBodyURI);
            compressedData.WriteCompressedXml(xmlWriter, body.OuterXml);

            xmlWriter.Close();

            // Create new message 
            XmlTextReader xmlReader = new XmlTextReader(new StringReader(newMessageXml.ToString()));

            Message newMsg = Message.CreateMessage(message.Version, null, xmlReader);

            // Preserve the headers of the original message 
            newMsg.Headers.CopyHeadersFrom(message);

            foreach (string propertyKey in message.Properties.Keys)
                newMsg.Properties.Add(propertyKey, message.Properties[propertyKey]);

            // Close the original message and return new message 
            message.Close();

            MessageHeader<CompressionHeaderContent> compressionHeader = new MessageHeader<CompressionHeaderContent>(compressionContent, true, "", false);
            newMsg.Headers.Add(compressionHeader.GetUntypedHeader(WSCompression.ElementNames.Compression, WSCompression.NamespaceURI));

            return newMsg;
        }

        public Message Decompress(Message compressedMessage)
        {
            int index = compressedMessage.Headers.FindHeader(WSCompression.ElementNames.Compression, WSCompression.NamespaceURI);
            if (index == -1)
                throw new Exception("The compression header is missing");

            CompressionHeaderContent compressionHeader = compressedMessage.Headers.GetHeader<CompressionHeaderContent>(index);

            string reference = compressionHeader.ReferenceList[0];

            XmlReader reader = compressedMessage.GetReaderAtBodyContents();

            while (reader.MoveToContent() == XmlNodeType.Element)
            {
                if (reader.NodeType == XmlNodeType.Element && CompressedData.IsValidElement(reader))
                {
                    string id = reader.GetAttribute(WSCompression.AttributeNames.Id);
                    if (id != "#" + reference)
                        throw new FaultException("Referenced element not found in document", new FaultCode("ReferencedDataNotFound", WSCompression.NamespaceURI));

                    break;
                }
                reader.Read();
            }
            
            CompressedData compressedData = new CompressedData(compressionHeader.Mode, compressionHeader.Level, reader);
            string body = compressedData.Data;

            compressedMessage.Headers.RemoveAt(index);

            // Create new message 
            XmlTextReader xmlReader = new XmlTextReader(new StringReader(body));

            Message newMsg = Message.CreateMessage(compressedMessage.Version, null, xmlReader);

            // Preserve the headers of the original message 
            newMsg.Headers.CopyHeadersFrom(compressedMessage);

            foreach (string propertyKey in compressedMessage.Properties.Keys)
                newMsg.Properties.Add(propertyKey, compressedMessage.Properties[propertyKey]);

            // Close the original message and return new message 
            compressedMessage.Close();

            return newMsg;
        }
        
    }
}
