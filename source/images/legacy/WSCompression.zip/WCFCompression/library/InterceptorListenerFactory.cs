
//  Copyright (c) Microsoft Corporation.  All Rights Reserved.

using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
    class InterceptorChannelListener<TChannel> : ChannelListenerBase<TChannel>
        where TChannel : class, IChannel
    {
        IMessageInterceptor interceptor;

        public InterceptorChannelListener(IMessageInterceptor interceptor, IDefaultCommunicationTimeouts timeouts)
            : base(timeouts)
        {
            if (interceptor == null)
            {
                this.interceptor = new NullMessageInterceptor();
            }
            else
            {
                this.interceptor = interceptor;
            }
        }

        public new IChannelListener<TChannel> InnerChannelListener
        {
            get { return (IChannelListener<TChannel>)base.InnerChannelListener; }
            set { base.InnerChannelListener = value; }
        }

        public IMessageInterceptor Interceptor
        {
            get { return interceptor; }
        }

        public override Uri Uri
        {
            get { return GetInnerListenerSnapshot().Uri; }
        }

        public override MessageVersion MessageVersion
        {
            get { return GetInnerListenerSnapshot().MessageVersion; }
        }

        public override string Scheme
        {
            get { return GetInnerListenerSnapshot().Scheme; }
        }

        protected override void OnOpen(TimeSpan timeout)
        {
            this.InnerChannelListener.Open(timeout);
        }

        protected override IAsyncResult OnBeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.InnerChannelListener.BeginOpen(timeout, callback, state);
        }

        protected override void OnEndOpen(IAsyncResult result)
        {
            this.InnerChannelListener.EndOpen(result);
        }

        protected override void OnClose(TimeSpan timeout)
        {
            this.InnerChannelListener.Close(timeout);
        }

        protected override IAsyncResult OnBeginClose(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.InnerChannelListener.BeginClose(timeout, callback, state);
        }

        protected override void OnEndClose(IAsyncResult result)
        {
            this.InnerChannelListener.EndClose(result);
        }

        void ThrowIfInnerListenerNotSet()
        {
            if (this.InnerChannelListener == null)
            {
                throw new InvalidOperationException("Inner listener is not set.");
            }
        }

        IChannelListener GetInnerListenerSnapshot()
        {
            IChannelListener innerChannelListener = this.InnerChannelListener;

            if (innerChannelListener == null)
            {
                throw new InvalidOperationException("Inner listener is not set.");
            }

            return innerChannelListener;
        }

        protected override TChannel OnAcceptChannel(TimeSpan timeout)
        {
            TChannel innerChannel = this.InnerChannelListener.AcceptChannel(timeout);
            return OnAcceptChannel(innerChannel);
        }

        protected override IAsyncResult OnBeginAcceptChannel(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.InnerChannelListener.BeginAcceptChannel(timeout, callback, state);
        }

        protected override TChannel OnEndAcceptChannel(IAsyncResult result)
        {
            TChannel innerChannel = this.InnerChannelListener.EndAcceptChannel(result);
            return OnAcceptChannel(innerChannel);
        }

        protected override bool OnWaitForChannel(TimeSpan timeout)
        {
            return this.InnerChannelListener.WaitForChannel(timeout);
        }

        protected override IAsyncResult OnBeginWaitForChannel(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.InnerChannelListener.BeginWaitForChannel(timeout, callback, state);
        }

        protected override bool OnEndWaitForChannel(IAsyncResult result)
        {
            return this.InnerChannelListener.EndWaitForChannel(result);
        }

        TChannel OnAcceptChannel(TChannel innerChannel)
        {
            if (innerChannel == null)
            {
                return null;
            }

            if (typeof(TChannel) == typeof(IInputChannel))
            {
                return (TChannel)(object)new InterceptorInputChannel(this, (IInputChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IReplyChannel))
            {
                return (TChannel)(object)new InterceptorReplyChannel(this, (IReplyChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IDuplexChannel))
            {
                return (TChannel)(object)new InterceptorDuplexChannel(this, (IDuplexChannel)innerChannel, this.interceptor);
            }
            else if (typeof(TChannel) == typeof(IInputSessionChannel))
            {
                return (TChannel)(object)new InterceptorInputSessionChannel(this,
                    (IInputSessionChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IReplySessionChannel))
            {
                return (TChannel)(object)new InterceptorReplySessionChannel(this,
                    (IReplySessionChannel)innerChannel);
            }
            else if (typeof(TChannel) == typeof(IDuplexSessionChannel))
            {
                return (TChannel)(object)new InterceptorDuplexSessionChannel(this,
                    (IDuplexSessionChannel)innerChannel, this.interceptor);
            }

            // Cannot wrap this channel.
            return innerChannel;
        }

        class InterceptorInputChannel : InterceptorChannelBase<IInputChannel>, IInputChannel
        {
            InterceptorChannelListener<TChannel> listener;

            public InterceptorInputChannel(InterceptorChannelListener<TChannel> listener, IInputChannel innerChannel)
                : base(listener, innerChannel, listener.interceptor)
            {
                this.listener = listener;
            }

            public EndpointAddress LocalAddress
            {
                get { return this.InnerChannel.LocalAddress; }
            }

            public IAsyncResult BeginReceive(AsyncCallback callback, object state)
            {
                return this.BeginReceive(listener.DefaultReceiveTimeout, callback, state);
            }

            public IAsyncResult BeginReceive(TimeSpan timeout, AsyncCallback callback, object state)
            {
                return this.BeginTryReceive(timeout, callback, state);
            }

            public Message EndReceive(IAsyncResult result)
            {
                Message message;
                this.EndTryReceive(result, out message);
                return message;
            }

            public bool TryReceive(TimeSpan timeout, out Message message)
            {
                ThrowIfDisposedOrNotOpen();
                do
                {
                    if (this.InnerChannel.TryReceive(timeout, out message))
                    {
                        if (message == null)
                        {
                            return true;
                        }
                        else
                        {
                            Interceptor.ProcessReceive(ref message);
                            if (message == null)
                            {
                                OnDropMessage();
                            }
                        }
                    }
                    else
                    {
                        return false;
                    }
                } while (message == null);

                return true;
            }

            public IAsyncResult BeginTryReceive(TimeSpan timeout, AsyncCallback callback, object state)
            {
                ThrowIfDisposedOrNotOpen();
                return new TryReceiveAsyncResult<IInputChannel>(this, timeout, callback, state);
            }

            public bool EndTryReceive(IAsyncResult result, out Message message)
            {
                message = TryReceiveAsyncResult<IInputChannel>.End(result);
                return true;
            }

            public bool WaitForMessage(TimeSpan timeout)
            {
                return this.InnerChannel.WaitForMessage(timeout);
            }

            public IAsyncResult BeginWaitForMessage(TimeSpan timeout, AsyncCallback callback, object state)
            {
                return this.InnerChannel.BeginWaitForMessage(timeout, callback, state);
            }

            public bool EndWaitForMessage(IAsyncResult result)
            {
                return this.InnerChannel.EndWaitForMessage(result);
            }

            public Message Receive()
            {
                return this.Receive(listener.DefaultReceiveTimeout);
            }

            public Message Receive(TimeSpan timeout)
            {
                Message message;
                if (this.TryReceive(timeout, out message))
                {
                    return message;
                }
                else
                {
                    throw new TimeoutException("Receive timed out.");
                }
            }
        }

        class InterceptorReplyChannel : InterceptorChannelBase<IReplyChannel>, IReplyChannel
        {
            InterceptorChannelListener<TChannel> listener;

            public InterceptorReplyChannel(InterceptorChannelListener<TChannel> listener, IReplyChannel innerChannel)
                : base(listener, innerChannel, listener.interceptor)
            {
                this.listener = listener;
            }

            public EndpointAddress LocalAddress
            {
                get { return this.InnerChannel.LocalAddress; }
            }

            public IAsyncResult BeginReceiveRequest(AsyncCallback callback, object state)
            {
                return this.BeginReceiveRequest(listener.DefaultReceiveTimeout, callback, state);
            }

            public IAsyncResult BeginReceiveRequest(TimeSpan timeout, AsyncCallback callback, object state)
            {
                return this.BeginTryReceiveRequest(timeout, callback, state);
            }

            public IRequestContext EndReceiveRequest(IAsyncResult result)
            {
                IRequestContext requestContext;
                this.EndTryReceiveRequest(result, out requestContext);
                return requestContext;
            }

            public bool TryReceiveRequest(TimeSpan timeout, out IRequestContext requestContext)
            {
                ThrowIfDisposedOrNotOpen();
                Message resultMessage;
                IRequestContext innerRequestContext;

                requestContext = null;

                do
                {
                    if (this.InnerChannel.TryReceiveRequest(timeout, out innerRequestContext))
                    {
                        if (innerRequestContext == null)
                        {
                            return true;
                        }
                        else
                        {
                            resultMessage = innerRequestContext.RequestMessage;
                            Interceptor.ProcessReceive(ref resultMessage);
                            if (resultMessage == null)
                            {
                                OnDropMessage();
                            }
                            else
                            {
                                requestContext = new InterceptorRequestContext(resultMessage, this, innerRequestContext, timeout);
                            }
                        }
                    }
                    else
                    {
                        return false;
                    }
                } while (resultMessage == null);

                return true;
            }

            public IAsyncResult BeginTryReceiveRequest(TimeSpan timeout, AsyncCallback callback, object state)
            {
                ThrowIfDisposedOrNotOpen();
                return new TryReceiveRequestAsyncResult(this, timeout, callback, state);
            }

            public bool EndTryReceiveRequest(IAsyncResult result, out IRequestContext requestContext)
            {
                IRequestContext context;
                Message message = TryReceiveRequestAsyncResult.End(result, out context);
                if (context == null)
                {
                    requestContext = null;
                }
                else
                {
                    requestContext = new InterceptorRequestContext(message, this, context, listener.DefaultSendTimeout);
                }
                return true;
            }

            public bool WaitForRequest(TimeSpan timeout)
            {
                return this.InnerChannel.WaitForRequest(timeout);
            }

            public IAsyncResult BeginWaitForRequest(TimeSpan timeout, AsyncCallback callback, object state)
            {
                return this.InnerChannel.BeginWaitForRequest(timeout, callback, state);
            }

            public bool EndWaitForRequest(IAsyncResult result)
            {
                return this.InnerChannel.EndWaitForRequest(result);
            }

            public IRequestContext ReceiveRequest()
            {
                return this.ReceiveRequest(listener.DefaultReceiveTimeout);
            }

            public IRequestContext ReceiveRequest(TimeSpan timeout)
            {
                IRequestContext requestContext;
                if (this.TryReceiveRequest(timeout, out requestContext))
                {
                    return requestContext;
                }
                else
                {
                    throw new TimeoutException("Receive request timed out.");
                }
            }

            class InterceptorRequestContext : IRequestContext
            {
                Message message;
                InterceptorReplyChannel channel;
                IRequestContext innerContext;
                TimeSpan defaultSendTimeout;

                public InterceptorRequestContext(Message message, InterceptorReplyChannel channel, IRequestContext innerContext, TimeSpan defaultSendTimeout)
                {
                    this.channel = channel;
                    this.innerContext = innerContext;
                    this.message = message;
                    this.defaultSendTimeout = defaultSendTimeout;
                }

                public Message RequestMessage
                {
                    get { return this.message; }
                }

                public void Abort()
                {
                    this.innerContext.Abort();
                }

                public IAsyncResult BeginReply(Message message, AsyncCallback callback, object state)
                {
                    return this.BeginReply(message, defaultSendTimeout, callback, state);
                }

                public IAsyncResult BeginReply(Message message, TimeSpan timeout, AsyncCallback callback, object state)
                {
                    return new ReplyAsyncResult(channel, message, timeout, innerContext, callback, state);
                }

                public void Close()
                {
                    this.innerContext.Close();
                }

                public void Close(TimeSpan timeout)
                {
                    this.innerContext.Close(timeout);
                }

                public void Dispose()
                {
                    this.innerContext.Dispose();
                }

                public void EndReply(IAsyncResult result)
                {
                    ReplyAsyncResult.End(result);
                }

                public void Reply(Message message)
                {
                    this.Reply(message, defaultSendTimeout);
                }

                public void Reply(Message message, TimeSpan timeout)
                {
                    channel.Interceptor.ProcessSend(ref message);
                    if (message == null)
                    {
                        channel.OnDropMessage();
                    }
                    else
                    {
                        this.innerContext.Reply(message, timeout);
                    }
                }
            }
        }

        class InterceptorInputSessionChannel : InterceptorInputChannel, IInputSessionChannel
        {
            IInputSessionChannel innerSessionChannel;

            public InterceptorInputSessionChannel(InterceptorChannelListener<TChannel> listener, IInputSessionChannel innerChannel)
                : base(listener, innerChannel)
            {
                this.innerSessionChannel = innerChannel;
            }

            public IInputSession Session
            {
                get { return innerSessionChannel.Session; }
            }

            internal override void OnDropMessage()
            {
                Fault();
                innerSessionChannel.Abort();
            }
        }

        class InterceptorReplySessionChannel : InterceptorReplyChannel, IReplySessionChannel
        {
            IReplySessionChannel innerSessionChannel;

            public InterceptorReplySessionChannel(InterceptorChannelListener<TChannel> listener, IReplySessionChannel innerChannel)
                : base(listener, innerChannel)
            {
                this.innerSessionChannel = innerChannel;
            }

            public IInputSession Session
            {
                get { return innerSessionChannel.Session; }
            }

            internal override void OnDropMessage()
            {
                Fault();
                innerSessionChannel.Abort();
            }
        }
    }
}
