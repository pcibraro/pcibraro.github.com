//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//--------------------------------------------------------------------------
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
	class RequestAsyncResult : AsyncResult
	{
        Message message;
        TimeSpan timeout;
        InterceptorChannelBase<IRequestChannel> channel;

        public RequestAsyncResult(InterceptorChannelBase<IRequestChannel> channel, Message message, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.message = message;
            this.channel = channel;

            channel.Interceptor.ProcessSend(ref this.message);
            if (this.message == null)
            {
                channel.OnDropMessage();
                this.message = Message.CreateMessage(MessageVersion.Soap12WSAddressing10, new DroppedMessageFault("Request Message dropped by interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                Complete(true);
            }
            else
            {
                channel.InnerChannel.BeginRequest(this.message, new AsyncCallback(HandleCallback), null);
            }
        }

        public RequestAsyncResult(InterceptorChannelBase<IRequestChannel> channel, Message message, TimeSpan timeout, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.message = message;
            this.timeout = timeout;
            this.channel = channel;

            channel.Interceptor.ProcessSend(ref this.message);
            if (this.message == null)
            {
                channel.OnDropMessage();
                this.message = Message.CreateMessage(message.Version, new DroppedMessageFault("Request Message dropped by interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                Complete(true);
            }
            else
            {
                channel.InnerChannel.BeginRequest(this.message, timeout, new AsyncCallback(HandleCallback), null);
            }
        }

        void HandleCallback(IAsyncResult asyncResult)
        {
            try
            {
                Message reply = channel.InnerChannel.EndRequest(asyncResult);
                channel.Interceptor.ProcessReceive(ref reply);
                if (reply == null)
                {
                    channel.OnDropMessage();
                    this.message = Message.CreateMessage(MessageVersion.Soap12WSAddressing10, new DroppedMessageFault("Reply Message dropped by interceptor."), "http://www.w3.org/2005/08/addressing/fault");
                }
                else
                {
                    this.message = reply;
                }
                Complete(false);
            }
            catch (Exception e)
            {
                Complete(false, e);
            }
        }

        public new WaitHandle AsyncWaitHandle
        {
            get { return base.AsyncWaitHandle; }
        }

        public new bool IsCompleted
        {
            get { return base.IsCompleted; }
        }

        public new bool CompletedSynchronously
        {
            get { return base.CompletedSynchronously; }
        }

        public static Message End(IAsyncResult result)
        {
            if (result == null)
            {
                throw new ArgumentNullException("result");
            }
            RequestAsyncResult requestResult = result as RequestAsyncResult;
            if (requestResult == null)
            {
                throw new ArgumentException("Invalid AsyncResult", "result");
            }
            AsyncResult.End(requestResult);

            return requestResult.message;
        }
    }
}
