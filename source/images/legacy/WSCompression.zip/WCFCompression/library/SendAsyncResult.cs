//----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.  All rights reserved.
//--------------------------------------------------------------------------
using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;

namespace Microsoft.ServiceModel.Samples
{
	class SendAsyncResult<TChannel> : AsyncResult
        where TChannel : IOutputChannel
	{
        Message message;
        TimeSpan timeout;
        InterceptorChannelBase<TChannel> channel;

        public SendAsyncResult(InterceptorChannelBase<TChannel> channel, Message message, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.message = message;
            this.channel = channel;

            channel.Interceptor.ProcessSend(ref this.message);
            if (this.message == null)
            {
                channel.OnDropMessage();
                Complete(true);
            }
            else
            {
                channel.InnerChannel.BeginSend(this.message, new AsyncCallback(HandleCallback), null);
            }
        }

        public SendAsyncResult(InterceptorChannelBase<TChannel> channel, Message message, TimeSpan timeout, AsyncCallback callback, object state)
            : base(callback, state)
        {
            this.message = message;
            this.timeout = timeout;
            this.channel = channel;

            channel.Interceptor.ProcessSend(ref this.message);
            if (this.message == null)
            {
                channel.OnDropMessage();
                Complete(true);
            }
            else
            {
                channel.InnerChannel.BeginSend(this.message, timeout, new AsyncCallback(HandleCallback), null);
            }
        }

        void HandleCallback(IAsyncResult asyncResult)
        {
            try
            {
                channel.InnerChannel.EndSend(asyncResult);
                Complete(false);
            }
            catch (Exception e)
            {
                Complete(false, e);
            }
        }

        public new WaitHandle AsyncWaitHandle
        {
            get { return base.AsyncWaitHandle; }
        }

        public new bool IsCompleted
        {
            get { return base.IsCompleted; }
        }

        public new bool CompletedSynchronously
        {
            get { return base.CompletedSynchronously; }
        }

        public static void End(IAsyncResult result)
        {
            if (result == null)
            {
                throw new ArgumentNullException("result");
            }
            SendAsyncResult<TChannel> outputResult = result as SendAsyncResult<TChannel>;
            if (outputResult == null)
            {
                throw new ArgumentException("Invalid AsyncResult", "result");
            }
            AsyncResult.End(outputResult);
        }
    }
}
