﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Messages
{
	[DataContract(Name = "link")]
	public class Link
	{
		[DataMember(Name = "href")]
		public string Href { get; set; }

		[DataMember(Name = "rel")]
		public string Rel { get; set; }

		[DataMember(Name = "type")]
		public string Type { get; set; }
	}
}
