﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;
using Microsoft.IdentityModel.Claims;
using System.Threading;

public class Service : IService
{
	public Atom10FeedFormatter EchoClaims()
	{
		IClaimsIdentity identity = (IClaimsIdentity)Thread.CurrentPrincipal.Identity;

		var feed = new SyndicationFeed()
		{
			Id = "http://Claims",
			Title = new TextSyndicationContent("My claims"),
		};

		feed.Items = identity.Claims.Select(c =>
			new SyndicationItem()
			{
				Id = Guid.NewGuid().ToString(),
				Title = new TextSyndicationContent(c.ClaimType),
				LastUpdatedTime = DateTime.UtcNow,
				Authors = 
			{ 
				new SyndicationPerson() 
				{
					Name = c.Issuer
				}
			},
				Content = new TextSyndicationContent(c.Value)
			}
		);

		WebOperationContext.Current.OutgoingResponse.ContentType = "application/atom+xml";
		return feed.GetAtom10Formatter();
	}
}
