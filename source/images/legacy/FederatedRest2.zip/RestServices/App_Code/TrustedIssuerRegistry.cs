﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens;


/// <summary>
/// Implements an IssuerNameRegistry that checks the given Issuer Token
/// to validated if it is trusted. If the token is trusted it returns a 
/// name for the issuer.
/// </summary>
public class TrustedIssuerNameRegistry : IssuerNameRegistry
{
	public override string GetIssuerName(SecurityToken securityToken)
	{
		X509SecurityToken x509Token = securityToken as X509SecurityToken;
		if (x509Token != null)
		{
			//
			// WARNING: This demonstrates a simple implementation that just checks the 
			// certificate subject name. In production systems this might look up the 
			// certificate in a database(of trusted certificates) and might do additional 
			// validation like checking the certificate for revocation.
			//
			// DO NOT use this sample code 'as is' in production code.
			//
			if (String.Equals(x509Token.Certificate.SubjectName.Name, "CN=localhost"))
			{
				return "RestSts";
			}
		}

		throw new SecurityTokenException("Untrusted issuer.");
	}
}

