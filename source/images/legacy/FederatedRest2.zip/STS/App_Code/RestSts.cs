﻿using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using System.Threading;
using System.Xml;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.SecurityTokenService;
using Microsoft.IdentityModel.Tokens;
using Microsoft.ServiceModel.Web;

[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
public class RestSts : IRestSts
{
	ITokenRepository repository = new InMemoryTokenRepository();
	
	[WebHelp(Comment = "Issues a new security token")]
	public Messages.RequestSecurityTokenResponse IssueToken(Messages.RequestSecurityToken requestMessage)
	{
		var configuration = new SecurityTokenServiceConfiguration(Constants.StsName);

		// Create the STS.
		var sts = new CustomSecurityTokenService(configuration);

		// Create RST from the request
		var request = new RequestSecurityToken(Constants.RequestTypes.Issue);
		request.AppliesTo = new EndpointAddress(requestMessage.AppliesTo);
		request.TokenType = requestMessage.TokenType;

		if (requestMessage.ClaimRequirements != null)
		{
			foreach (var claimType in requestMessage.ClaimRequirements)
			{
				request.Claims.Add(new RequestClaim(claimType.Uri, claimType.IsOptional));
			}
		}

		// Get RSTR from the STS.
		var response = sts.Issue(ClaimsPrincipal.CreateFromPrincipal(Thread.CurrentPrincipal), request);

		var securityToken = ExtractToken(configuration, response);

		var handler = configuration.SecurityTokenHandlers[securityToken];

		var responseMessage = new Messages.RequestSecurityTokenResponse();
		responseMessage.TokenType = requestMessage.TokenType;
		responseMessage.RequestedSecurityToken = SerializeToken(handler, securityToken);
		responseMessage.Links = new List<Messages.Link>();
		responseMessage.Links.Add(
			new Messages.Link
			{
				Type = Constants.ContentTypes.ApplicationXml,
				Href = FormatUri(securityToken.Id),
				Rel = Constants.LinkTypes.Self
			}
		);

		repository.Add(Thread.CurrentPrincipal.Identity, securityToken);
		
		return responseMessage;
	}

	public Messages.RequestSecurityTokenResponse RenewToken(string tokenId)
	{
		var configuration = new SecurityTokenServiceConfiguration(Constants.StsName);

		// Create the STS.
		var sts = new CustomSecurityTokenService(configuration);

		var existingToken = repository[Thread.CurrentPrincipal.Identity, tokenId];

		var handler = configuration.SecurityTokenHandlers[existingToken];

		// Create RST from the request
		var request = new RequestSecurityToken(Constants.RequestTypes.Renew);
		request.TokenType = handler.TokenTypeIdentifier;
		request.RenewTarget = repository[Thread.CurrentPrincipal.Identity, tokenId];

		var response = sts.Renew(ClaimsPrincipal.CreateFromPrincipal(Thread.CurrentPrincipal), request);

		var securityToken = ExtractToken(configuration, response);

		var responseMessage = new Messages.RequestSecurityTokenResponse();
		responseMessage.TokenType = handler.TokenTypeIdentifier;
		responseMessage.RequestedSecurityToken = SerializeToken(handler, securityToken);
		responseMessage.Links = new List<Messages.Link>();
		responseMessage.Links.Add(
			new Messages.Link
			{
				Type = Constants.ContentTypes.ApplicationXml,
				Href = FormatUri(securityToken.Id),
				Rel = Constants.LinkTypes.Self
			}
		);

		repository[Thread.CurrentPrincipal.Identity, tokenId] = securityToken;

		return responseMessage;
	}

	public void CancelToken(string tokenId)
	{
		var configuration = new SecurityTokenServiceConfiguration(Constants.StsName);

		// Create the STS.
		var sts = new CustomSecurityTokenService(configuration);

		var existingToken = repository[Thread.CurrentPrincipal.Identity, tokenId];

		var handler = configuration.SecurityTokenHandlers[existingToken];

		// Create RST from the request
		var request = new RequestSecurityToken(Constants.RequestTypes.Cancel);
				
		//TODO: No support for CancelTarget in Geneva
		//request.CancelTarget = repository[Thread.CurrentPrincipal.Identity, tokenId];

		var response = sts.Cancel(ClaimsPrincipal.CreateFromPrincipal(Thread.CurrentPrincipal), request);

		repository.Remove(Thread.CurrentPrincipal.Identity, tokenId);
	}

	public Messages.RequestSecurityTokenResponse GetToken(string tokenId)
	{
		var configuration = new SecurityTokenServiceConfiguration(Constants.StsName);

		var securityToken = this.repository[Thread.CurrentPrincipal.Identity, tokenId];

		var handler = configuration.SecurityTokenHandlers[securityToken];
		
		var responseMessage = new Messages.RequestSecurityTokenResponse();
		responseMessage.TokenType = handler.TokenTypeIdentifier;
		responseMessage.RequestedSecurityToken = SerializeToken(handler, securityToken);
		responseMessage.Links = new List<Messages.Link>();
		responseMessage.Links.Add(
			new Messages.Link
			{
				Type = Constants.ContentTypes.ApplicationXml,
				Href = FormatUri(securityToken.Id),
				Rel = Constants.LinkTypes.Self
			}
		);

		return responseMessage;
	}

	private string FormatUri(string segment)
	{
		return WebOperationContext.Current.IncomingRequest.UriTemplateMatch.BaseUri + "/" + segment;
	}
	
	private static SecurityToken ExtractToken(SecurityTokenServiceConfiguration configuration, RequestSecurityTokenResponse response)
	{
		SecurityToken securityToken;

		if (response.RequestedSecurityToken.SecurityToken is EncryptedSecurityToken)
		{
			securityToken = ((EncryptedSecurityToken)response.RequestedSecurityToken.SecurityToken).Token;
		}
		else
		{
			securityToken = response.RequestedSecurityToken.SecurityToken;
		}

		return securityToken;
	}
	
	private static string SerializeToken(SecurityTokenHandler handler, SecurityToken securityToken)
	{
		StringBuilder stringBuilder = new StringBuilder();
		handler.WriteToken(XmlWriter.Create(new StringWriter(stringBuilder),
			new XmlWriterSettings { OmitXmlDeclaration = true }), securityToken);

		return stringBuilder.ToString();
	}
}
