﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IdentityModel.Tokens;
using System.Security.Principal;
using System.Web.Caching;


public interface ITokenRepository
{
	void Add(IIdentity identity, SecurityToken token);
	void Remove(IIdentity identity, string id);

	SecurityToken this[IIdentity identity, string id]
	{
		get; set;
	}
}

public class InMemoryTokenRepository : ITokenRepository
{
	public void Add(IIdentity identity, SecurityToken token)
	{
		HttpContext.Current.Cache.Add(GetCacheKey(identity, token.Id), token,
			null, token.ValidTo, Cache.NoSlidingExpiration, CacheItemPriority.Normal, null);
	}

	public void Remove(IIdentity identity, string id)
	{
		HttpContext.Current.Cache.Remove(GetCacheKey(identity, id));
	}

	public SecurityToken this[IIdentity identity, string id]
	{
		get
		{
			return Get(identity, id);
		}
		set
		{
			Set(identity, id, value);
		}
	}

	private SecurityToken Get(IIdentity identity, string id)
	{
		var token = (SecurityToken)HttpContext.Current.Cache[GetCacheKey(identity, id)];

		if (token == null)
			throw new Exception(string.Format("The token with id {0} does not exist", id));

		return token;
	}

	private void Set(IIdentity identity, string id, SecurityToken securityToken)
	{
		HttpContext.Current.Cache[GetCacheKey(identity, id)] = securityToken;
	}

	private string GetCacheKey(IIdentity identity, string id)
	{
		return identity.Name + id;
	}
}
