﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public static class Constants
{
	public const string StsName = "RestSts";

	public static class RequestTypes
	{
		public const string Issue = "http://schemas.microsoft.com/idfx/requesttype/issue";
		public const string Renew = "Renew";
		public const string Cancel = "Cancel";
	}

	public static class ContentTypes
	{
		public const string ApplicationXml = "application/xml";
	}

	public static class LinkTypes
	{
		public const string Self = "self";
	}
}
