using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Xml.Linq;
using System.Security.Cryptography.X509Certificates;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.SecurityTokenService;
using System.Collections;
using System.IdentityModel.Tokens;
using System.Collections.Generic;
using System.Security.Principal;
using System.ServiceModel;


/// <summary>
/// Summary description for MySecurityTokenService
/// </summary>
public class CustomSecurityTokenService : SecurityTokenService
{
	const string SigningCertificateName = "CN=localhost";
	const string EncryptingCertificateName = "CN=localhost";
	const string AddressExpected = "http://localhost:7397/RestServices/Service.svc/Claims";

	SigningCredentials signingCredentials;
	EncryptingCredentials encryptingCredentials;

	public CustomSecurityTokenService(SecurityTokenServiceConfiguration configuration)
		: base(configuration)
	{
		// Setup our certificate the STS is going to use to sign the issued tokens
		signingCredentials = new X509SigningCredentials(CertificateUtil.GetCertificate(StoreName.My, StoreLocation.LocalMachine, SigningCertificateName));

		// We only support a single RP identity represented by the _encryptingCreds
		encryptingCredentials = new X509EncryptingCredentials(CertificateUtil.GetCertificate(StoreName.My, StoreLocation.LocalMachine, EncryptingCertificateName));
	}


	/// <summary>
	/// This methods returns the configuration for the token issuance request. The configuration
	/// is represented by the Scope class. In our case, we are only capable to issue a token for a
	/// single RP identity represented by the _encryptingCreds field.
	/// </summary>
	/// <param name="principal">The caller's principal</param>
	/// <param name="request">The incoming RST</param>
	/// <returns>The scope.</returns>
	protected override Scope GetScope(IClaimsPrincipal principal, RequestSecurityToken request)
	{
		ValidateAppliesTo(request.AppliesTo);

		// Create the scope using the request AppliesTo address and the RP identity
		Scope scope = new Scope(request, signingCredentials);
		scope.EncryptingCredentials = encryptingCredentials;

		return scope;
	}

	/// <summary>
	/// This methods returns the claims to be included in the issued token encapsulated by an IClaimsIdentity.
	/// </summary>
	/// <param name="principal">The caller's principal.</param>
	/// <param name="request">The incoming RST, we don't use this in our implementation.</param>
	/// <param name="scope">The scope that was previously returned by GetScope method.</param>
	/// <returns>The claims to be included in the issued token encapsulated by an IClaimsIdentity.</returns>
	protected override IClaimsIdentity GetOutputClaimsIdentity(IClaimsPrincipal principal, RequestSecurityToken request, Scope scope)
	{
		IClaimsIdentity outputIdentity = new ClaimsIdentity();

		// value filter
		outputIdentity.Claims.Add(new Claim(System.IdentityModel.Claims.ClaimTypes.Name, principal.Identity.Name));

		// new claim type
		outputIdentity.Claims.Add(new Claim("http://MyClaim/2008/05/AgeClaim", "25", ClaimValueTypes.Integer));

		return outputIdentity;
	}

	/// <summary>
	/// Validates the appliesTo and throws an exception if the appliesTo is null or appliesTo contains some unexpected address.  
	/// </summary>
	void ValidateAppliesTo(EndpointAddress appliesTo)
	{
		if (appliesTo == null)
		{
			throw new InvalidRequestException("The appliesTo is null.");
		}

		if (!appliesTo.Uri.Equals(new Uri(AddressExpected)))
		{
			throw new InvalidRequestException(String.Format("The relying party address is not valid. Expected value is {0}, the actual value is {1}.", AddressExpected, appliesTo.Uri.AbsoluteUri));
		}
	}

}

