﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Http;
using Messages;
using System.Runtime.Serialization;
using System.Net;

namespace ClientConsole
{
	public class NegociateTokenStage : HttpWebRequestTransportStage
	{
		private string stsUri = "";

		public NegociateTokenStage(string stsUri) : base()
		{
			this.stsUri = stsUri;
		}
		
		protected override void ProcessRequestAndTryGetResponse(HttpRequestMessage request, out HttpResponseMessage response, out object state)
		{
			string token = GetToken(stsUri, request.Uri.AbsoluteUri, this.Settings.Credentials);
			
			request.Headers.Add("Authorization", token);
			
			base.ProcessRequestAndTryGetResponse(request, out response, out state);
		}

		string GetToken(string address, string appliesTo, ICredentials credentials)
		{
			RequestSecurityToken request = new RequestSecurityToken
			{
				TokenType = "http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1",
				AppliesTo = appliesTo
			};
			
			DataContractSerializer requestSerializer = new DataContractSerializer(typeof(RequestSecurityToken));

			HttpClient client = new HttpClient();
			client.TransportSettings.Credentials = credentials;
			HttpResponseMessage response = client.Post(stsUri, "application/xml", 
				HttpContent.Create(s => requestSerializer.WriteObject(s, request)));
			
			RequestSecurityTokenResponse rstr = response.Content.ReadAsDataContract<RequestSecurityTokenResponse>();
			return rstr.RequestedSecurityToken;
		}
	}
}
