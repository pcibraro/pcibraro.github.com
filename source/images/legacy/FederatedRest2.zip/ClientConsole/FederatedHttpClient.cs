﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Http;

namespace ClientConsole
{
public class FederatedHttpClient : HttpClient
{
	public string StsUri
	{
		get; set;
	}

	protected override HttpStage CreateTransportStage()
	{
		NegociateTokenStage stage = new NegociateTokenStage(this.StsUri);
		stage.Settings = this.TransportSettings;

		return stage;
	}
}
}
