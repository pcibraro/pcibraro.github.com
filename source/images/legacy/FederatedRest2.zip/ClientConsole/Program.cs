﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.IdentityModel.Web;
using Microsoft.IdentityModel.Protocols.WSFederation;
using System.Net;
using System.IO;
using System.Runtime.Serialization;
using Messages;
using System.Xml;
using Microsoft.Http;

namespace ClientConsole
{
	class Program
	{
		static void Main(string[] args)
		{
			FederatedHttpClient client = new FederatedHttpClient { StsUri = "http://localhost:7481/STS/Service.svc/Tokens" };
			client.TransportSettings.Credentials = new NetworkCredential("cibrax", "foo");

			string response = client.Get("http://localhost:7397/RestServices/Service.svc/Claims").Content.ReadAsString();

			Console.WriteLine(response);
		}
	}
}
