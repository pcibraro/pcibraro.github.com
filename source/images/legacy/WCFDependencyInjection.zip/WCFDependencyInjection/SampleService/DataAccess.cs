using System;
using System.Collections.Generic;
using System.Text;

namespace SampleService
{
	public interface ICustomerDataAccess
	{
		string GetFullName(string customerId);
	}

	public class CustomerDataAccess : ICustomerDataAccess
	{
		public CustomerDataAccess()
		{
		}

		public string GetFullName(string customerId)
		{
			return "FOO";
		}
	}
}
