using System;
using System.ServiceModel;

namespace SampleService
{
	[ServiceContract(Namespace = "http://Microsoft.ServiceModel.Samples")]
	public interface ICustomer
	{
		[OperationContract]
		string GetFullName(string customerId);
	}

	public class CustomerService : ICustomer
	{
		ICustomerBusinessComponent businessComponent;

		public CustomerService(ICustomerBusinessComponent businessComponent)
		{
			this.businessComponent = businessComponent;
		}

		public string GetFullName(string customerId)
		{
			return businessComponent.GetFullName(customerId);
		}
		
	}
}
