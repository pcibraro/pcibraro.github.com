using System;
using System.Collections.Generic;
using System.Text;

namespace SampleService
{
	public interface ICustomerBusinessComponent
	{
		string GetFullName(string customerId);
	}

	public class CustomerBusinessComponent : ICustomerBusinessComponent
	{
		ICustomerDataAccess dataAccess;

		public CustomerBusinessComponent(ICustomerDataAccess dataAccess)
		{
			this.dataAccess = dataAccess;
		}

		#region ICustomerBusinessComponent Members

		public string GetFullName(string customerId)
		{
			return dataAccess.GetFullName(customerId);
		}

		#endregion
	}
}
