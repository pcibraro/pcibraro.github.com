using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;

namespace SampleService
{
	class Program
	{
		static void Main()
		{
			ServiceHost host = null;
			try
			{
				host = new ServiceHost(typeof(CustomerService));

				host.Open();

				// Create a client with given client endpoint configuration
				ChannelFactory<ICustomer> channelFactory = new ChannelFactory<ICustomer>("client");
				ICustomer client = channelFactory.CreateChannel();

				Console.WriteLine("Customer Full Name {0}", client.GetFullName("Id"));

				//Closing the client gracefully closes the connection and cleans up resources
				channelFactory.Close();

				Console.WriteLine();
				Console.WriteLine("Press <ENTER> to terminate client.");
				Console.ReadLine();

				Console.WriteLine("\n+++ press any key to close a ServiceHost +++\n");
				Console.ReadLine();

				host.Close();
			}
			catch (CommunicationException ex)
			{
				if (host != null)
					host.Abort();

				Console.WriteLine(ex.Message);
				Console.ReadLine();
			}
			catch (Exception ex)
			{
				if (host != null)
					host.Abort();

				Console.WriteLine(ex);
				Console.ReadLine();
			}
			finally
			{
				Console.WriteLine("\n*** press any key to exit ... ***\n");
				Console.ReadLine();
			}


		}
	}
}
