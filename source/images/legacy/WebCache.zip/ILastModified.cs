﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Syndication;

namespace Microsoft.ServiceModel.Web 
{
public interface ILastModified
{
	DateTime? GetLastModifiedForOutput(object[] outputs, object returnValue);
}

	public class SyndicationLastModified : ILastModified
	{
		public DateTime? GetLastModifiedForOutput(object[] outputs, object returnValue)
		{
			if(returnValue is SyndicationFeedFormatter)
			{
				var formatter = (SyndicationFeedFormatter)returnValue;
				return formatter.Feed.LastUpdatedTime.UtcDateTime;
			}

			return null;

		}
	}

	public class CurrentDateLastModified : ILastModified
	{
		public DateTime? GetLastModifiedForOutput(object[] outputs, object returnValue)
		{
			return DateTime.Now;
		}
	}
}
