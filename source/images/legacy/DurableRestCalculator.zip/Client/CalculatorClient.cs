﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace DurableServiceClient
{
	[ServiceContract(Namespace = "http://Microsoft.WorkflowServices.Samples")]
	public interface ICalculator
	{
		[OperationContract()]
		[WebInvoke(Method = "POST")]
		int PowerOn();

		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "add")]
		int Add(int value);

		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "subtract")]
		int Subtract(int value);

		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "multiply")]
		int Multiply(int value);

		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "divide")]
		int Divide(int value);

		[OperationContract()]
		[WebInvoke(Method = "DELETE")]
		void PowerOff();
	}  

	public interface ICalculatorChannel : ICalculator, System.ServiceModel.IClientChannel
	{
	}

	[System.Diagnostics.DebuggerStepThroughAttribute()]
	public partial class CalculatorClient : System.ServiceModel.ClientBase<ICalculator>, ICalculator
	{

		public CalculatorClient()
		{
		}

		public CalculatorClient(string endpointConfigurationName) :
			base(endpointConfigurationName)
		{
		}

		public CalculatorClient(string endpointConfigurationName, string remoteAddress) :
			base(endpointConfigurationName, remoteAddress)
		{
		}

		public CalculatorClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
			base(endpointConfigurationName, remoteAddress)
		{
		}

		public CalculatorClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
			base(binding, remoteAddress)
		{
		}

		public int PowerOn()
		{
			return base.Channel.PowerOn();
		}

		public int Add(int value)
		{
			return base.Channel.Add(value);
		}

		public int Subtract(int value)
		{
			return base.Channel.Subtract(value);
		}

		public int Multiply(int value)
		{
			return base.Channel.Multiply(value);
		}

		public int Divide(int value)
		{
			return base.Channel.Divide(value);
		}

		public void PowerOff()
		{
			base.Channel.PowerOff();
		}
	}
}
