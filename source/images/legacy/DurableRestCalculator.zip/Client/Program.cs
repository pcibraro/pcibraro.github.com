﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Diagnostics;

namespace DurableServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press Return when service is ready");
            Console.ReadLine();
            CalculatorClient proxy = new CalculatorClient();

            Console.WriteLine("Powering On");
            Debug.Assert(proxy.PowerOn() == 0);

            Console.WriteLine("Adding 10");
            Console.WriteLine("Expected Result: 10 - Final Result: " + proxy.Add(10));

            Console.WriteLine("Subtracting 5");
            Console.WriteLine("Expected Result 5 - Final Result: " + proxy.Subtract(5));

			Console.WriteLine("Multiple 3");
			Console.WriteLine("Expected Result 15 - Final Result: " + proxy.Multiply(3));

            Console.WriteLine("Powering Off");
            proxy.PowerOff();
        }
    }
}
