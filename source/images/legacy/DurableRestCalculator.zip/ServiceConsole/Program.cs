﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel;

namespace ServiceConsole
{
	class Program
	{
		static void Main(string[] args)
		{
			ServiceHost host = new ServiceHost(typeof(DurableCalculator), new Uri("http://localhost:8080/DurableCalculator"));
			host.Open();

			Console.WriteLine("Press <enter> to exit");
			Console.ResetColor();
			Console.ReadLine();

			host.Close();


		}
	}
}
