﻿using System;
using System.ServiceModel.Description;
using System.ServiceModel;

namespace ServiceConsole
{
    [Serializable]
    [DurableService]
    public class DurableCalculator : ICalculator
    {
        int _currentValue = 0;

        [DurableOperation(CanCreateInstance=true)]
        public int PowerOn()
        {
            
			return _currentValue;
        }

        [DurableOperation]
        public int Add(int value)
        {
            return (_currentValue += value);
        }

        [DurableOperation]
        public int Subtract(int value)
        {
            return (_currentValue -= value);
        }

        [DurableOperation]
        public int Multiply(int value)
        {
            return (_currentValue *= value);
        }

        [DurableOperation]
        public int Divide(int value)
        {
            return (_currentValue /= value);
        }

        [DurableOperation(CompletesInstance=true)]
        public void PowerOff()
        {
        }
    }
}
