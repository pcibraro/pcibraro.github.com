﻿using System.ServiceModel;
using System.ServiceModel.Web;

namespace ServiceConsole
{
    [ServiceContract(Namespace = "http://Microsoft.WorkflowServices.Samples")]
    public interface ICalculator
    {
        [OperationContract()]
		[WebInvoke(Method = "POST")]
		int PowerOn();
        
		[OperationContract()]
        [WebInvoke(Method = "PUT", UriTemplate = "add")]
		int Add(int value);
        
		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "subtract")]
		int Subtract(int value);
        
		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "multiply")]
		int Multiply(int value);
        
		[OperationContract()]
		[WebInvoke(Method = "PUT", UriTemplate = "divide")]
		int Divide(int value);
        
		[OperationContract()]
		[WebInvoke(Method = "DELETE")]
		void PowerOff();
    }  
}
