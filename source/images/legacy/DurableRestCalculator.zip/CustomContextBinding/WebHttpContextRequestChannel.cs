using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
    class WebHttpContextRequestChannel : WebHttpContextChannelBase, IRequestChannel
    {
		private ContextProtocol contextProtocol;

		IRequestChannel innerRequestChannel;

        public WebHttpContextRequestChannel(ChannelManagerBase channelManager, IRequestChannel innerChannel)
            : base(channelManager, innerChannel)
        {
            this.innerRequestChannel = innerChannel;
            this.endpointAddress = innerChannel.RemoteAddress;
			this.contextProtocol = new ClientContextProtocol(innerChannel.Via, this);
        }

        public IAsyncResult BeginRequest(Message message, TimeSpan timeout,
            AsyncCallback callback, object state)
        {
			this.contextProtocol.OnOutgoingMessage(message, null);
			return this.innerRequestChannel.BeginRequest(message, callback, state);
        }

        public IAsyncResult BeginRequest(Message message, AsyncCallback callback,
            object state)
        {
            return BeginRequest(message, DefaultSendTimeout, callback, state);
        }

        public Message EndRequest(IAsyncResult result)
        {
			Message message = this.innerRequestChannel.EndRequest(result);
			if (message != null)
			{
				this.contextProtocol.OnIncomingMessage(message);
			}
			return message;
        }

		public override T GetProperty<T>()
        {
            if ((typeof(T) == typeof(IContextManager)) && (this.contextProtocol is IContextManager))
            {
                return (T) (object)this.contextProtocol;
            }

			T property = base.GetProperty<T>();
			if (property != null)
			{
				return property;
			}
			return this.innerRequestChannel.GetProperty<T>();
        }

        public EndpointAddress RemoteAddress
        {
            get
            {
                return innerRequestChannel.RemoteAddress;
            }
        }

        public Message Request(Message message, TimeSpan timeout)
        {
			this.contextProtocol.OnOutgoingMessage(message, null);
			Message message2 = this.innerRequestChannel.Request(message);
			if (message2 != null)
			{
				this.contextProtocol.OnIncomingMessage(message2);
			}
			return message2;
        }

        public Message Request(Message message)
        {
            return Request(message, DefaultSendTimeout);
        }

        public Uri Via
        {
            get
            {
                return innerRequestChannel.Via;
            }
        }
    }
}
