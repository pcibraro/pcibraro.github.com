﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Net;
using System.Xml;
using System.IO;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Collections.Specialized;

namespace Microsoft.ServiceModel.Samples
{
	internal class ServiceContextProtocol : ContextProtocol
	{
		public ServiceContextProtocol(ContextMode contextMode, NameValueCollection uriTemplates)
		{
			this.ContextMode = contextMode;
			this.UriTemplates = uriTemplates;
		}

		public ContextMode ContextMode
		{
			get;
			private set;
		}

		public NameValueCollection UriTemplates
		{
			get;
			private set;
		}

		public override void OnIncomingMessage(Message message)
		{
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}
			
			this.OnReceiveMessage(message);
		}

		public override void OnOutgoingMessage(Message message, System.ServiceModel.Channels.RequestContext requestContext)
		{
			ContextMessageProperty property;
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}

			if (ContextMode == ContextMode.HttpHeader)
			{
				if (ContextMessageProperty.TryGet(message, out property))
				{
					OnSendMessage(message, property);
				}
			}
		}

		private void OnReceiveMessage(Message message)
		{
			if (ContextMode == ContextMode.UriTemplate)
			{
				Uri prefix = new Uri(message.Headers.To.Scheme + "://" + message.Headers.To.Authority);
				
				UriTemplateTable table = new UriTemplateTable(prefix);
				foreach (string key in this.UriTemplates)
				{
					System.UriTemplate uriTemplate = new UriTemplate(this.UriTemplates[key]);
					table.KeyValuePairs.Add(new KeyValuePair<UriTemplate, object>(uriTemplate, key));
				}

				
				UriTemplateMatch results = table.MatchSingle(message.Headers.To);
				if (results != null && results.BoundVariables.Count > 0)
				{
					Dictionary<string, string> context = new Dictionary<string, string>();
					
					foreach (string key in results.BoundVariables.Keys)
					{
						//Hack: Ugly hack!!!, BoundVariables always return names in Upper Case but
						// the context manager only accept keys with exact casing.
						if (key.ToLower() == "instanceid")	  
						{
							context.Add("instanceId", results.BoundVariables[key]);
						}
						else if (key.ToLower() == "conversationid")
						{
							context.Add("conversationId", results.BoundVariables[key]);
						}
						else
						{
							context.Add(key, results.BoundVariables[key]);
						}
					}

					ContextMessageProperty property = new ContextMessageProperty(context);
					property.AddOrReplaceInMessage(message);
				}
			}
			else
			{
			
				object value;
				if (message.Properties.TryGetValue(HttpRequestMessageProperty.Name, out value))
				{
					HttpRequestMessageProperty requestProperty = value as HttpRequestMessageProperty;
					if (requestProperty != null)
					{
						ContextMessageProperty property;
						string str = requestProperty.Headers["WscContext"];
						if (!string.IsNullOrEmpty(str) && TryCreateFromHttpHeader(str, out property))
						{
							property.AddOrReplaceInMessage(message);
						}
						
					}
				}
			}
		}

		private void OnSendMessage(Message message, ContextMessageProperty context)
		{
			object value;
			HttpResponseMessageProperty httpProperty = null;
			if (message.Properties.TryGetValue(HttpResponseMessageProperty.Name, out value))
			{
				httpProperty = value as HttpResponseMessageProperty;
			}
			if (httpProperty == null)
			{
				httpProperty = new HttpResponseMessageProperty();
				message.Properties.Add(HttpResponseMessageProperty.Name, httpProperty);
			}
			string str = EncodeContextAsHttpHeader(context);
			httpProperty.Headers.Add("WscContext", str);
		}

		private bool TryCreateFromHttpHeader(string httpHeader, out ContextMessageProperty context)
		{
			if (httpHeader == null)
				throw new ArgumentNullException("httpHeader");

			try
			{
				context = ContextMessageHeader.ParseContextHeader(XmlReader.Create(new MemoryStream(Convert.FromBase64String(httpHeader))));
			}
			catch (SerializationException exception)
			{
				throw;
			}
			catch (ProtocolException exception2)
			{
				throw;
			}

			return (context != null);
		}

		private string EncodeContextAsHttpHeader(ContextMessageProperty context)
		{
			if (context == null)
			{
				throw new ArgumentNullException("context");
			}
			
			MemoryStream output = new MemoryStream();
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.OmitXmlDeclaration = true;
			XmlWriter writer = XmlWriter.Create(output, settings);
			new ContextMessageHeader(context.Context).WriteHeader(writer, MessageVersion.Default);
			writer.Flush();

			return Convert.ToBase64String(output.GetBuffer(), 0, (int)output.Length);
		}
	}
}
