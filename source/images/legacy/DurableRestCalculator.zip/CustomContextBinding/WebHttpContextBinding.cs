﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.Collections.Specialized;

namespace Microsoft.ServiceModel.Samples
{
	public class WebHttpContextBinding : WebHttpBinding
	{
		public WebHttpContextBinding() : base()
		{
			this.UriTemplates = new NameValueCollection();
		}

		public ContextMode ContextMode
		{
			get;
			set;
		}

		public NameValueCollection UriTemplates
		{
			get;
			private set;
		}
		
		public override BindingElementCollection CreateBindingElements()
		{
			BindingElementCollection elements = base.CreateBindingElements();
			elements.Insert(0, new WebHttpContextBindingElement(this.ContextMode, this.UriTemplates));

			return elements;
		}
	}
}
