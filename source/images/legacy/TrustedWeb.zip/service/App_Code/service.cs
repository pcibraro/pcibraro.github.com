
using System;
using System.ServiceModel;
using System.Collections;
using System.Collections.Generic;
using System.Security.Principal;

namespace Microsoft.ServiceModel.Samples
{
    // Define a service contract.
    [ServiceContract(Namespace="http://Microsoft.ServiceModel.Samples")]
    public interface ICalculator
    {
        [OperationContract]
        string GetCallerIdentity();
        [OperationContract]
        double Add(double n1, double n2);
        [OperationContract]
        double Subtract(double n1, double n2);
        [OperationContract]
        double Multiply(double n1, double n2);
        [OperationContract]
        double Divide(double n1, double n2);
    }

    // Service class which implements the service contract.
    // Added code to access identity of incoming certificate
    public class CalculatorService : ICalculator
    {

        public string GetCallerIdentity()
        {
            // The client certificate is not mapped to a Windows identity by default
            // ServiceSecurityContext.PrimaryIdentity is populated based on the information
            // in the certificate that the client used to authenticate itself to the service
			object list;
			if (ServiceSecurityContext.Current.AuthorizationContext.Properties.TryGetValue("Identities", out list))
			{
				IList<IIdentity> identities = (IList<IIdentity>) list;
				
				if (identities.Count > 0)
				{
					return identities[0].Name;
				}
			}

			return String.Empty;
        }

        public double Add(double n1, double n2)
        {
            double result = n1 + n2;
            return result;
        }

        public double Subtract(double n1, double n2)
        {
            double result = n1 - n2;
            return result;
        }

        public double Multiply(double n1, double n2)
        {
            double result = n1 * n2;
            return result;
        }

        public double Divide(double n1, double n2)
        {
            double result = n1 / n2;
            return result;
        }
    }

}
