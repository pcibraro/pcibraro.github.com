using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using System.Configuration;
using System.ServiceModel.Security.Tokens;

namespace TrustedWebExtension
{
	/// <summary>
	/// Binding for trusted web scenarios
	/// </summary>
	public class TrustedWebClientBinding : Binding
	{
		CustomBinding customBinding;

		public TrustedWebClientBinding()
			: base()
		{
		}

		/// <summary>
		/// Reference to the custom binding in the security file
		/// </summary>
		public CustomBinding Binding
		{
			get { return customBinding; }
			set { customBinding = value; }
		}

		public override BindingElementCollection CreateBindingElements()
		{
			return AddUserNameSupportingTokenToBinding(Binding);
		}

		public override string Scheme
		{
			get 
			{    
				TransportBindingElement element = Binding.Elements.Find<TransportBindingElement>();
				if (element == null)
				{
					return string.Empty;
				}
				return element.Scheme;
			}
 		}

		private BindingElementCollection AddUserNameSupportingTokenToBinding(Binding binding)
		{
			BindingElementCollection elements = binding.CreateBindingElements();

			SecurityBindingElement security = elements.Find<SecurityBindingElement>();
			if (security != null)
			{
				UserNameSecurityTokenParameters tokenParameters = new UserNameSecurityTokenParameters();
				tokenParameters.InclusionMode = SecurityTokenInclusionMode.AlwaysToRecipient;
				tokenParameters.RequireDerivedKeys = false;
				security.EndpointSupportingTokenParameters.SignedEncrypted.Add(tokenParameters);

				return elements;
			}

			throw new ArgumentException("Unexisting security binding element");
		}
	}

	/// <summary>
	/// Configuration element
	/// </summary>
	public class TrustedWebClientBindingElement : StandardBindingElement
	{
		public TrustedWebClientBindingElement()
		{
		}

		/// <summary>
		/// Name of the custom binding that defines the mutual certificate authentication scenario.
		/// </summary>
		[ConfigurationProperty("bindingReference", IsRequired = true)]
		public string BindingReference
		{
			get { return (string)base["bindingReference"]; }
		}

		protected override void OnApplyConfiguration(Binding binding)
		{
			TrustedWebClientBinding trustedWebClient = (TrustedWebClientBinding)binding;

			BindingsSection bindings = (BindingsSection)ConfigurationManager.GetSection("system.serviceModel/bindings");

			if (bindings == null)
			{
				throw new ConfigurationErrorsException("Unexisting bindings section");
			}

			if(!bindings.CustomBinding.Bindings.ContainsKey(this.BindingReference))
				throw new ConfigurationErrorsException(string.Format("Unexisting binding configuration {0}", this.BindingReference));

			CustomBindingElement element = bindings.CustomBinding.Bindings[this.BindingReference];

			trustedWebClient.Binding = new CustomBinding();
			element.ApplyConfiguration(trustedWebClient.Binding);
		}

		protected override Type BindingElementType
		{
			get { return typeof(TrustedWebClientBinding); }
		}

		protected override ConfigurationPropertyCollection Properties
		{
			get
			{
				ConfigurationPropertyCollection properties = base.Properties;
				properties.Add(new ConfigurationProperty("bindingReference", typeof(string), null, ConfigurationPropertyOptions.IsRequired));
				return properties;
			}
		}

	}

	public class TrustedBindingCollectionElement : StandardBindingCollectionElement<TrustedWebClientBinding, TrustedWebClientBindingElement>
	{
	}
}
