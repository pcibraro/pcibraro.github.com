using System;
using System.Collections.Generic;
using System.Text;

using System.IdentityModel.Selectors;
using System.ServiceModel;

namespace TrustedWebExtension
{
	/// <summary>
	/// Allows empty passwords for the username tokens. This validator is used in the TrustedWeb scenario.
	/// </summary>
    public class UsernameBlankPasswordValidator : UserNamePasswordValidator
    {
		public override void Validate(string userName, string password)
        {
			UserNamePasswordValidator.None.Validate(userName, password);
        }
    }
}
