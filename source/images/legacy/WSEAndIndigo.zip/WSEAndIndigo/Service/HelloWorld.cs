using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

using System.Xml;
using System.Runtime.Serialization;
using System.ServiceModel;



namespace Service
{
    [MessageContract()]
    public class HelloWorldRequest
    {
        [MessageBody(Name = "Message", Namespace = "http://HelloWorld")]
        public string Message;
    }

    [MessageContract()]
    public class HelloWorldResponse
    {
        [MessageBody(Name = "ReturnValue", Namespace = "http://HelloWorld")]
        public string ReturnValue;
    }
            
    [ServiceContract(Namespace="http://HelloWorld")]
    interface IHelloWorld
    {
        [OperationContract(Action="HelloWorldRequest", ReplyAction="HelloWorldResponse")] 
        HelloWorldResponse HelloWorld(HelloWorldRequest message);
    }

       
    class HelloWorldService : IHelloWorld
    {
        #region IHelloWorld Members

        public HelloWorldResponse HelloWorld(HelloWorldRequest request)
        {
            HelloWorldResponse response = new HelloWorldResponse();
            response.ReturnValue = "Hello World" + request.Message;

            return response;
        }
        
        #endregion
    }
}
