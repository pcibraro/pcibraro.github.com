using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.ServiceModel.Security.Tokens; 

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ServiceHost host = new ServiceHost(typeof(HelloWorldService), new Uri[] { new Uri("http://localhost:8080/Samples/HelloWorldService") });
                
                host.Open();
                
                Console.WriteLine("Listening....");
                Console.ReadLine();

                host.Close();
                host.Dispose();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString()); 
            }
            
        }
       
    }
}
