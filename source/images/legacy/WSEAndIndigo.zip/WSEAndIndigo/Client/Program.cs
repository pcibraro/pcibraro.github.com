using System;
using System.Collections.Generic;
using System.Text;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                localhost.HelloWorldServiceWse service = new Client.localhost.HelloWorldServiceWse();
                service.SetPolicy("ClientPolicy");

                Console.WriteLine(service.HelloWorld("John Doe"));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString()); 
            }
        }

        

       


    }


}
