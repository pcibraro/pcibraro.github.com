WSPolling for WSE 3.0

Prerequisites:
- Windows Server 2003, or Windows XP with Internet Information Server (IIS)
- Microsoft .NET Framework Version 2.0
- WSE 3.0 RTM

Installation instructions:

1. Run the SetupVdir.vbs script to install all Web applications.
2. Run the SQL script "database.sql" against a SQL server instance to create the database used by this sample
3. Check the connection string in the following file Service/Web.config

<connectionStrings>
    <add name="Messages" connectionString="Data source=localhost;Initial Catalog=WSEPolling;User id=WSEPolling;password=password" />
</connectionStrings>