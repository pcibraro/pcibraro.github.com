using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Messaging;

namespace WSEPolling
{
    public class PollingClient : SoapClient
    {
        public PollingClient(Uri destination)
            : base(destination)
        {
        }

        public Uri InvokeService(string action, object bodyObject)
        {
            return InvokeService(action, bodyObject, null);
        }

        public Uri InvokeService(string action, object bodyObject, string targetNamespace)
        {
            SoapEnvelope envelope = new SoapEnvelope(this.SoapVersion);

            if (targetNamespace != null)
            {
                envelope.SetBodyObject(bodyObject, targetNamespace);
            }
            else
            {
                envelope.SetBodyObject(bodyObject);
            }

            envelope.Context.Addressing.ReplyTo = new Microsoft.Web.Services3.Addressing.ReplyTo(new Uri("http://www.w3.org/2005/08/ws-polling/HoldResponse"));
            
            this.SendOneWay(action, envelope);

            return envelope.Context.Addressing.MessageID.Value;
        }

        public SoapEnvelope GetMessage(GetMessageRequest request)
        {
            return this.SendRequestResponse(WSPolling.Actions.GetMessage, request); 
        }

        public object GetMessageBody(GetMessageRequest request, Type responseBodyType, string responseTargetNamespace)
        {
            SoapEnvelope response = this.SendRequestResponse(WSPolling.Actions.GetMessage, request);
            
            return response.GetBodyObject(responseBodyType, responseTargetNamespace);
        }
                
    }
}
