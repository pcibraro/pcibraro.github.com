using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using Microsoft.Web.Services3;

namespace WSEPolling
{
    interface IMessageStore
    {
        void Init(XmlElement configuration);

        void StoreRequest(SoapEnvelope request);
        
        void StoreResponse(SoapEnvelope response);
                
        SoapEnvelope GetResponse(GetMessageRequest request);
    }
}
