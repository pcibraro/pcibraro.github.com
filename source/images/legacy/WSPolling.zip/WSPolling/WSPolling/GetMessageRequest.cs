using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services3.Xml;
using Microsoft.Web.Services3.Addressing;

namespace WSEPolling
{
    [XmlRootAttribute(Namespace = WSPolling.NamespaceURI, ElementName = "GetMessageRequest")]
    public class GetMessageRequest : OpenElementElement
    {
        string _messageID;
        string _to;

        public GetMessageRequest()
        {
        }

        public GetMessageRequest( XmlElement element)
        {
            LoadXml(element);
        }
        
        public string MessageID
        {
            get { return _messageID; }
            set { _messageID = value; }
        }

        public string To
        {
            get { return _to; }
            set { _to = value; }
        }

        public override XmlElement GetXml(XmlDocument document)
        {
            if (document == null)
                throw new ArgumentNullException("document");

            XmlElement element = document.CreateElement(WSPolling.Prefix, WSPolling.ElementNames.GetMessage, WSPolling.NamespaceURI);

            if (this._messageID != null)
            {
                MessageID messageId = new MessageID(new Uri(this._messageID));
                XmlElement messageIdElement = messageId.GetXml(document);
                element.AppendChild(messageIdElement);
            }

            if (this._to != null)
            {
                XmlElement to = document.CreateElement(WSPolling.Prefix, WSPolling.ElementNames.To, WSPolling.NamespaceURI);
                to.InnerText = this._to;
                element.AppendChild(to);
            }

            if (this.AnyElements != null && this.AnyElements.Count > 0)
            {
                XmlElement extensions = document.CreateElement(WSPolling.Prefix, WSPolling.ElementNames.Extensions, WSPolling.NamespaceURI);

                GetXmlElements(document, extensions);
                
                element.AppendChild(extensions);
            }

            return element;          

        }

        public override void LoadXml(XmlElement element)
        {
            if (null == element)
                throw new ArgumentNullException("element");

            if (element.LocalName != WSPolling.ElementNames.GetMessage || element.NamespaceURI != WSPolling.NamespaceURI)
                throw new ArgumentException(String.Format("Invalid root element, localname:{0} namespace:{1}", element.LocalName, element.NamespaceURI), "element");

            try
            {
                AnyElements.Clear();
                if (element.HasChildNodes)
                {
                    for (int i = 0; i < element.ChildNodes.Count; i++)
                    {
                        XmlElement child = element.ChildNodes[i] as XmlElement;

                        if (child != null)
                        {
                            switch (child.NamespaceURI)
                            {
                                case WSAddressing.NamespaceURI:
                                    switch (child.LocalName)
                                    {
                                        case WSAddressing.ElementNames.MessageID:
                                            MessageID messageID = new MessageID(child);
                                            this._messageID = messageID.Value.ToString();
                                            break;
                                    }
                                    break;
                                case WSPolling.NamespaceURI:
                                    switch (child.LocalName)
                                    {
                                        case WSPolling.ElementNames.To:
                                            this._to = child.InnerText;
                                            break;
                                        case WSPolling.ElementNames.Extensions:
                                            LoadXmlElements(child);
                                            break;
                                    }
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

        }


    }
}
