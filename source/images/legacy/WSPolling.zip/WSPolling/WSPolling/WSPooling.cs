using System;
using System.Collections.Generic;
using System.Text;

namespace WSEPolling
{
    public class WSPolling
    {
        public const string NamespaceURI = "http://www.w3.org/2005/08/ws-polling";
        public const string Prefix = "wsp";
        public const string HoldResponseURI = "http://www.w3.org/2005/08/ws-polling/HoldResponse";

        public static class AttributeNames
        {
            public const string Reason = "reason";
            public const string MessagesPending = "messagesPending";
        }

        public static class ElementNames
        {
            public const string GetMessage = "GetMessage";
            public const string StatusRequested = "StatusRequested";
            public const string Status = "Status";
            public const string To = "To";
            public const string Extensions = "extensions";
            public const string NoMessageAvailable = "NoMessageAvailable";
        }

        public static class Actions
        {
            public const string GetMessage = "http://www.w3.org/2005/08/ws-polling/GetMessage";
            public const string NoMessageAvailable = "http://www.w3.org/2005/08/ws-polling/NoMessageAvailable";
        }
                
    }
}
