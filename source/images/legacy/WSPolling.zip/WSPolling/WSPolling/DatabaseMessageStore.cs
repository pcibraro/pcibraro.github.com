using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;
using System.Configuration;

using System.Data.SqlClient;

using Microsoft.Web.Services3;

namespace WSEPolling
{
    class DatabaseMessageStore : IMessageStore
    {
        private string _connectionString = null;
        
        #region IMessageStore Members

        public void Init(XmlElement configuration)
        {
            ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["Messages"];
            if(settings == null)
                throw new ConfigurationErrorsException("The connection string 'Messages' is not configured");

            if(settings.ConnectionString == null)
                throw new ConfigurationErrorsException("Invalid value for the connection string 'Messages'");

            this._connectionString = settings.ConnectionString;
        }

        public void StoreRequest(SoapEnvelope request)
        {
            using (SqlConnection connection = new SqlConnection(this._connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("InsertMessage", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@MessageID", request.Context.Addressing.MessageID.Value.ToString()));
                    command.Parameters.Add(new SqlParameter("@To", request.Context.Addressing.To.Value.ToString()));

                    command.ExecuteNonQuery();
                }

                connection.Close();
            }
        }

        public void StoreResponse(SoapEnvelope response)
        {
            response.Context.Addressing.GetXml(response);

            using (SqlConnection connection = new SqlConnection(this._connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("UpdateMessage", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@MessageID", response.Context.Addressing.RelatesTo.Value.ToString()));
                    command.Parameters.Add(new SqlParameter("@Message", response.OuterXml));

                    command.ExecuteNonQuery();
                }

                connection.Close();
            }
        }

        public SoapEnvelope GetResponse(GetMessageRequest request)
        {
            SoapEnvelope response = new SoapEnvelope();

            using (SqlConnection connection = new SqlConnection(this._connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("GetMessage", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@MessageID", request.MessageID.ToString()));

                    using (SqlDataReader reader = command.ExecuteReader(System.Data.CommandBehavior.CloseConnection))
                    {
                        if (reader.Read())
                        {
                            if (reader["Message"] == DBNull.Value )
                            {
                                NoMessageAvailable noMessage = new NoMessageAvailable(Reason.ResponseNotReady);
                                response.Context.Addressing.Action = WSPolling.Actions.NoMessageAvailable; 
                                response.SetBodyObject(noMessage);
                            }
                            else
                            {
                                string message = (string)reader["Message"];

                                response.Load(new StringReader(message));
                                response.Context.Addressing.RemoveXml(response);
                            }
                        }
                        else
                        {
                            NoMessageAvailable noMessage = new NoMessageAvailable(Reason.NoMessageFound);
                            response.Context.Addressing.Action = WSPolling.Actions.NoMessageAvailable; 
                            response.SetBodyObject(noMessage);
                        }

                        reader.Close();
                    }
                }

                connection.Close();
            }

            return response;
        }
               

        #endregion
    }
}
