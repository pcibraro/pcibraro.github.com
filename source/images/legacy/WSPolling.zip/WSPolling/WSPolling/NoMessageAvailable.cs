using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services3.Xml;
using Microsoft.Web.Services3.Addressing;

namespace WSEPolling
{
    public enum Reason
    {
        ResponseAlreadySent,
        ResponseNotReady,
        UnknownMessageID,
        NoMessageFound
    }

    public class NoMessageAvailable : IXmlElement
    {
        private Reason _reason;

        public NoMessageAvailable(Reason reason)
        {
            _reason = reason;
        }

        public NoMessageAvailable(XmlElement element)
        {
            LoadXml(element);
        }

        public Reason Reason
        {
            get
            {
                return _reason;
            }
            set
            {
                _reason = value;
            }
        }

        #region IXmlElement Members

        public XmlElement GetXml(XmlDocument document)
        {
            if (document == null)
                throw new ArgumentNullException("document");

            XmlElement element = document.CreateElement(WSPolling.Prefix, WSPolling.ElementNames.NoMessageAvailable, WSPolling.NamespaceURI);

            XmlAttribute reasonAttribute = document.CreateAttribute(WSPolling.AttributeNames.Reason);
            reasonAttribute.Value = this._reason.ToString();
            element.Attributes.Append(reasonAttribute);
            
            return element;
        }

        public void LoadXml(XmlElement element)
        {
            if (null == element)
                throw new ArgumentNullException("element");

            if (element.LocalName != WSPolling.ElementNames.NoMessageAvailable || element.NamespaceURI != WSPolling.NamespaceURI)
                throw new ArgumentException(String.Format("Invalid root element, localname:{0} namespace:{1}", element.LocalName, element.NamespaceURI), "element");

            if (element.HasChildNodes)
            {
                for (int i = 0; i < element.ChildNodes.Count; i++)
                {
                    XmlElement child = element.ChildNodes[i] as XmlElement;

                    if (child != null)
                    {
                        if (child.LocalName == WSPolling.ElementNames.NoMessageAvailable &&
                            child.NamespaceURI == WSPolling.NamespaceURI)
                        {
                            if (child.Attributes[WSPolling.AttributeNames.Reason] != null)
                            {
                                this._reason = (Reason)Enum.Parse(typeof(Reason), child.Attributes[WSPolling.AttributeNames.Reason].Value);
                            }
                        }
                        else
                        {
                            throw new Exception("Invalid child node");
                        }
                    }
                }
            }
        }

        #endregion
    }
}
