using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using Microsoft.Web.Services3.Xml;
using Microsoft.Web.Services3.Addressing;

namespace WSEPolling 
{
    [XmlRoot("StatusHeader", Namespace = WSPolling.NamespaceURI, IsNullable = false)]
    [XmlType(Namespace = WSPolling.NamespaceURI)]
    public class StatusHeader : System.Web.Services.Protocols.SoapHeader
    {
        private bool _pending;
        private string _messageId;
        private string _to;

        
        public StatusHeader()
        {
        }

        [XmlAttribute(WSPolling.AttributeNames.MessagesPending)] 
        public bool AreMessagesPending
        {
            get { return _pending; }
            set { _pending = value; }
        }

        public string MessageID
        {
            get { return _messageId; }
            set { _messageId = value; }
        }

        public string To
        {
            get { return _to; }
            set { _to = value; }
        }
    }
}
