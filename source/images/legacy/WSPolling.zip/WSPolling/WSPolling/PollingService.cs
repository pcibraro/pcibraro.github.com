using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

using System.Threading;

using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Messaging;
using Microsoft.Web.Services3.Addressing;

namespace WSEPolling
{
    public class PollingService : SoapService
    {
        static IMessageStore _store;
        
        static PollingService()
        {
            _store = new DatabaseMessageStore();
            _store.Init(null);
        }
                        
        [SoapMethod(WSPolling.Actions.GetMessage)]
        public virtual SoapEnvelope GetMessage(GetMessageRequest request)
        {
            SoapEnvelope envelope = _store.GetResponse(request);

            //XmlAttribute replyAttribute = envelope.CreateAttribute(WSAddressing.Prefix, "RelationshipType", WSAddressing.NamespaceURI);
            //replyAttribute.Value = "urn:MessageID";

            //RelatesTo messageIDRelatesTo = envelope.Context.Addressing.RelatesTo;
            //messageIDRelatesTo.AnyAttributes.Add(replyAttribute);
            //envelope.CreateHeader().AppendChild(messageIDRelatesTo.GetXml(envelope));      

            //Hack: WSE doesn't support more than one RelatesTo header
            RelatesTo relatesTo = new RelatesTo(RequestSoapContext.Current.Addressing.MessageID.Value);
            envelope.Context.Addressing.RelatesTo = relatesTo;

            return envelope;
        }

        protected override SoapMethodInvoker RouteRequest(SoapEnvelope request)
        {
            return new AsyncSoapMethodInvoker(this, base.RouteRequest(request));
        }

        protected virtual void StoreResponse(SoapEnvelope response)
        {
            _store.StoreResponse (response); 
        }

        protected virtual void StoreRequest(SoapEnvelope request)
        {
            _store.StoreRequest(request);
        }
        
        class AsyncSoapMethodInvoker : SoapMethodInvoker
        {
            private SoapMethodInvoker _invoker;
            private PollingService _service;

            public AsyncSoapMethodInvoker(PollingService service, SoapMethodInvoker invoker)
            {
                this._invoker = invoker;
                this._service = service;
            }

            public override SoapEnvelope Invoke(SoapEnvelope message)
            {
                if (message.Context.Addressing.Action != WSPolling.Actions.GetMessage &&
                    message.Context.Addressing.ReplyTo != null &&
                    message.Context.Addressing.ReplyTo.Address.Value.ToString() == WSPolling.HoldResponseURI)
                {
                    this._service.StoreRequest(message);

                    WaitCallback callBack = new WaitCallback(this.Invoke);
                    ThreadPool.QueueUserWorkItem(callBack, message);

                    return new SoapEnvelope();
                }
                else
                {
                    SoapEnvelope response = _invoker.Invoke(message);

                    return response;
                }
            }

            public override bool OneWay
            {
                get { return _invoker.OneWay; }
            }

            private void Invoke(object state)
            {
                SoapEnvelope request = (SoapEnvelope)state;
                SoapEnvelope response = _invoker.Invoke(request);

                _service.StoreResponse(response);
            }
        }
    }
}
