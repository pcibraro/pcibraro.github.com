using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Messaging;

/// <summary>
/// Summary description for Service
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[Policy("ServicePolicy")]
public class Service : WSEPolling.PollingService
{
        
    public Service()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    
    [SoapMethod("HelloWorld")]
    public string HelloWorld(string name)
    {
        return "Hello World " + name;
    }

}

