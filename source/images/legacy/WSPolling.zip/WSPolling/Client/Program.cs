using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Web.Services3;

using WSEPolling;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            PollingClient client = new PollingClient(new Uri("http://localhost/WSEPollingService/Service.ashx"));

            client.SetPolicy("ClientPolicy"); 
            
            string s = "Test";
                        
            Uri id = client.InvokeService("HelloWorld", s, "http://tempuri.org/");
            
            System.Threading.Thread.Sleep(1000);

            WSEPolling.GetMessageRequest request = new WSEPolling.GetMessageRequest();
            request.MessageID = id.ToString();

            SoapEnvelope response = client.GetMessage(request);

            //string message = (string)client.GetMessageBody(request, typeof(string), "http://tempuri.org/");
            
            string message = response.OuterXml;

            Console.WriteLine(message);
        }
    }
}
