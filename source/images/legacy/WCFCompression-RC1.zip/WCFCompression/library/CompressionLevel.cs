// Copyright 2006
// Pablo Cibraro, http://weblogs.asp.net/cibrax
// Rodolfo Finochieti, http://weblogs.shockbyte.com.ar/rodolfof 

using System;

namespace Microsoft.ServiceModel.Samples
{
    public enum CompressionLevel
    {
        Fast = 1,
        Normal = -1,
        Maximum = 9,
        NoCompression = 0
    }
}