// Copyright 2006
// Pablo Cibraro, http://weblogs.asp.net/cibrax
// Rodolfo Finochieti, http://weblogs.shockbyte.com.ar/rodolfof 

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Microsoft.ServiceModel.Samples
{
    internal class CompressedData
    {
        private string _id;
        private CompressionMode _compressionMode;
        private CompressionLevel _compressionLevel;
        private string _data;

        public CompressedData(CompressionMode compressionMode, CompressionLevel compressionLevel, string id)
        {
            _compressionMode = compressionMode;
            _compressionLevel = compressionLevel;
            _id = id;
        }

        public CompressedData(CompressionMode compressionMode, CompressionLevel compressionLevel, XmlReader elementReader)
        {
            _compressionLevel = compressionLevel;
            _compressionMode = compressionMode;
            ReadXml(elementReader, compressionMode, compressionLevel);
        }

        public string Data
        {
            get { return _data; }
        }

        public static bool IsValidElement(XmlReader reader)
        {
            return (reader.LocalName == WSCompression.ElementNames.CompressedData && reader.NamespaceURI == WSCompression.NamespaceURI);
        }

        public void WriteCompressedXml(XmlWriter writer, string data)
        {
            if (writer == null)
                throw new ArgumentNullException("writer");

            string compressedData = CompressAndBase64Encode(data, _compressionMode, _compressionLevel);

            writer.WriteStartElement(WSCompression.Prefix, WSCompression.ElementNames.CompressedData, WSCompression.NamespaceURI);
            writer.WriteAttributeString(WSCompression.AttributeNames.Id, _id);
            writer.WriteString(compressedData);
            writer.WriteEndElement();
        }

        private static string CompressAndBase64Encode(string data, CompressionMode compressionMode, CompressionLevel compressionLevel)
        {
            return Convert.ToBase64String((new Compressor(compressionMode, compressionLevel)).CompressString(data));
        }

        private static string Base64DecodeAndDecompress(string compressedData, CompressionMode compressionMode, CompressionLevel compressionLevel)
        {
            return (new Compressor(compressionMode, compressionLevel)).DecompressString(Convert.FromBase64String(compressedData));
        }

        public void ReadXml(XmlReader reader, CompressionMode compressionMode, CompressionLevel compressionLevel)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");

            if(!IsValidElement(reader))
                throw new ArgumentException("Invalid element");
             
            //This attribute is optional
            _id = reader.GetAttribute(WSCompression.AttributeNames.Id);

            string compressedData = reader.ReadString();

            this._data = Base64DecodeAndDecompress(compressedData, compressionMode, compressionLevel);

            reader.Read();
        }
    }
}
