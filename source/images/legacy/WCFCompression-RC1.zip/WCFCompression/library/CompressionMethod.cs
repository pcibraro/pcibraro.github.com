// Copyright 2006
// Pablo Cibraro, http://weblogs.asp.net/cibrax
// Rodolfo Finochieti, http://weblogs.shockbyte.com.ar/rodolfof 

using System;
using System.Xml;

namespace Microsoft.ServiceModel.Samples
{
    internal class CompressionMethod
    {
        private string _algorithm;
        private string _level;

        public CompressionMethod( CompressionMode compressionMode, CompressionLevel compressionLevel )
        {
            _algorithm = GetAlgorithm( compressionMode );
            _level = GetLevel( compressionLevel );
        }

        public CompressionMethod( XmlReader elementReader )
        {
            ReadXml(elementReader);
        }

        public static bool IsValidElement(XmlReader elementReader)
        {
            return (elementReader.LocalName == WSCompression.ElementNames.CompressionMethod && elementReader.NamespaceURI == WSCompression.NamespaceURI);
        }

        public string Algorithm 
        { 
            get 
            { 
                return _algorithm; 
            } 
        }

        public static string GetAlgorithm( CompressionMode compressionMode )
        {
            switch ( compressionMode )
            {
                case CompressionMode.GZip:
                    return WSCompression.Algorithm.GZip;
                case CompressionMode.Deflate:
                    return WSCompression.Algorithm.Deflate;
                default:
                    throw new ArgumentOutOfRangeException( "compressionMode" );
            }
        }

        public static CompressionMode GetCompressionMode( string algorithm )
        {
            switch ( algorithm )
            {
                case WSCompression.Algorithm.GZip:
                    return CompressionMode.GZip;
                case WSCompression.Algorithm.Deflate:
                    return CompressionMode.Deflate;
                default:
                    throw new ArgumentOutOfRangeException( "compressionMode" );
            }
        }

        public string Level
        {
            get
            { 
                return _level;
            }
        }

        public static string GetLevel( CompressionLevel compressionLevel )
        {
            switch ( compressionLevel )
            {
                case CompressionLevel.Fast:
                    return WSCompression.Level.Fast;
                case CompressionLevel.Maximum:
                    return WSCompression.Level.Maximum;
                case CompressionLevel.NoCompression:
                    return WSCompression.Level.NoCompression;
                case CompressionLevel.Normal:
                    return WSCompression.Level.Normal;
                default:
                    throw new ArgumentOutOfRangeException( "compressionLevel" );
            }
        }

        public static CompressionLevel GetCompressionLevel( string level )
        {
            switch ( level )
            {
                case WSCompression.Level.Fast:
                    return CompressionLevel.Fast;
                case WSCompression.Level.Maximum:
                    return CompressionLevel.Maximum;
                case WSCompression.Level.NoCompression:
                    return CompressionLevel.NoCompression;
                case WSCompression.Level.Normal:
                    return CompressionLevel.Normal;
                default:
                    throw new ArgumentOutOfRangeException( "level" );
            }
        }

        public void ReadXml( XmlReader reader )
        {
            if ( reader == null )
                throw new ArgumentNullException( "reader" );

            if (!IsValidElement(reader))
                throw new ArgumentException("Invalid element");
            
            _algorithm = reader.GetAttribute(WSCompression.AttributeNames.Algorithm);
            _level = reader.GetAttribute(WSCompression.AttributeNames.Level);

            reader.Read();
        }

        public void WriteXml( XmlWriter writer )
        {
            if ( writer == null )
                throw new ArgumentNullException( "writer" );

            writer.WriteStartElement(WSCompression.Prefix, WSCompression.ElementNames.CompressionMethod, WSCompression.NamespaceURI);
            writer.WriteAttributeString(WSCompression.AttributeNames.Algorithm, Algorithm);
            writer.WriteAttributeString(WSCompression.AttributeNames.Level, Level);
            writer.WriteEndElement();            
        }
    }
}