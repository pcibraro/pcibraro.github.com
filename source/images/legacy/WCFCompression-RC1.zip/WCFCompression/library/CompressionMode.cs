// Copyright 2006
// Pablo Cibraro, http://weblogs.asp.net/cibrax
// Rodolfo Finochieti, http://weblogs.shockbyte.com.ar/rodolfof 

using System;

namespace Microsoft.ServiceModel.Samples
{
    public enum CompressionMode
    {
        None = 0,
        GZip = 1,
        Deflate = 2,
    }
}