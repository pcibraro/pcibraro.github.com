// Copyright 2006
// Pablo Cibraro, http://weblogs.asp.net/cibrax
// Rodolfo Finochieti, http://weblogs.shockbyte.com.ar/rodolfof 

using System;

namespace Microsoft.ServiceModel.Samples
{
    internal static class WSCompression
    {
        public const string Prefix = "sc";
        public const string NamespaceURI = "http://weblogs.shockbyte.com.ar/rodolfof/compression/2006/02";

        public static class Algorithm
        {
            public const string GZip = "http://weblogs.shockbyte.com.ar/rodolfof/compression/2006/02/gzip";
            public const string Deflate = "http://weblogs.shockbyte.com.ar/rodolfof/soap/compression/2006/02/deflate";
        }

        public static class Level
        {
            public const string Fast = "http://weblogs.shockbyte.com.ar/rodolfof/compression/2006/02/fast";
            public const string Normal = "http://weblogs.shockbyte.com.ar/rodolfof/compression/2006/02/normal";
            public const string Maximum = "http://weblogs.shockbyte.com.ar/rodolfof/soap/compression/2006/02/maximun";
            public const string NoCompression = "http://weblogs.shockbyte.com.ar/rodolfof/soap/compression/2006/02/nocompressionlevel";
        }

        public static class AttributeNames
        {
            public const string Algorithm = "Algorithm";
            public const string Level = "Level";
            public const string Threshold = "Threshold";
            public const string Uri = "URI";
            public const string Id = "Id";
        }

        public static class ElementNames
        {
            public const string Compression = "Compression";
            public const string CompressedData = "CompressedData";
            public const string ReferenceList = "ReferenceList";
            public const string DataReference = "DataReference";
            public const string CompressionMethod = "CompressionMethod";
        }
    }
}