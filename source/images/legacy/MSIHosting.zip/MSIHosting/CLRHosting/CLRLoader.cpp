#include "StdAfx.h"
#include "clrloader.h"
#include "Strings.h"

#include <windows.h>
#include <msi.h>
#include <msiquery.h>

// some interfaces that will be used are from this namespace.
using namespace mscorlib;

// auto_ptr is used to enforce clean-up on DLL unload.
std::auto_ptr<CCLRLoader> CCLRLoader::m_pInstance;

// forward declarations
static HRESULT StoreBinary(TCHAR* szFile, TCHAR* szKeyName, MSIHANDLE handle);

// class functions

CCLRLoader *CCLRLoader::TheInstance()
{
	if (m_pInstance.get() == NULL)
  	{
        m_pInstance = std::auto_ptr<CCLRLoader>(new CCLRLoader());
	}

    return m_pInstance.get();
}

CCLRLoader::CCLRLoader(void)
	: m_pHost(NULL)
	, m_pLocalDomain(NULL)
{
}

CCLRLoader::~CCLRLoader(void)
{
	if (m_pLocalDomain)
	{
		m_pLocalDomain->Release();
	}

	if (m_pHost)
	{
		m_pHost->Stop();
		m_pHost->Release();
	}
}

// LoadCLR: This method starts up the Common Language Runtime
HRESULT CCLRLoader::LoadCLR()
{
	HRESULT hr = S_OK;

	// ensure the CLR is only loaded once.
	if (m_pHost != NULL)
		return hr;

	// Load runtime into the process ...
	hr = CorBindToRuntimeEx(
		 // version, use 1.1 framework
		szCLRVersion,
		 // flavor, use workstation
		szCLRFlavor,
		 // domain-neutral"ness" and gc settings
		STARTUP_LOADER_OPTIMIZATION_MULTI_DOMAIN |	STARTUP_CONCURRENT_GC,
		CLSID_CorRuntimeHost, 
		IID_ICorRuntimeHost, 
		(PVOID*) &m_pHost);

	// If S_FALSE is returned, it means the CLR has already been loaded
	if (hr == S_FALSE)
	{
		return hr;
	}

	// couldn't load....
	if (!SUCCEEDED(hr)) 
	{
		return hr;
	}

	// start CLR
	return m_pHost->Start();
}

// CreateLocalAppDomain: the function creates AppDomain with BaseDirectory
// set to location of unmanaged DLL containing this code. Assuming that the
// target assembly is located in the same directory, the classes from this
// assemblies can be instantiated by calling _AppDomain::Load() method.
HRESULT CCLRLoader::CreateLocalAppDomain()
{
    USES_CONVERSION;

	HRESULT hr = S_OK;

	// ensure the domain is created only once
	if (m_pLocalDomain != NULL)
	{
		return hr;
	}

	CComPtr<IUnknown> pDomainSetupPunk;
	CComPtr<IAppDomainSetup> pDomainSetup;
	CComPtr<IUnknown> pLocalDomainPunk;
	TCHAR szDirectory[MAX_PATH + 1];
	
	// Create an AppDomainSetup with the base directory pointing to the
    // location of the managed DLL. The assumption is made that the
    // target assembly is located in the same directory
	IfFailGo( m_pHost->CreateDomainSetup(&pDomainSetupPunk) );
	IfFailGo( pDomainSetupPunk->QueryInterface(__uuidof(pDomainSetup),
		(LPVOID*)&pDomainSetup) );

	// Get the location of the hosting DLL
	//IfFailGo( ::GetDllDirectory(this->m_MsiHandle, szDirectory, sizeof(szDirectory)/sizeof(szDirectory[0])) );
	GetTempPath(sizeof(szDirectory), szDirectory);
	
	// Configure the AppDomain to search for assemblies in the above directory
	pDomainSetup->put_ApplicationBase(CComBSTR(szDirectory));
	
	// Configure the application name
	pDomainSetup->put_ApplicationName(CComBSTR(szApplicationName));

	pDomainSetup->put_ConfigurationFile(CComBSTR(szApplicationConfigFile));

	// Create an AppDomain that will run the managed assembly
	IfFailGo( m_pHost->CreateDomainEx(szApplicationName, 
		pDomainSetupPunk, 0, &pLocalDomainPunk) );
	
	// Cast IUnknown pointer to _AppDomain pointer
	IfFailGo( pLocalDomainPunk->QueryInterface(__uuidof(m_pLocalDomain),  
        (LPVOID*)&m_pLocalDomain) );

Error:
   return hr;
}

HRESULT CCLRLoader::RunCustomActions()
{
	HRESULT hr = S_OK;
	_ObjectHandle *pObjHandle = NULL;
	VARIANT v;
	DISPID dispid;
	DISPPARAMS dispparams = {NULL, NULL, 0, 0};
	VARIANTARG varg[1];

	dispparams.cArgs = 1;
	dispparams.cNamedArgs = 0;
	dispparams.rgvarg = varg;
	dispparams.rgvarg[0].vt = VT_I4;
	dispparams.rgvarg[0].lVal = this->m_MsiHandle;

	OLECHAR FAR* szMember = szCustomActionMember;
	CComPtr<IDispatch> pDisp;

	// Ensure the common language runtime is running ...
    IfFailGo( LoadCLR() );

    // In order to securely load an assembly, its fully qualified strong name
    // and not the filename must be used. To do that, the target AppDomain's 
    // base directory needs to point to the directory where the assembly is
    // residing. CreateLocalAppDomain() ensures that such AppDomain exists.
	IfFailGo( CreateLocalAppDomain() );

	TCHAR szAssemblyPath[MAX_PATH+1];
	GetTempPath(sizeof(szAssemblyPath), szAssemblyPath);
	strcat(szAssemblyPath, szAssemblyName);
	strcat(szAssemblyPath, ".dll");
	IfFailGo( ::StoreBinary( szAssemblyPath, "CustomActionRuntime", this->m_MsiHandle ) );

	strcat(szAssemblyPath, "");
	GetTempPath(sizeof(szAssemblyPath), szAssemblyPath);
	strcat(szAssemblyPath, szApplicationConfigFile);
	IfFailGo( ::StoreBinary( szAssemblyPath, szApplicationConfigFileBinaryKey, this->m_MsiHandle ) );

	// Create an instance of the managed class
	IfFailGo(m_pLocalDomain->CreateInstance(CComBSTR(szAssemblyName),
		CComBSTR(szClassName), &pObjHandle)); 

	// extract interface pointer from the object handle
	VariantInit(&v);
	hr = pObjHandle->Unwrap(&v);

	pDisp = v.pdispVal;

	//Retrieve the DISPID
	IfFailGo( pDisp->GetIDsOfNames (IID_NULL, 
						  &szMember,
						  1,
						  LOCALE_SYSTEM_DEFAULT,
						  &dispid
								) );


	IfFailGo( pDisp->Invoke  ( dispid,
					IID_NULL,
					LOCALE_SYSTEM_DEFAULT,
					DISPATCH_METHOD,
					&dispparams,
					NULL,
					NULL,
					NULL
				  ) );

Error:

   return hr;
}

static HRESULT StoreBinary( TCHAR* szFile, TCHAR* szKeyName, MSIHANDLE handle )
{
	PMSIHANDLE hDatabase = MsiGetActiveDatabase(handle);
	PMSIHANDLE hView;

	TCHAR szQuery[255] = "";
	strcat(szQuery, "SELECT * FROM Binary WHERE Name = '");
	strcat(szQuery, szKeyName);
	strcat(szQuery, "'");

	if( MsiDatabaseOpenView(hDatabase, szQuery, &hView) != ERROR_SUCCESS )
		return E_FAIL;

	if( MsiViewExecute(hView, NULL) != ERROR_SUCCESS )
		return E_FAIL;
    	
	for (;;)
    {
		PMSIHANDLE hRecord;
        UINT fetchResult = MsiViewFetch(hView, &hRecord);
        if ( fetchResult == ERROR_NO_MORE_ITEMS ) break;
        
		DWORD dwritten = 0;
		DWORD dlen = MsiRecordDataSize(hRecord,2);
		char *pBinary = new char[dlen];
		
		if( MsiRecordReadStream(hRecord,2,pBinary,&dlen) == ERROR_SUCCESS  )
		{			
			HANDLE hfile = CreateFile(szFile, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

			if( hfile == 0 )
				return E_FAIL;
			
			WriteFile(hfile, pBinary, dlen, &dwritten, NULL );
			CloseHandle(hfile);
		}

		pBinary = 0;
	}

	return S_OK;
}


