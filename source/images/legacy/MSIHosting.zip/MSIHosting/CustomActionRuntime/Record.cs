using System;
using System.Text;
using System.Collections;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace CustomActionRuntime
{
	/// <summary>
	/// </summary>
	public class Record
	{
		#region Interop Methods
		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiRecordClearData(IntPtr hRecord);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiRecordGetFieldCount(IntPtr hRecord);
		#endregion

		#region Private Fields
		private IntPtr _handle;
		private FieldCollection _fields = new FieldCollection();
		#endregion

		#region Constructors
		internal Record( IntPtr handle )
		{
			_handle = handle;
			
			int fieldCount = MsiRecordGetFieldCount( _handle ); 
			for( int index = 0; index < fieldCount; index++ )
			{
				_fields.Add( new Field( handle, index ) );
			}
		}

		internal Record( IntPtr handle, int fieldCount )
		{
			_handle = handle;
			for( int index = 0; index < fieldCount; index++ )
			{
				_fields.Add( new Field( handle, index ) );
			}
		}
		#endregion

		#region Internal Methods
		internal IntPtr Handle
		{
			get { return _handle; }
		}
		#endregion

		#region Public Methods
		
		/// <summary>
		/// Gets a collection containing the record fields
		/// </summary>
		public FieldCollection Fields
		{
			get { return _fields; }
		}

		/// <summary>
		/// Sets all fields in a record to null.
		/// </summary>
		public void ClearData()
		{
			int result = MsiRecordClearData(_handle);
			if( result != 0 )
				throw new Win32Exception( result );
		}
		#endregion

		
	}
}
