using System;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace CustomActionRuntime
{
	/// <summary>
	/// </summary>
	public class Field
	{
		#region Interop Methods
		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiRecordGetInteger(IntPtr hRecord, int iField);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiRecordGetString(IntPtr hRecord, int iField, 
			[Out] StringBuilder szValueBuf, ref int pcchValueBuf);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern bool MsiRecordIsNull(IntPtr hRecord, int iField);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiRecordReadStream(IntPtr hRecord, int iField, 
			[Out] byte[] szDataBuf, ref int pcbDataBuf);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiRecordDataSize(IntPtr hRecord, int iField);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiRecordSetInteger(IntPtr hRecord, int iField, int iValue);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiRecordSetString(IntPtr hRecord, int iField, string szValue);
		
		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiRecordSetStream(IntPtr hRecord, int iField, string szFilePath);
		#endregion

		#region Private Fields
		private IntPtr _recordHandle;
		private int _fieldNumber;
		#endregion

		#region Constructors
		internal Field( IntPtr recordHandle, int fieldNumber )
		{
			_recordHandle = recordHandle;
			_fieldNumber = fieldNumber;
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Returns the integer value from a record field. 
		/// </summary>
		public int GetInteger()
		{
			return MsiRecordGetInteger( _recordHandle, _fieldNumber );
		}

		/// <summary>
		/// Returns the string value of a record field. 
		/// </summary>
		public string GetString()
		{
			StringBuilder value = new StringBuilder(1024);
			int size = 1024;
 
			int result = MsiRecordGetString( _recordHandle, _fieldNumber, value, ref size);

			if( result != 0 )
				throw new Win32Exception(result);

			return value.ToString();
		}

		/// <summary>
		/// Reports whether a record field is null. 
		/// </summary>
		public bool IsNull()
		{
			return MsiRecordIsNull( _recordHandle, _fieldNumber );
		}

		/// <summary>
		/// Reads bytes from a record stream field into a buffer. 
		/// </summary>
		public byte[] ReadStream()
		{
			int size = DataSize();

			if( size > 0 )
			{
				byte[] buffer = new byte[ size ];
				int result = MsiRecordReadStream( _recordHandle, _fieldNumber, buffer, ref size);

				return buffer;
			}

			return null;
		}

		/// <summary>
		/// Returns the length of a record field. 
		/// </summary>
		public int DataSize()
		{
			return MsiRecordDataSize( _recordHandle, _fieldNumber );
		}

		/// <summary>
		/// Sets a record field to an integer field. 
		/// </summary>
		public void SetInteger( int value )
		{
			int result = MsiRecordSetInteger( _recordHandle, _fieldNumber, value );
			if( result != 0 )
				throw new Win32Exception( result );
		}

		/// <summary>
		/// Sets a record field to an integer field. 
		/// </summary>
		public void SetString( string value )
		{
			int result = MsiRecordSetString( _recordHandle, _fieldNumber, value );
			if( result != 0 )
				throw new Win32Exception( result );
		}

		/// <summary>
		/// Sets a record stream field from a file.  
		/// </summary>
		public void SetStream( string filePath )
		{
			int result = MsiRecordSetStream( _recordHandle, _fieldNumber, filePath );
			if( result != 0 )
				throw new Win32Exception( result );
		}

		#endregion
	}
}
