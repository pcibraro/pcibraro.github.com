using System;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace CustomActionRuntime
{
	/// <summary>
	/// Represents the custom action runtime. 
	/// It creates the context and calls the custom action.
	/// </summary>
	public class Runtime
	{
		#region Constructors
		public Runtime()
		{
		}
		#endregion

		#region Public Methods
		public void RunActions( long handle )
		{
			InstallerContext context = new InstallerContext( handle );
			CustomAction customAction = new CustomAction();
			customAction.Run( context );
		}
		#endregion
	}
}
