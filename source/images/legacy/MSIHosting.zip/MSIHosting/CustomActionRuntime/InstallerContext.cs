using System;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace CustomActionRuntime
{
	#region Interop Structures & Enums
	public enum MsiCondition
	{
		False = 0,
		True  = 1,
		None  = 2,
		Error = 3
	}

	public enum MsiAssemblyInfo
	{
		NetAssembly = 0,
		Win32Assembly = 1
	}

	public enum InstallState
	{
		NotUsed = -7,  // component disabled
		BadConfig = -6,  // configuration data corrupt
		Incomplete = -5,  // installation suspended or in progress
		SourceAbsent = -4,  // run from source, source is unavailable
		MoreData = -3,  // return buffer overflow
		InvalidArgs = -2,  // invalid function argument
		Unknown = -1,  // unrecognized product or feature
		Broken =  0,  // broken
		Advertised   =  1,  // advertised feature
		Removed =  1,  // component being removed (action state, not settable)
		Absent =  2,  // uninstalled (or action state absent but clients remain)
		Local =  3,  // installed on local drive
		Source =  4,  // run from source, CD or net
		Default =  5,  // use default, local or source
	}

	#endregion

	/// <summary>
	/// Represents the current installer context. 
	/// </summary>
	public class InstallerContext
	{
		#region Interop methods
		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiGetProperty( IntPtr hInstall, string szName, 
			[Out] StringBuilder szValueBuf, ref int pchValueBuf);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiSetProperty(IntPtr hInstall, string szName, string szValue);
		
		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiSetTargetPath(IntPtr hInstall, string szFolder, string szFolderPath);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiDoAction(IntPtr hInstall, string szAction);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern MsiCondition MsiEvaluateCondition(IntPtr hInstall, string szCondition);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern short MsiGetLanguage(IntPtr hInstall);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiGetSourcePath(IntPtr hInstall, string szFolder, 
			[Out] StringBuilder szPathBuf, ref int pcchPathBuf);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiGetTargetPath(IntPtr hInstall, string szFolder, 
			[Out] StringBuilder szPathBuf, ref int pcchPathBuf);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiProvideAssembly(string szAssemblyName, string szAppContext, 
			int dwInstallMode, int dwAssemblyInfo, 
			[Out] StringBuilder lpPathBuf, ref int pcchPathBuf);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiSetInstallLevel(IntPtr hInstall, int iInstallLevel);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern IntPtr MsiCreateRecord(int cParams);

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiGetFeatureState( IntPtr hInstall, string szFeature, 
			out InstallState piInstalled, out InstallState piAction );

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiGetComponentState( IntPtr hInstall, string szComponent,
			out InstallState piInstalled, out InstallState piAction );

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiSetComponentState( IntPtr hInstall, string szComponent,
			InstallState iState );

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiSetFeatureState( IntPtr hInstall, string szFeature,
			InstallState iState );

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern IntPtr MsiGetLastErrorRecord();

		[DllImport("msi.dll", CharSet=CharSet.Unicode)]
		static extern int MsiDatabaseOpenView( IntPtr hDatabase, string szQuery,
			out IntPtr phView );


		#endregion

		#region Private Fields
		private IntPtr _handle;
		#endregion

		#region Constructors
		public InstallerContext( long handle )
		{
			_handle = new IntPtr( handle );
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Msi handler
		/// </summary>
		public IntPtr CurrentHandler
		{
			get { return _handle; }
		}

		/// <summary>
		/// Executes a built-in action, custom action, or user-interface wizard action. 
		/// </summary>
		public void DoAction( string action )
		{
			int result = MsiDoAction( _handle, action );

			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Evaluates a conditional expression containing property names and values. 
		/// </summary>
		public MsiCondition EvaluateCondition( string conditionId )
		{
			MsiCondition condition = MsiEvaluateCondition( _handle, conditionId );
			return condition;
		}

		/// <summary>
		/// Returns the numeric language of the installation that is currently running. 
		/// </summary>
		public short GetLanguage()
		{
			return MsiGetLanguage( _handle );
		}

		/// <summary>
		/// Gets the value for an installer property. 
		/// </summary>
		public string GetProperty( string propertyName )
		{
			StringBuilder value = new StringBuilder(1024);
			int size = 1024;
 
			int result = MsiGetProperty(_handle, propertyName, value, ref size);

			if( result != 0 )
				throw new Win32Exception(result);

			return value.ToString();
		}

		/// <summary>
		/// Returns the full source path for a folder in the Directory table. 
		/// </summary>
		public string GetSourcePath( string folderId )
		{
			StringBuilder value = new StringBuilder(1024);
			int size = 1024;
 
			int result = MsiGetSourcePath(_handle, folderId, value, ref size);

			if( result != 0 )
				throw new Win32Exception(result);

			return value.ToString();
		}

		/// <summary>
		/// Returns the full target path for a folder in the Directory table. 
		/// </summary>
		public string GetTargetPath( string folderId )
		{
			StringBuilder value = new StringBuilder(1024);
			int size = 1024;
 
			int result = MsiGetTargetPath(_handle, folderId, value, ref size);

			if( result != 0 )
				throw new Win32Exception(result);

			return value.ToString();
		}

		/// <summary>
		/// Returns the full path to a Windows Installer component containing an assembly. 
		/// The function prompts for a source and performs any necessary installation. 
		/// ProvideAssembly also increments the usage count for the feature. 
		/// </summary>
		/// <remarks>
		/// This function is available starting with Windows Installer version 2.0
		/// </remarks>
		public string ProvideAssembly( string assemblyName, string installPath, MsiAssemblyInfo assemblyInfo )
		{
			StringBuilder value = new StringBuilder(1024);
			int size = 1024;
 
			int result = MsiProvideAssembly( assemblyName, installPath, 0, (int)assemblyInfo, value, ref size);

			if( result == 0 )
				return value.ToString();

			return null;
		}

		/// <summary>
		/// Sets the installation level for a full product installation. 
		/// </summary>
		public void SetInstallLevel( int installLevel )
		{
			int result = MsiSetInstallLevel( _handle, installLevel );

			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Sets the value for an installation property. 
		/// </summary>
		public void SetProperty( string propertyName, string value )
		{
			int result = MsiSetProperty( _handle, propertyName, value );

			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Sets the full target path for a folder in the Directory table. 
		/// </summary>
		public void SetTargetPath( string folderId, string path )
		{
			int result = MsiSetTargetPath( _handle, folderId, path );

			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Creates a new record with the specified number of fields. 
		/// </summary>
		public Record CreateRecord( int fieldCount )
		{
			IntPtr handle = MsiCreateRecord( fieldCount );
			if( handle != IntPtr.Zero )
			{
				Record record = new Record( handle, fieldCount ); 
				return record;
			}

			return null;
		}

		/// <summary>
		/// Returns the requested state of a feature
		/// </summary>
		public void GetFeatureState( string feature, out InstallState installed, out InstallState action )
		{
			int result = MsiGetFeatureState( _handle, feature, out installed, out action );
			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Returns the requested state of a component
		/// </summary>
		public void GetComponentState( string component, out InstallState installed, out InstallState action )
		{
			int result = MsiGetComponentState( _handle, component, out installed, out action );
			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Sets a component to the requested state
		/// </summary>
		public void SetComponentState( string component, InstallState installed )
		{
			int result = MsiSetComponentState( _handle, component, installed );
			if( result != 0 )
				throw new Win32Exception(result);
		}

		/// <summary>
		/// Sets a component to the requested state
		/// </summary>
		public void SetFeatureState( string feature, InstallState installed )
		{
			int result = MsiSetFeatureState( _handle, feature, installed );
			if( result != 0 )
				throw new Win32Exception(result);
		}
		
		/// <summary>
		/// Returns the error record that was last returned for the calling process.
		/// </summary>
		public Record GetLastError()
		{
			IntPtr handle = MsiGetLastErrorRecord();
			if( handle != IntPtr.Zero )
				return new Record( handle );
			
			return null;

		}

		/// <summary>
		/// Prepares a database query and returns a view object
		/// </summary>
		public View OpenView( string query )
		{
			IntPtr viewHandle;
			
			int result = MsiDatabaseOpenView( _handle, query, out viewHandle );
			if( result != 0 )
				throw new Win32Exception(result);

			View view = new View( viewHandle );
			return view;
		}
		#endregion
	}
}
