using System;

namespace CustomActionRuntime
{
	/// <summary>
	/// Custom action
	/// </summary>
	public class CustomAction
	{
		#region Constructors
		public CustomAction()
		{
			
		}
		#endregion

		public void Run( InstallerContext context )
		{
			string pid = context.GetProperty( "PIDKEY" );
			context.SetProperty( "PIDACCEPTED", pid[0] == '1' ? "1" : "0");
		}
	}
}
