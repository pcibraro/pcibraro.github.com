using System;
using System.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;

namespace CustomActionRuntime
{
	/// <summary>
	/// </summary>
	public class View : IDisposable
	{
		#region Interop Methods
		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiViewExecute(IntPtr hView, IntPtr hRecord);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiViewFetch(IntPtr hView, out IntPtr phRecord);

		[DllImport("msi.dll", ExactSpelling=true)]
		static extern int MsiViewClose(IntPtr hView);

		private const long ERROR_NO_MORE_ITEMS = 259L;
		#endregion

		#region Private Fields
		private IntPtr _handle;
		private bool _closed;
		#endregion

		#region Constructors
		internal View( IntPtr handle )
		{
			_handle = handle;
		}
		#endregion

		#region Public Methods
		/// <summary>
		/// Executes a SQL view query and supplies any required parameters.
		/// </summary>
		public RecordCollection Execute( Record parameters )
		{
			int result = 0;
			if( parameters != null )
				result = MsiViewExecute( _handle, parameters.Handle );
			else
				result = MsiViewExecute( _handle, IntPtr.Zero );

			if( result != 0 )
			{
				throw new Win32Exception( result );
			}
			else
			{
				RecordCollection records = new RecordCollection();
				
				for(;;)
				{
					IntPtr recordHandle;
					result = MsiViewFetch( _handle, out recordHandle );
					if( result == ERROR_NO_MORE_ITEMS )
						break;

					Record record = new Record( recordHandle );
					records.Add( record );
				}

				return records;

			}
		}

		/// <summary>
		/// Executes a SQL view query and supplies any required parameters.
		/// </summary>
		public RecordCollection Execute()
		{
			return Execute( null );
		}

		/// <summary>
		/// Releases the result set for an executed view.
		/// </summary>
		public void Close()
		{
			MsiViewClose( _handle );
			_closed = true;
		}

		#endregion

		#region IDisposable Members

		public void Dispose()
		{
			if( !_closed )
				Close();

		}

		#endregion
	}
}
