using System;
using System.Collections;

namespace CustomActionRuntime
{
	/// <summary>
	/// </summary>
	public class FieldCollection : CollectionBase
	{
		#region Constructors
		public FieldCollection()
		{
		}
		#endregion

		#region Public Properties
		public Field this[ int index ]
		{
			get { return (Field)this.InnerList[ index ]; }
			set { this.InnerList[ index ] = value; }
		}
		#endregion

		#region Public Methods
		public void Add( Field value )
		{
			this.InnerList.Add( value );
		}

		public void Remove( Field value )
		{
			this.InnerList.Remove( value );
		}

		public bool Contains( Field value )
		{
			return this.Contains( value );
		}

		public void Insert( int index, Field value )
		{
			this.InnerList.Insert( index, value );
		}
		#endregion
	}
}
