using System;
using System.Collections;

namespace CustomActionRuntime
{
	/// <summary>
	/// </summary>
	public class RecordCollection : CollectionBase
	{
		#region Constructors
		public RecordCollection()
		{
		}
		#endregion

		#region Public Properties
		public Record this[ int index ]
		{
			get { return (Record)this.InnerList[ index ]; }
			set { this.InnerList[ index ] = value; }
		}
		#endregion

		#region Public Methods
		public void Add( Record value )
		{
			this.InnerList.Add( value );
		}

		public void Remove( Record value )
		{
			this.InnerList.Remove( value );
		}

		public bool Contains( Record value )
		{
			return this.Contains( value );
		}

		public void Insert( int index, Record value )
		{
			this.InnerList.Insert( index, value );
		}
		#endregion
	}
}
