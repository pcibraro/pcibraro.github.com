﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Configuration;
using System.Configuration;
using System.ServiceModel.Channels;

namespace Microsoft.ServiceModel.Samples
{
	public enum ContextMode
	{
		HttpHeader,
		UriTemplate
	}
	
	public class WebHttpContextBindingConfigurationElement : WebHttpBindingElement
	{
		[ConfigurationProperty("contextMode", DefaultValue=ContextMode.HttpHeader)]
		public ContextMode ContextMode
		{
			get { return (ContextMode)base["contextMode"]; }
			set { base["contextMode"] = value; }
		}

		[ConfigurationProperty("uriTemplates", IsRequired=false)]
		public NameValueConfigurationCollection UriTemplates
		{
			get { return (NameValueConfigurationCollection)base["uriTemplates"]; }
			set { base["uriTemplates"] = value; }
		}

		protected override ConfigurationPropertyCollection Properties
		{
			get
			{
				ConfigurationPropertyCollection properties = base.Properties;
				properties.Add(new ConfigurationProperty("contextMode",	typeof(ContextMode), ContextMode.HttpHeader, null, null, ConfigurationPropertyOptions.None));
				properties.Add(new ConfigurationProperty("uriTemplate", typeof(string), null, null, null, ConfigurationPropertyOptions.None));
				properties.Add(new ConfigurationProperty("uriTemplates", typeof(NameValueConfigurationCollection), new NameValueConfigurationCollection(), ConfigurationPropertyOptions.None));
				return properties;
			}
		}

		protected override void InitializeFrom(Binding binding)
		{
			base.InitializeFrom(binding);
			WebHttpContextBinding contextBinding = (WebHttpContextBinding)binding;

			this.ContextMode = contextBinding.ContextMode;
			foreach (string key in contextBinding.UriTemplates.Keys)
			{
				this.UriTemplates.Add(new NameValueConfigurationElement(key, contextBinding.UriTemplates[key]));
			}
		}

		protected override void OnApplyConfiguration(System.ServiceModel.Channels.Binding binding)
		{
			if (this.ContextMode == ContextMode.UriTemplate && this.UriTemplates.Count == 0)
			{
				throw new ConfigurationErrorsException("uriTemplates are required for UriTemplate context mode");
			}
			
			WebHttpContextBinding contextBinding = (WebHttpContextBinding)binding;

			contextBinding.ContextMode = this.ContextMode;
			foreach (NameValueConfigurationElement value in this.UriTemplates)
			{
				contextBinding.UriTemplates.Add(value.Name, value.Value);
			}
			
			base.OnApplyConfiguration(binding);
		}
		
		protected override Type BindingElementType
		{
			get
			{
				return typeof(WebHttpContextBinding);
			}
		}
	}
}
