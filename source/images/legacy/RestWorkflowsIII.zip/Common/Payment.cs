﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Common
{
	[Serializable]
	[DataContract(Name = "payment", Namespace = "http://starbucks.example.org")]
	public class Payment
	{
		public string OrderId { get; set; }

		[DataMember(Name = "cardNo")]
		public string CardNumber { get; set; }

		[DataMember(Name = "expires")]
		public string Expires { get; set; }

		[DataMember(Name = "name")]
		public string Name { get; set; }

		[DataMember(Name = "amount")]
		public decimal Amount { get; set; }
	}
}
