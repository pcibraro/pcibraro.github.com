﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Common
{
	[Serializable]
	[DataContract(Name="order", Namespace="http://starbucks.example.org")]
	public class Order
	{
		public string OrderId { get; set; }

		[DataMember(Name="drink")]
		public string Drink { get; set; }

		[DataMember(Name="cost")]
		public decimal? Cost { get; set; }

		[DataMember(Name="next")]
		public Next[] Next { get; set; }
	}

	[Serializable]
	[DataContract(Name="next", Namespace="http://example.org/state-machine")]
	public class Next
	{
		[DataMember(Name="rel")]
		public string Rel { get; set; }

		[DataMember(Name="uri")]
		public string Uri { get; set; }

		[DataMember(Name="type")]
		public string Type { get; set; }

		public Next()
		{
			Type = "application/xml";
		}
	}
}
