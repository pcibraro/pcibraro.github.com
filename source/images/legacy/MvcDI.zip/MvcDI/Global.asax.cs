﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Autofac.Builder;
using Autofac.Integration.Web.Mvc;
using System.Reflection;
using System.Web.Security;
using MvcDI.Controllers;
using Autofac.Integration.Web;

namespace MvcDI
{
	public class GlobalApplication : System.Web.HttpApplication, IContainerProviderAccessor
	{
		public static void RegisterRoutes(RouteCollection routes)
		{
			routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

			routes.MapRoute(
				"Default",                                              // Route name
				"{controller}/{action}/{id}",                           // URL with parameters
				new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
			);

		}

		static IContainerProvider containerProvider;

		protected void Application_Start()
		{
			RegisterRoutes(RouteTable.Routes);

			var builder = new ContainerBuilder();

			// Automatically register all controllers in the current assembly.
			builder.RegisterModule(new AutofacControllerModule(Assembly.GetExecutingAssembly()));

			builder.Register<MembershipProvider>(container => Membership.Provider).ExternallyOwned();
			builder.Register<FormsAuthenticationWrapper>().As<IFormsAuthentication>().FactoryScoped();
			
			containerProvider = new ContainerProvider(builder.Build());

			// Hook MVC factory.
			ControllerBuilder.Current.SetControllerFactory(new AutofacControllerFactory(containerProvider));
		}

		public IContainerProvider ContainerProvider
		{
			get { return containerProvider; }
		}
	}
}