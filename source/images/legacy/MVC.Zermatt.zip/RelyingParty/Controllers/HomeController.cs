﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Web;
using System.IdentityModel.Tokens;
using Microsoft.IdentityModel.Web.Controls;

namespace RelyingParty.Controllers
{
	[HandleError]
	public class HomeController : Controller
	{
		private IFederatedAuthentication authentication;

		public HomeController()
		{
			this.authentication = new FederatedAuthentication("Home/Logout");
		}

		public HomeController(IFederatedAuthentication authentication)
		{
			this.authentication = authentication;
		}

		public ActionResult Index()
		{
			ViewData["Title"] = "Home Page";
			ViewData["Message"] = "Welcome to ASP.NET MVC!";
			
			return View();
		}

		public ActionResult About()
		{
			ViewData["Title"] = "About Page";
			return View();
		}

		public ActionResult Login()
		{
			this.authentication.Authenticate();

			return Redirect("About"); //HACK To avoid request validations
		}
		
		public ActionResult Logout()
		{
			return RedirectToAction("Index");
		}
	}

	public interface IFederatedAuthentication
	{
		IClaimsPrincipal Authenticate();
	}

	public class FederatedAuthentication : IFederatedAuthentication
	{
		private string logoutUrl;

		public FederatedAuthentication(string logoutUrl)
		{
			this.logoutUrl = logoutUrl;
		}

		public IClaimsPrincipal Authenticate()
		{
			string securityTokenXml = FederatedAuthenticationModule.Current.GetXmlTokenFromPassiveSignInResponse(System.Web.HttpContext.Current.Request, null);

			FederatedAuthenticationModule current = FederatedAuthenticationModule.Current;
			
			SecurityToken token = null;
			IClaimsPrincipal authContext = current.AuthenticateUser(securityTokenXml, out token);

			TicketGenerationContext context = new TicketGenerationContext(authContext, false, logoutUrl, typeof(SignInControl).Name);
			current.IssueTicket(context);

			return authContext;
		}
	}
}
