﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using Microsoft.IdentityModel.Protocols.WSFederation;

namespace RelyingParty.Views.Home
{
	public partial class Index : ViewPage
	{
		//protected string GetClientScript()
		//{
		//    StringBuilder builder = new StringBuilder();
		//    builder.AppendLine();
		//    builder.AppendLine("<script type=\"text/javascript\">");
		//    builder.AppendLine("//<!--");
		//    builder.AppendLine("function " + this.ClientSideSignInFunction + "() {");
		//    builder.AppendLine("  var signInUrl = '" + this.GetSignInUrl() + "';");
			
		//    builder.AppendLine("  window.location.href = signInUrl;");
		//    builder.AppendLine("}");
		//    builder.AppendLine("//-->");
		//    builder.AppendLine("</script>");
		//    builder.AppendLine();
		//    return builder.ToString();
		//}

		//private string GetSignInUrl()
		//{
		//    string issuer = "https://localhost/SimplePassiveSTS/Default.aspx";
			
		//    SignInRequestMessage request = new SignInRequestMessage(new Uri(issuer));
		//    request.Realm = "https://localhost/SimpleWebApp/Default.aspx";
			
		//    //string reply = this.Reply;
		//    //if (!string.IsNullOrEmpty(reply))
		//    //{
		//    //    request.Reply = reply;
		//    //}
		//    //else
		//    //{
		//    request.Reply = "foo.aspx"; //UrlPath.RemoveQueryString(this.Page.Request.Url.AbsoluteUri);
		//    //}
			
		//    FederatedPassiveContext context = new FederatedPassiveContext(this.UniqueID, base.SignInContext, this.Context.Request.QueryString["ReturnUrl"], this.RememberMeSet);
		//    request.Context = context.WCtx;
		//    request.CurrentTime = DateTime.UtcNow.ToString("s", CultureInfo.InvariantCulture) + "Z";
		//    reply = this.Freshness;
		//    if (!string.IsNullOrEmpty(reply))
		//    {
		//        double result = -1.0;
		//        if (!double.TryParse(reply, out result) || (result < 0.0))
		//        {
		//            throw DiagnosticUtil.ExceptionUtil.ThrowHelperError(new InvalidOperationException(SR.GetString("ID5020", new object[0])));
		//        }
		//        request.Freshness = reply;
		//    }
		//    reply = this.AuthenticationType;
		//    if (!string.IsNullOrEmpty(reply))
		//    {
		//        request.AuthenticationType = reply;
		//    }
		//    reply = this.Policy;
		//    if (!string.IsNullOrEmpty(reply))
		//    {
		//        request.Policy = reply;
		//    }
		//    reply = this.Resource;
		//    if (!string.IsNullOrEmpty(reply))
		//    {
		//        request.Resource = reply;
		//    }
		//    reply = this.Request;
		//    if (!string.IsNullOrEmpty(reply))
		//    {
		//        request.Request = reply;
		//    }
		//    reply = this.RequestPtr;
		//    if (!string.IsNullOrEmpty(reply))
		//    {
		//        request.RequestPtr = reply;
		//    }
		//    NameValueCollection values = HttpUtility.ParseQueryString(this.SignInQueryString);
		//    foreach (string str4 in values.Keys)
		//    {
		//        request.Parameters.Add(str4, values[str4]);
		//    }
		//    return ControlUtil.GetPathAndQuery(request);
		//}


	}




}
