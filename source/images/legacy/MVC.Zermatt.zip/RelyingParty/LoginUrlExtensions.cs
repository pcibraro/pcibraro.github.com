﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Xml;

namespace System.Web.Mvc
{
	public static class LoginUrlExtensions
	{
		public static string LoginUrl(this UrlHelper helper, string actionName, string controllerName, string stsUrl)
		{
			string host = helper.ViewContext.HttpContext.Request.Url.Authority;
			string schema = helper.ViewContext.HttpContext.Request.Url.Scheme;

			string realm = string.Format("{0}://{1}", schema, host);
			string reply = helper.Action(actionName, controllerName).Substring(1);

			return string.Format("{0}?wa=wsignin1.0&wtrealm={1}&wreply={2}&wctx=rm=0&id=FederatedPassiveSignIn1&wct={3}",
				stsUrl, realm, reply, XmlConvert.ToString(DateTime.Now));
		}

		public static string LoginUrl(this UrlHelper helper, string actionName, string controllerName)
		{
			string sts = ConfigurationManager.AppSettings["StsUrl"];

			return LoginUrl(helper, actionName, controllerName, sts); 			
		}

		public static string LogoutUrl(this UrlHelper helper, string actionName, string controllerName)
		{
			string sts = ConfigurationManager.AppSettings["StsUrl"];

			return LogoutUrl(helper, actionName, controllerName, sts);
		}

		public static string LogoutUrl(this UrlHelper helper, string actionName, string controllerName, string stsUrl)
		{
			string host = helper.ViewContext.HttpContext.Request.Url.Authority;
			string schema = helper.ViewContext.HttpContext.Request.Url.Scheme;

			string realm = string.Format("{0}://{1}", schema, host);
			string reply = string.Format("{0}{1}", realm, helper.Action(actionName, controllerName));
			
			return string.Format("{0}?wa=wsignout1.0&wreply={1}",
				stsUrl, reply);
		}
	}
}
