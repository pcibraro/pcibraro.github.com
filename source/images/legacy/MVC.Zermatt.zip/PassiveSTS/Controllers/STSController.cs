﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.IdentityModel.Protocols.WSFederation;
using System.Globalization;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Services.SecurityTokenService;
using Microsoft.IdentityModel.Protocols.WSTrust;
using Microsoft.IdentityModel.Claims;
using System.Web.Security;

namespace PassiveSTS.Controllers
{
	public class STSController : Controller
	{
		ICredentialProvider credentialProvider;
		IClaimsProvider claimsProvider;

		public STSController()
		{
			this.credentialProvider = new CredentialProvider();
			this.claimsProvider = new ClaimsProvider(Membership.Provider);
		}

		public STSController(ICredentialProvider credentialProvider, IClaimsProvider claimsProvider)
		{
			this.credentialProvider = credentialProvider;
			this.claimsProvider = claimsProvider;
		}

		[Authorize]
		public ActionResult Index()
		{
			// Use WSFederationMessage.CreateFromUri to parse the request and create a WSFederationMessage. 
			WSFederationMessage federationMessage = WSFederationMessage.CreateFromUri(Request.Url);

			if (federationMessage.Action == WSFederationConstants.Actions.SignIn)
			{
				// Process the sign in request. 
				SignInResponseMessage responseMessage = ProcessSignInRequest(
					federationMessage as SignInRequestMessage);

				// Always Echo back the Context (wctx) which came on the request.
				responseMessage.Context = federationMessage.Context;

				// Write the response message.     
				return new SignInActionResult(responseMessage);
			}
			else if (federationMessage.Action == WSFederationConstants.Actions.SignOut ||
					  federationMessage.Action == WSFederationConstants.Actions.SignOutCleanup)
			{
				SignOutRequestMessage requestMessage = federationMessage as SignOutRequestMessage;
				return RedirectToAction("Logout", "Account", new { returnUrl = requestMessage.Reply });
			}
			else
			{
				throw new InvalidOperationException(String.Format(
							  CultureInfo.InvariantCulture, "Unsupported Action: {0}", federationMessage.Action));
			}
		}

		

		private SignInResponseMessage ProcessSignInRequest(SignInRequestMessage requestMessage)
		{
			if (requestMessage == null)
			{
				throw new ArgumentNullException("requestMessage");
			}

			// Ensure that the requestMessage has the required wtrealm parameter
			if (String.IsNullOrEmpty(requestMessage.Realm))
			{
				throw new InvalidOperationException(
							  "Incoming Passive Request message didn't contain the wtrealm parameter.");
			}

			SecurityTokenServiceConfiguration configuration = new SecurityTokenServiceConfiguration("PassiveSTS");
			
			// Create the STS.
			SecurityTokenService sts = new MySecurityTokenService(configuration, this.credentialProvider, this.claimsProvider, requestMessage.Reply);

			// Create the WS-Federation serializer to process the request and create the response.
			// This creates the default WSFederationSerializer that handles the WS-Trust Feb 2005 specification.
			WSFederationSerializer federationSerializer = new WSFederationSerializer();

			// Create RST from the request
			RequestSecurityToken request = federationSerializer.CreateRequest(
				requestMessage, new WSTrustSerializationContext());

			// Get RSTR from the STS.
			RequestSecurityTokenResponse response = sts.Issue(ClaimsPrincipal.Current, request);

			// Create WS-Federation Response message from the RSTR
			return new SignInResponseMessage(new Uri(response.ReplyTo),
				federationSerializer.GetResponseAsString(response, new WSTrustSerializationContext()));

		}
	}
}
