﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.IdentityModel.Protocols.WSFederation;

namespace PassiveSTS
{
	public class SignInActionResult : ActionResult
	{
		SignInResponseMessage responseMessage;

		public SignInActionResult(SignInResponseMessage responseMessage)
		{
			this.responseMessage = responseMessage;
		}

		public override void ExecuteResult(ControllerContext context)
		{
			this.responseMessage.Write(context.HttpContext.Response.Output);
			
			context.HttpContext.Response.Flush();
			context.HttpContext.Response.End();
		}
	}
}
