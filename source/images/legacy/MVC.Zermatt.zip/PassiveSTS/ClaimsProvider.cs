﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.IdentityModel.Claims;
using System.Web.Security;
using System.Web.Profile;

namespace PassiveSTS
{
	public interface IClaimsProvider
	{
		IEnumerable<Claim> GetClaims(IClaimsPrincipal principal);
	}

	public class ClaimsProvider : IClaimsProvider
	{
		MembershipProvider membershipProvider;

		public ClaimsProvider(MembershipProvider provider)
		{
			this.membershipProvider = provider;
		}

		public IEnumerable<Claim> GetClaims(IClaimsPrincipal principal)
		{
			MembershipUser user = membershipProvider.GetUser(principal.Identity.Name, false);
			
			yield return new Claim(System.IdentityModel.Claims.ClaimTypes.Name, principal.Identity.Name);
			yield return new Claim(System.IdentityModel.Claims.ClaimTypes.Email, user.Email, ClaimValueTypes.Email);
			yield return new Claim("http://ZermattSamples/2008/05/AgeClaim", "29", ClaimValueTypes.Integer);

			yield break;
		}
	}
}
