﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.IdentityModel.Services.SecurityTokenService;
using System.IdentityModel.Tokens;
using Microsoft.IdentityModel.Services;
using System.Security.Cryptography.X509Certificates;

namespace PassiveSTS
{
	public interface ICredentialProvider
	{
		EncryptingCredentials GetEncryptingCredential(string appliesTo);
		SigningCredentials GetSigningCredentials();
	}

	public class CredentialProvider : ICredentialProvider
	{
		ICertificateResolver certificateResolver;

		public CredentialProvider()
		{
			this.certificateResolver = new CertificateResolver();
		}

		public CredentialProvider(ICertificateResolver certificateResolver)
		{
			this.certificateResolver = certificateResolver;
		}
		
		public EncryptingCredentials GetEncryptingCredential(string appliesTo)
		{
			MySecurityTokenServiceConfiguration section = MySecurityTokenServiceConfiguration.GetSection();

			ServiceCertificateConfiguration serviceConfig = section.ServiceCertificates.Item(appliesTo);
			if (serviceConfig == null)
			{
				throw new InvalidRequestException(string.Format("The AppliesTo address {0} is not supported by this identity provider", appliesTo));
			}

			EncryptingCredentials encryptingCredentials = new X509EncryptingCredentials(
				certificateResolver.Resolve(serviceConfig.StoreLocation, serviceConfig.StoreName, serviceConfig.FindType, serviceConfig.FindValue));

			return encryptingCredentials;
		}

		public SigningCredentials GetSigningCredentials()
		{
			MySecurityTokenServiceConfiguration section = MySecurityTokenServiceConfiguration.GetSection();

			CertificateConfiguration issuer = section.IssuerCertificate; 

			SigningCredentials signingCredentials = new X509SigningCredentials(
				certificateResolver.Resolve(issuer.StoreLocation, issuer.StoreName, issuer.FindType, issuer.FindValue));

			return signingCredentials;
		}
	}
}
