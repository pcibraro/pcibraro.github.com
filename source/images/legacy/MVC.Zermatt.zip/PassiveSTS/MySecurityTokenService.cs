using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.ServiceModel;
using System.Xml.Linq;

using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Services;
using Microsoft.IdentityModel.Services.SecurityTokenService;

namespace PassiveSTS
{
    /// <summary>
    /// Extends the Microsoft.IdentityModel.Services.SecurityTokenService class to provide
    /// necessary information required to issue a security token. Such as encryption credentials to 
    /// encrypt the issued token, signing credentials to sign the issued token, claims that STS  
    /// wants to issue for the token request.
    /// </summary>
    public class MySecurityTokenService : SecurityTokenService
    {
		ICredentialProvider credentialProvider;
		IClaimsProvider claimsProvider;
		string replyAddress;

		public MySecurityTokenService(SecurityTokenServiceConfiguration configuration, ICredentialProvider credentialProvider, IClaimsProvider claimsProvider, string replyAddress)
			: base(configuration)
		{
			this.credentialProvider = credentialProvider;
			this.claimsProvider = claimsProvider;
			this.replyAddress = replyAddress;
		}

        /// <summary>
        /// This methods returns the configuration for the token issuance request. The configuration
        /// is represented by the Scope class. 
        /// </summary>
        /// <param name="principal">The caller's principal</param>
        /// <param name="request">The incoming RST</param>
        /// <returns></returns>
        protected override Scope GetScope( IClaimsPrincipal principal, RequestSecurityToken request )
        {
			EncryptingCredentials encryptingCredentials = this.credentialProvider.GetEncryptingCredential(request.AppliesTo.Uri.ToString());
			SigningCredentials signingCredentials = this.credentialProvider.GetSigningCredentials();

            Scope scope = new Scope(request, signingCredentials);

            // Setting the encrypting credentials
            // If you have multiple RPs for the STS you would select the certificate that is specific to 
            // the RP that requests the token.
			scope.EncryptingCredentials = encryptingCredentials;

            // Set the ReplyTo address for the WS-Federation passive protocol 
            // (this is not used in the WS-Trust active case)
			scope.ReplyToAddress = scope.AppliesToAddress + replyAddress;

            return scope;
        }

        /// <summary>
        /// This methods returns the content of the issued token. The content is represented as a set of
        /// IClaimIdentity intances, each instance corresponds to a single issued token. Currently, IDFx only
        /// supports a single token issuance, so the returned collection must always contain only a single instance.
        /// </summary>
        /// <param name="scope">The scope that was previously returned by GetScope method</param>
        /// <param name="principal">The caller's principal</param>
        /// <param name="request">The incoming RST, we don't use this in our implementation</param>
        /// <returns></returns>
        public override ClaimsIdentityCollection GetOutputSubjects( Scope scope, IClaimsPrincipal principal, RequestSecurityToken request )
        {
            ClaimsIdentity outputIdentity = new ClaimsIdentity();

			foreach (Claim claim in claimsProvider.GetClaims(principal))
			{
				outputIdentity.Claims.Add(claim);
			}
			
            return new ClaimsIdentityCollection( outputIdentity );
        }
    }
}
