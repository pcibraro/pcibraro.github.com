﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Security.Cryptography.X509Certificates;

namespace PassiveSTS
{
	public class MySecurityTokenServiceConfiguration : ConfigurationSection
    {
        public MySecurityTokenServiceConfiguration() : base()
        {
        }

        [ConfigurationProperty("issuerCertificate", IsRequired = true)]
		public CertificateConfiguration IssuerCertificate
        {
			get { return (CertificateConfiguration)base["issuerCertificate"]; }
        }

		[ConfigurationProperty("serviceCertificates")]
		public ServiceCertificateCollection ServiceCertificates
		{
			get { return (ServiceCertificateCollection)base["serviceCertificates"]; }
		}

		public static MySecurityTokenServiceConfiguration GetSection()
		{
			return (MySecurityTokenServiceConfiguration)ConfigurationManager.GetSection("mySecurityTokenService");
		}
	}
	
	public class ServiceCertificateCollection : ConfigurationElementCollection
    {
        public ServiceCertificateCollection() : base()
        {
        }

        public void Add(ConfigurationElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }

            BaseAdd(element);
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ServiceCertificateConfiguration();
        }

        protected override Object GetElementKey(ConfigurationElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }

            ServiceCertificateConfiguration serviceCertificateConfiguration = (ServiceCertificateConfiguration)element;
            return serviceCertificateConfiguration.AppliesTo.ToString();
        }

        internal bool Contains(string appliesTo)
        {
            return Item(appliesTo) != null;
        }

        internal ServiceCertificateConfiguration Item(string appliesTo)
        {
            foreach (ServiceCertificateConfiguration ele in this)
            {
                if (ele.AppliesTo == appliesTo)
                {
                    return ele;
                }
            }

            return null;
        }
	}
	
	public class CertificateConfiguration : ConfigurationElement
    {
		public CertificateConfiguration()
            : base()
        {
        }

		[ConfigurationProperty("storeLocation", DefaultValue = StoreLocation.LocalMachine)]
		public StoreLocation StoreLocation
        {
            get { return (StoreLocation)base["storeLocation"]; }
        }

		[ConfigurationProperty("storeName", DefaultValue = StoreName.My)]
		public StoreName StoreName
        {
            get { return (StoreName)base["storeName"]; }
        }

        [ConfigurationProperty("findValue", IsRequired = true)]
		public string FindValue
        {
            get { return (string)base["findValue"]; }
        }

        [ConfigurationProperty("findType", IsRequired = true)]
		public X509FindType FindType
        {
            get { return (X509FindType)base["findType"]; }
        }
	}

	public class ServiceCertificateConfiguration : CertificateConfiguration
	{
		public ServiceCertificateConfiguration()
			: base()
		{
		}

		[ConfigurationProperty("appliesTo", IsRequired = true)]
		public string AppliesTo
		{
			get { return (string)base["appliesTo"]; }
		}
	}
}
