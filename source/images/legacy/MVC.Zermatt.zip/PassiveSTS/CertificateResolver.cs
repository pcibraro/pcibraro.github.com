﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography.X509Certificates;

namespace PassiveSTS
{
	public interface ICertificateResolver
	{
		X509Certificate2 Resolve(StoreLocation location, StoreName name, X509FindType findType, string findValue);
	}

	public class CertificateResolver : ICertificateResolver
	{
		public X509Certificate2 Resolve(StoreLocation storelocation, StoreName storeName, X509FindType findType, string findValue)
		{
			X509Store store = new X509Store(storeName, storelocation);

			try
			{
				store.Open(OpenFlags.OpenExistingOnly);
				X509Certificate2Collection collection = store.Certificates.Find(findType, findValue, true);

				if (collection.Count > 0)
				{
					return collection[0];
				}
				else
				{
					throw new Exception(String.Format("The certificate {0} could not be found ", findValue));
				}
			}
			finally
			{
				store.Close();
			}

		}
	}
}
