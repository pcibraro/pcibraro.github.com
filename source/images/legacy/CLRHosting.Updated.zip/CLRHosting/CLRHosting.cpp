// CLRHosting.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "clrloader.h"

#pragma comment(linker, "/EXPORT:Execute=_Execute@4")

extern "C" UINT __stdcall Execute (MSIHANDLE hInstall) {
	  
	HRESULT hr = S_OK;

	// Create an instance of a managed addin
	// and fetch the interface pointer
    CCLRLoader *pCLRLoader = CCLRLoader::TheInstance();
	pCLRLoader->m_MsiHandle = hInstall;
	IfNullGo(pCLRLoader);
    IfFailGo(pCLRLoader->RunCustomActions());
	
	return ERROR_SUCCESS;

	Error:
		return hr;	
	
  
}
//
//extern "C" __declspec(dllexport) UINT MsiWriteToLog(MSIHANDLE hMSI, LPCSTR strMessage, bool isError)
//{
//	INSTALLMESSAGE msgType = INSTALLMESSAGE_INFO;
//
//	if(isError)
//		msgType = INSTALLMESSAGE_ERROR;
//
//    MSIHANDLE hrec=MsiCreateRecord(1);
//    MsiRecordSetString(hrec,0, strMessage);
//    MsiProcessMessage(hMSI, msgType, hrec);
//    MsiCloseHandle(hrec);
//    return ERROR_SUCCESS;
//}


//
//void WriteToLog1(MSIHANDLE hMSI, String* strMessage)
//{
//
//    CHAR* strMessageArr={0};
//    strMessageArr=(char*)(void*)Marshal::StringToHGlobalAnsi(strMessage);
//    WriteToLog(hMSI,strMessageArr);
//
//}