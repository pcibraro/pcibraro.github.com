static LPCWSTR szCLRVersion = L"v1.1.4322";

static LPCWSTR szCLRFlavor = L"wks";

static LPCWSTR szApplicationName = L"MsiHosting";

static TCHAR* szApplicationConfigFile = "MsiHosting.config";

static OLECHAR FAR* szCustomActionMember = L"RunActions";

static TCHAR* szAssemblyName = "CustomActionRuntime";

static TCHAR* szClassName = "CustomActionRuntime.Runtime";

static TCHAR* szCustomActionRuntimeBinaryKey = "CustomActionRuntime";

static TCHAR* szApplicationConfigFileBinaryKey = "MsiHostingConfig";
