// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Security.Tokens;
using System.ServiceModel.Channels;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                                
                ChannelFactory<IHelloWorldChannel> factory = new ChannelFactory<IHelloWorldChannel>("clientendpoint");
                //factory.Credentials.UserName.UserName = "MyUser";
                //factory.Credentials.UserName.Password = "MyPassword";
                
                IHelloWorldChannel helloWorldService = factory.CreateChannel();
                
                string response = helloWorldService.HelloWorld("John Doe");
                                
                Console.WriteLine(response);
            }
            catch (FaultException e)
            {
                Console.WriteLine(e.ToString()); 
            }
        }

        


    }


}
