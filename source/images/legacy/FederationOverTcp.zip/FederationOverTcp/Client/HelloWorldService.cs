﻿// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System.ServiceModel;
using System;
using System.Xml.Serialization;
using System.Runtime.Serialization;

[ServiceContract()]
public interface IHelloWorld
{
	[OperationContract(Name = "helloWorld")]
	string HelloWorld(string message);
}

public interface IHelloWorldChannel : IHelloWorld, System.ServiceModel.IClientChannel
{
}

