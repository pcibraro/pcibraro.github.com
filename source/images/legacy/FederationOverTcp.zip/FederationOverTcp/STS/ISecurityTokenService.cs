using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Samples.Security.STS
{
    /// <summary>
    /// WCF contract for a Secure Token Service
    /// </summary>
	[ServiceContract]
    public interface ISecurityTokenService
    {
        [OperationContract(Action = Constants.Trust.Actions.Issue, ReplyAction = Constants.Trust.Actions.IssueReply)]
		Message IssueToken(Message rstMessage);
    }
}
