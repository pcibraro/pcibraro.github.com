using System;
using System.Web;
using System.Collections;
using System.Configuration;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Xml;

namespace Samples.Security.STS
{   
	/// <summary>
	/// STS Configuration section
	/// </summary>
    public sealed class STSConfiguration : ConfigurationSection
    {
        const string SectionName = "Samples.Security.STS";

        private ConfigurationProperty _samlTokenIssuerConfiguration = new ConfigurationProperty("samlTokenIssuer", typeof(STSTokenIssuerConfiguration), null, ConfigurationPropertyOptions.None);
        private ConfigurationPropertyCollection _properties = new ConfigurationPropertyCollection();

        static STSConfiguration _configuration = null;
        static Exception _configurationException = null;
        static object _configurationLock = new object();

        static STSConfiguration Current 
		{
            get
            {
                if (_configuration == null)
                {
                    lock (_configurationLock)
                    {
                        if (_configuration == null)
                        {
                            STSConfiguration configuration = null;

                            if (_configurationException == null)
                            {
                                try
                                {
                                    if (configuration == null)
                                    {
                                        configuration = (STSConfiguration)ConfigurationManager.GetSection(STSConfiguration.SectionName);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //
                                    // Cache the exception for perf reason
                                    //
                                    _configurationException = ex;

                                    //
                                    // rethrow
                                    //
                                    throw new ConfigurationErrorsException(Resources.ConfigurationUnexpectedError, ex);
                                }
                            }
                            else
                            {
                                //
                                // rethrow
                                //
								throw new ConfigurationErrorsException(Resources.ConfigurationUnexpectedError, _configurationException);
                            }

                            if (configuration == null)
                            {
                                configuration = new STSConfiguration();
                            }

                            _configuration = configuration;
                        }
                    }
                }

                return _configuration;
            }
        }

		public STSConfiguration()
            : base()
        {
            _properties.Add(_samlTokenIssuerConfiguration);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get { return _properties; }
        }

        private static void Initialize()
        {
            // Just load up the config, if not already loaded.
			STSConfiguration config = STSConfiguration.Current;
        }
        public static STSTokenIssuerConfiguration SamlTokenIssuerConfiguration
        {
            get
            {
                Initialize();
                return (STSTokenIssuerConfiguration)_configuration[_configuration._samlTokenIssuerConfiguration];
            }
        }

	}

}
 

