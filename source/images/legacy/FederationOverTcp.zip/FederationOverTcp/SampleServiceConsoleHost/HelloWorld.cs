using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

using System.Xml;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace SampleServiceConsoleHost
{
    [ServiceContract()]
    interface IHelloWorld
    {
        [OperationContract(Name = "helloWorld")]
        string HelloWorld(string message);
    }

    class HelloWorldService : IHelloWorld
    {
        #region IHelloWorld Members
        
        public string HelloWorld(string message)
        {
            return "Hello World : " + message;
        }

       
        #endregion
        
    }
}
