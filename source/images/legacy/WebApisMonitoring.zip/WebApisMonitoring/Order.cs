﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace WebApisMonitoring
{
	public class Order
	{
		public int OrderId { get; set; }

		public string FullName { get; set; }

		public ShippingDetails Shipping { get; set; }

		[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "value", Justification = "Json Serializer doesn't support read only")]
		public string Self
		{
			get { return string.Format(CultureInfo.CurrentCulture, "order/{0}", this.OrderId); }
			set { }
		}
	}

	public class ShippingDetails
	{
		public string Address { get; set; }

		public string City { get; set; }

		public string State { get; set; }

		public string Zip { get; set; }

		public string Email { get; set; }
	}

	
}