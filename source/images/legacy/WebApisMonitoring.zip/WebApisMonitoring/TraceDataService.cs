﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Services;
using System.Data.Services.Common;
using System.ServiceModel.Web;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web.Hosting;

namespace WebApisMonitoring
{
	public class TraceDataService : DataService<TraceDataSource>
	{
		public static void InitializeService(DataServiceConfiguration config)
		{
			config.SetEntitySetAccessRule("*", EntitySetRights.AllRead);
			config.SetServiceOperationAccessRule("*", ServiceOperationRights.AllRead);

			config.SetEntitySetPageSize("TraceEvents", 50);

			config.DataServiceBehavior.AcceptCountRequests = true;
			config.DataServiceBehavior.AcceptProjectionRequests = true;
			config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;

			config.UseVerboseErrors = true;
		}
		
		[WebGet]
		public IQueryable<TraceEvent> all()
		{
			var virtualPath = HostingEnvironment.ApplicationVirtualPath;

			var eventSources = this.CurrentDataSource.EventSources
				.Where(e => e.ApplicationVirtualPath.StartsWith(virtualPath))
				.Select(e => e.Id)
				.ToArray();

			var events = this.CurrentDataSource.TraceEvents
				.Where(t => eventSources.Contains(t.EventSourceId));

			return events;
		}
	}
}