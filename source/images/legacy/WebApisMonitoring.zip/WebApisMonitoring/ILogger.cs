﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApisMonitoring
{
	public interface ILogger
	{
		string ActivityId { get; }

		bool WriteError(string name, string format, params object[] args);
		bool WriteWarning(string name, string format, params object[] args);
		bool WriteInformation(string name, string format, params object[] args);
	}
}