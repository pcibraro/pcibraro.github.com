﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Http;

namespace WebApisMonitoring
{
	public static class HttpResponseExtensions
	{
		public static void AddActivityHeader(this HttpResponseMessage response, string activityId)
		{
			response.Headers.AddWithoutValidation("X-Trace-ActivityId", activityId);
		}
	}
}