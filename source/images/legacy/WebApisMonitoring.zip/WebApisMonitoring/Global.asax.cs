﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Routing;
using Microsoft.ServiceModel.Http;
using System.ComponentModel.Composition.Hosting;
using System.ServiceModel.Activation;
using System.Data.Services;

namespace WebApisMonitoring
{
	public class Global : System.Web.HttpApplication
	{

		protected void Application_Start(object sender, EventArgs e)
		{
			//use MEF for providing instances
			var catalog = new AssemblyCatalog(typeof(Global).Assembly);
			var container = new CompositionContainer(catalog);

			var configuration = new OrderManagerConfiguration(container);
			
			RouteTable.Routes.AddServiceRoute<OrderResource>("order", configuration);
			RouteTable.Routes.AddServiceRoute<OrdersResource>("orders", configuration);

			RouteTable.Routes.Add("traces", new ServiceRoute("traces",
				new DataServiceHostFactory(),
				typeof(TraceDataService)));
		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{

		}

		protected void Application_End(object sender, EventArgs e)
		{

		}
	}
}