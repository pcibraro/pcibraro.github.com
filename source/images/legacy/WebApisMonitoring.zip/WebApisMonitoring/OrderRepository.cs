﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.Composition;

namespace WebApisMonitoring
{
	[Export(typeof(IOrderRepository))]
	public class OrderRepository : IOrderRepository
	{
		static List<Order> AllOrders = new List<Order> { 
			new Order 
			{
 				OrderId = 1,
				FullName = "Pablo Cibraro",
				Shipping = new ShippingDetails
				{
					Address = "My Address",
					City = "Buenos Aires",
					Email = "myEmail@mail.com",
					State = "BA",
					Zip = "22209"
				}
			},
			new Order 
			{
 				OrderId = 2,
				FullName = "Jorge Gonzalez",
				Shipping = new ShippingDetails
				{
					Address = "Another Address",
					City = "Buenos Aires",
					Email = "another@mail.com",
					State = "BA",
					Zip = "22209"
				}
			}
		};

		public IQueryable<Order> All 
		{ 
			get { return AllOrders.AsQueryable(); } 
		}
	}
}