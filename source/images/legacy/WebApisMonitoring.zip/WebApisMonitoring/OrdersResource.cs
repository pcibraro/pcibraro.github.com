﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Web;
using System.ServiceModel;
using System.ComponentModel.Composition;
using System.Net.Http;

namespace WebApisMonitoring
{
	[ServiceContract]
	[Export]
	public class OrdersResource
	{
		IOrderRepository repository;
		ILogger logger;

		[ImportingConstructor]
		public OrdersResource(IOrderRepository repository, ILogger logger)
		{
			this.repository = repository;
			this.logger = logger;
		}

		[WebGet(UriTemplate = "")]
		[QueryComposition(Enabled=true)]
		public IEnumerable<Order> Get(HttpResponseMessage response)
		{
			this.logger.WriteInformation("Orders Requested", "All Orders");

			response.AddActivityHeader(this.logger.ActivityId);

			return repository.All;
		}
	}
}