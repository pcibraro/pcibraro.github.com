﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Web;
using System.Net.Http;
using System.Net;
using System.Globalization;
using System.ServiceModel;
using System.ComponentModel.Composition;

namespace WebApisMonitoring
{
	[ServiceContract]
	[Export]
	public class OrderResource
	{
		IOrderRepository repository;
		ILogger logger;

		[ImportingConstructor]
		public OrderResource(IOrderRepository repository, ILogger logger)
		{
			this.repository = repository;
			this.logger = logger;
		}

		[WebGet(UriTemplate = "{id}")]
		public Order Get(string id, HttpResponseMessage response)
		{
			var order = this.repository.All.FirstOrDefault(o => o.OrderId == int.Parse(id, CultureInfo.InvariantCulture));
			if (order == null)
			{
				response.StatusCode = HttpStatusCode.NotFound;
				response.Content = new StringContent("Order not found");
			}

			this.logger.WriteInformation("Order Requested", "Order Id {0}", id);

			response.AddActivityHeader(this.logger.ActivityId);

			return order;
		}
	}
}