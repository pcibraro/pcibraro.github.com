// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Channels;

using RSTConstants = Gudge.Samples.Security.RSTRSTR.Constants;

namespace WCF.SAML
{
    [ServiceContract]
    public interface ISecurityTokenService
    {
        [OperationContract(Action = RSTConstants.Trust.Actions.Issue, ReplyAction = RSTConstants.Trust.Actions.IssueReply)]
        Message IssueToken(Message rstMessage);
    }
}
