// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Security.Tokens;
using System.IdentityModel.Selectors;

namespace WCF.SAML
{
    /// <summary>
    /// Custom credentials. This implementation returns a custom security token manager
    /// </summary>
    public class CustomCredentials : ServiceCredentials
    {
        public CustomCredentials()
            : base()
        {
        }

        protected override ServiceCredentials CloneCore()
        {
            return new CustomCredentials();
        }

        public override SecurityTokenManager CreateSecurityTokenManager()
        {
            
            return new CustomSecurityTokenManager(this);
        }
    }

    
}

