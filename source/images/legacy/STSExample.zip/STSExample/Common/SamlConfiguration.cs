// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Web;
using System.Collections;
using System.Configuration;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Xml;

namespace WCF.SAML
{   
    public sealed class SamlConfiguration : ConfigurationSection
    {
        const string SectionName = "WcfSaml";

        private ConfigurationProperty _samlTokenIssuerConfiguration = new ConfigurationProperty("samlTokenIssuer", typeof(SamlTokenIssuerConfiguration), null, ConfigurationPropertyOptions.None);
        private ConfigurationPropertyCollection _properties = new ConfigurationPropertyCollection();

        static SamlConfiguration _configuration = null;
        static Exception _configurationException = null;
        static object _configurationLock = new object();
        static int _recursionGuard = 0;

        static SamlConfiguration Current 
		{
            get
            {
                if (_configuration == null)
                {
                    lock (_configurationLock)
                    {
                        if (_configuration == null)
                        {
                            SamlConfiguration configuration = null;

                            if (_configurationException == null)
                            {
                               if (Interlocked.CompareExchange(ref _recursionGuard, 1, 0) > 0)
                                    throw new ConfigurationErrorsException(Messages.ConfigurationNotInitialized);

                                try
                                {
                                    if (configuration == null)
                                    {
                                        configuration = (SamlConfiguration)ConfigurationManager.GetSection(SamlConfiguration.SectionName);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //
                                    // Cache the exception for perf reason
                                    //
                                    _configurationException = ex;

                                    //
                                    // rethrow
                                    //
                                    throw new ConfigurationErrorsException(Messages.ConfigurationUnexpectedError, ex);
                                }
                            }
                            else
                            {
                                //
                                // rethrow
                                //
								throw new ConfigurationErrorsException(Messages.ConfigurationUnexpectedError, _configurationException);
                            }

                            if (configuration == null)
                            {
                                configuration = new SamlConfiguration();
                            }

                            _configuration = configuration;
                        }
                    }
                }

                return _configuration;
            }
        }

        public SamlConfiguration()
            : base()
        {
            _properties.Add(_samlTokenIssuerConfiguration);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get { return _properties; }
        }

        private static void Initialize()
        {
            // Just load up the config, if not already loaded.
            SamlConfiguration config = SamlConfiguration.Current;
        }
        public static SamlTokenIssuerConfiguration SamlTokenIssuerConfiguration
        {
            get
            {
                Initialize();
                return (SamlTokenIssuerConfiguration)_configuration[_configuration._samlTokenIssuerConfiguration];
            }
        }

	}

}
 

