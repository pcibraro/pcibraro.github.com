// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.ServiceModel;
using System.ServiceModel.Security;
using System.ServiceModel.Security.Tokens;
using System.Security.Cryptography.X509Certificates;
using System.Collections;

using System.ServiceModel.Description;

using WCF.SAML;

namespace WCF.SAML
{
    /// <summary>
    /// This token manager knows how to handle a SAML token. 
    /// </summary>
    public class CustomSecurityTokenManager : ServiceCredentialsSecurityTokenManager
    {
        public CustomSecurityTokenManager(CustomCredentials customCredentials)
            : base(customCredentials)
        {
            
        }

        public override SecurityTokenAuthenticator CreateSecurityTokenAuthenticator(SecurityTokenRequirement tokenRequirement, out SecurityTokenResolver outOfBandTokenResolver)
        {
            
            if (tokenRequirement.TokenType ==  Constants.TokenType)
            {
                List<SecurityToken> tokens = SamlConfiguration.SamlTokenIssuerConfiguration.GetAllServiceTokens(); 
                                
                List<SecurityTokenAuthenticator> securityAuthenticators = new List<SecurityTokenAuthenticator>();
                securityAuthenticators.Add(new X509SecurityTokenAuthenticator(X509CertificateValidator.None));

                outOfBandTokenResolver = SecurityTokenResolver.CreateDefaultSecurityTokenResolver(tokens.AsReadOnly(), true);
                return new SamlSecurityTokenAuthenticator(securityAuthenticators);
            }
            else
            {
                return base.CreateSecurityTokenAuthenticator(tokenRequirement, out outOfBandTokenResolver);
            }
        }
    }

    
}
