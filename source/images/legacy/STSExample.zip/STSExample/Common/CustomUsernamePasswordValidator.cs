// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;

using System.IdentityModel.Selectors;

namespace WCF.SAML
{
    /// <summary>
    /// Custom password validator. This sample does not validate the password that receives in the 
    /// Username token
    /// </summary>
    public class CustomUsernamePasswordValidator : UserNamePasswordValidator
    {
        public override void Validate(string userName, string password)
        {
            UserNamePasswordValidator.None.Validate(userName, password);
        }
    }
}
