// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;

namespace WCF.SAML
{
    public sealed class Constants
    {
        public const string TokenType = "http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1";
        public const string AssertionIdPrefix = "SamlSecurityToken-";
    }
}
