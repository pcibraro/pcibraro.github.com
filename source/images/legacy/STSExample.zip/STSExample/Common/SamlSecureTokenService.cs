// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Security;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Channels;
using System.ServiceModel.Security.Tokens;
using System.IdentityModel.Tokens;
using System.Security.Cryptography;
using System.Threading;
using System.Security.Cryptography.X509Certificates;

using RequestSecurityToken = Gudge.Samples.Security.RSTRSTR.RequestSecurityToken;
using RequestSecurityTokenResponse = Gudge.Samples.Security.RSTRSTR.RequestSecurityTokenResponse;
using RSTConstants = Gudge.Samples.Security.RSTRSTR.Constants;

namespace WCF.SAML
{    
    /// <summary>
    /// This is a service to handle Request Security Token (RST) for WS-SecureConversation
    /// This implementation will issue a SamlToken
    /// </summary>
    public class SamlSecureTokenService : ISecurityTokenService
    {
        public SamlSecureTokenService()
        {
            
        }

        #region ISecurityTokenService Members

        /// <summary>
        /// This method receives a RST message and issues a SAML token
        /// </summary>
        /// <param name="rstMessage"></param>
        /// <returns></returns>
        public Message IssueToken(Message rstMessage)
        {
            RequestSecurityToken rst = RequestSecurityToken.CreateFrom(rstMessage.GetReaderAtBodyContents());
            
            if (Constants.TokenType != rst.TokenType)
            {
                throw new NotSupportedException(String.Format(Messages.UnsupportedTokenType, rst.TokenType));
            }

            // setup RSTR
            RequestSecurityTokenResponse rstr = new RequestSecurityTokenResponse();
            
            rstr.AppliesTo = rst.AppliesTo;
            rstr.Context = rst.Context;

            SecurityKeyIdentifier proofKeyIdentifier = null;
            if (rst.KeyType == RSTConstants.Trust.KeyTypes.Symmetric)
            {
                // generate proof token
                proofKeyIdentifier = this.GenerateSymmetricProofKey(rst, rstr);
            }
            else if (rst.KeyType == RSTConstants.Trust.KeyTypes.Public)
            {
                // generate proof token
                proofKeyIdentifier = this.GenerateAsymmetricProofKey(rst, rstr);
            }
            else
            {
                throw new NotSupportedException(String.Format(Messages.UnsuportedKeyType, rst.KeyType));
            }

            if (proofKeyIdentifier == null)
            {
                throw new NullReferenceException(Messages.InvalidProofToken);
            }

            // generate security token to issue
            SecurityToken issuedToken = this.GenerateSamlToken(rst, rstr, proofKeyIdentifier);
                                    
            //attach security token to RSTR
            rstr.RequestedSecurityToken = issuedToken;
            rstr.TokenType = rst.TokenType;

            // send RSTR
            //rstr.MakeReadOnly();
            Message rstrMessage = Message.CreateMessage(rstMessage.Version, RSTConstants.Trust.Actions.IssueReply, rstr);
            rstrMessage.Headers.RelatesTo = rstMessage.Headers.MessageId;
            rstMessage.Headers.ReplyTo.ApplyTo(rstrMessage);

            return rstrMessage;
        }

        #endregion

        #region Private methods

        /// <summary>
        /// Creates the SAML token using the information provided in the RST message.
        /// </summary>
        private SecurityToken GenerateSamlToken(RequestSecurityToken rst, RequestSecurityTokenResponse rstr, SecurityKeyIdentifier proofKeyIdentifier)
        {
            // create saml:Assertion
            SamlAssertion samlAssertion = new SamlAssertion();
            samlAssertion.AssertionId = Constants.AssertionIdPrefix + Guid.NewGuid().ToString();
            samlAssertion.Conditions = new SamlConditions(DateTime.UtcNow, DateTime.Now.AddSeconds(SamlConfiguration.SamlTokenIssuerConfiguration.TtlInSeconds));

            samlAssertion.Issuer = OperationContext.Current.IncomingMessageHeaders.To.ToString();

            X509SecurityToken signingToken = (X509SecurityToken)SamlConfiguration.SamlTokenIssuerConfiguration.GetAuthorityToken();
                        
            X509AsymmetricSecurityKey signingKey = new X509AsymmetricSecurityKey(signingToken.Certificate);
                                                
            samlAssertion.SigningCredentials = new SigningCredentials(signingKey, SecurityAlgorithms.RsaSha1Signature, SecurityAlgorithms.Sha1Digest,
                new SecurityKeyIdentifier(new X509ThumbprintKeyIdentifierClause(signingToken.Certificate)));
            
            this.GenerateSamlStatements(samlAssertion.Statements, proofKeyIdentifier, rst);

            // create SamlToken
            SamlSecurityToken samlToken = new SamlSecurityToken(samlAssertion);
            
            return samlToken;
        }

        #endregion

        #region Protected methods

        /// <summary>
        /// Creates the statements for the SAML token
        /// </summary>
        /// <param name="statements">Collection of statements that will be included in the token</param>
        /// <param name="proofKeyIdentifier">Proof key identifier for the token</param>
        /// <param name="data">It contains some useful information provided in the RST message</param>
        protected virtual void GenerateSamlStatements(IList<SamlStatement> statements, SecurityKeyIdentifier proofKeyIdentifier, RequestSecurityToken rst)
        {
            // create saml:Subject
            SamlSubject subject = new SamlSubject();
            subject.ConfirmationMethods.Add(SamlConstants.HolderOfKey);
            subject.KeyIdentifier = proofKeyIdentifier;
            subject.Name = "federatedUser";
            subject.NameFormat = SamlConstants.UserNameNamespace;

            // create saml:AttributeStatement and add it to assertion
            SamlAttributeStatement samlAttributeStatement = new SamlAttributeStatement();
            samlAttributeStatement.SamlSubject = subject;
            statements.Add(samlAttributeStatement);
                        
            // create role claims
            List<string> roleList = new List<string>();
            roleList.Add("federatedServiceUser");
            roleList.Add("tokenRequestor");
            
            samlAttributeStatement.Attributes.Add(new SamlAttribute("http://schemas.microsoft.com/xsi/2005/05/role", "role", roleList));
        }

        #endregion

        #region Protected methods
        /// <summary>
        /// Generates a symmetric key for the SAML token
        /// </summary>
        /// <param name="rst"></param>
        /// <param name="rstr"></param>
        /// <returns></returns>
        protected virtual SecurityKeyIdentifier GenerateSymmetricProofKey(RequestSecurityToken rst, RequestSecurityTokenResponse rstr)
        {
            RNGCryptoServiceProvider randomNumberGenerator = new RNGCryptoServiceProvider();

            // see if there is any client entropy
            BinarySecretSecurityToken clientEntropy = rst.RequestorEntropy as BinarySecretSecurityToken;

            byte[] key = null;
            
            if (clientEntropy != null)
            {
                int keySize = 256;

                if (rst.KeySize != 0)
                    keySize = rst.KeySize;

                byte[] issuerEntropy = new byte[rst.KeySize / 8];

                randomNumberGenerator.GetBytes(issuerEntropy);

                key = rstr.ComputeCombinedKey(clientEntropy.GetKeyBytes(), issuerEntropy, keySize);
                rstr.ComputeKey = true;
                rstr.IssuerEntropy = new BinarySecretSecurityToken(issuerEntropy);
            }
            else
            {
                key = new byte[rst.KeySize / 8];
                randomNumberGenerator.GetBytes(key);

                BinarySecretSecurityToken proofToken = new BinarySecretSecurityToken(key);
                rstr.KeySize = proofToken.KeySize;
                rstr.RequestedProofToken = proofToken;
            }
                        
            EndpointAddress appliesTo = rst.AppliesTo;

            X509SecurityToken encryptionToken = (X509SecurityToken)SamlConfiguration.SamlTokenIssuerConfiguration.GetServiceToken(appliesTo);

            X509AsymmetricSecurityKey x509Key = new X509AsymmetricSecurityKey(encryptionToken.Certificate);
            byte[] encryptedKey = x509Key.EncryptKey("http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p", key);

            EncryptedKeyIdentifierClause clause = new EncryptedKeyIdentifierClause(encryptedKey, "http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p",
                new SecurityKeyIdentifier(new X509ThumbprintKeyIdentifierClause(encryptionToken.Certificate)));

            SecurityKeyIdentifier proofKeyIdentifier = new SecurityKeyIdentifier(clause);

            return proofKeyIdentifier;
        }

        /// <summary>
        /// Generates a Asymmetric key for the SAML token
        /// </summary>
        /// <param name="rst"></param>
        /// <param name="rstr"></param>
        /// <returns></returns>
        protected virtual SecurityKeyIdentifier GenerateAsymmetricProofKey(RequestSecurityToken rst, RequestSecurityTokenResponse rstr)
        {
            throw new NotImplementedException(Messages.UnsupportedAsymmetricKeyType);
        }

        #endregion
    }
}
