// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

using System.Xml;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace SampleService
{
    [ServiceContract()]
    interface IHelloWorld
    {
        [OperationContract(Name = "helloWorld", ProtectionLevel = System.Net.Security.ProtectionLevel.Sign)]
        [XmlSerializerFormat()]
        string HelloWorld(string message);
    }

    class HelloWorldService : IHelloWorld
    {
        #region IHelloWorld Members
        
        public string HelloWorld(string message)
        {
            return "Hello World : " + message;
        }

       
        #endregion
        
    }
}
