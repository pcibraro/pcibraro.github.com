// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;

using System.IdentityModel.Selectors;

namespace SecureTokenService
{
    public class CustomUsernamePasswordValidator : UserNamePasswordValidator
    {
        public override void Validate(string userName, string password)
        {
            UserNamePasswordValidator.None.Validate(userName, password);
        }
    }
}
