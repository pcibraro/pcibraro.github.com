// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Xml;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Security.Tokens;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;

namespace TokenCache
{
    /// <summary> 
    /// Helper class used as cache for security tokens 
    /// </summary> 
    class TokenCacheHelper
    {
        private const int DefaultTimeout = 1000;
        private static Dictionary<Uri, SecurityToken> tokens = new Dictionary<Uri, SecurityToken>();
        private static ReaderWriterLock tokenLock = new ReaderWriterLock();

        private TokenCacheHelper()
        {
        }

        public static SecurityToken GetToken(Uri endpoint)
        {
            
            SecurityToken token = null;
            tokenLock.AcquireReaderLock(DefaultTimeout);

            try
            {
                tokens.TryGetValue(endpoint, out token);
                return token;
            }
            finally
            {
                tokenLock.ReleaseReaderLock();
            }
        }

        public static void AddToken(Uri endpoint, SecurityToken token)
        {
            tokenLock.AcquireWriterLock(DefaultTimeout);
            try
            {
                if (tokens.ContainsKey(endpoint))
                    tokens.Remove(endpoint);

                tokens.Add(endpoint, token);
            }
            finally
            {
                tokenLock.ReleaseWriterLock();
            }
        }
    } 


    /// <summary> 
    /// Custom token provider. This class keeps the tokens outside of the channel 
    /// so they can be reused 
    /// </summary> 
    public class CacheIssuedSecurityTokenProvider : IssuedSecurityTokenProvider
    {

        private IssuedSecurityTokenProvider innerProvider;

        /// <summary> 
        /// Constructor 
        /// </summary> 
        public CacheIssuedSecurityTokenProvider(IssuedSecurityTokenProvider innerProvider)
            : base()
        {

            this.innerProvider = innerProvider;
            this.CacheIssuedTokens = innerProvider.CacheIssuedTokens;
            this.IdentityVerifier = innerProvider.IdentityVerifier;
            this.IssuedTokenRenewalThresholdPercentage = innerProvider.IssuedTokenRenewalThresholdPercentage;
            this.IssuerAddress = innerProvider.IssuerAddress;
            this.IssuerBinding = innerProvider.IssuerBinding;

            foreach (IEndpointBehavior behavior in innerProvider.IssuerChannelBehaviors)
            {
                this.IssuerChannelBehaviors.Add(behavior);
            }

            this.KeyEntropyMode = innerProvider.KeyEntropyMode;
            this.MaxIssuedTokenCachingTime = innerProvider.MaxIssuedTokenCachingTime;
            this.MessageSecurityVersion = innerProvider.MessageSecurityVersion;
            this.SecurityAlgorithmSuite = innerProvider.SecurityAlgorithmSuite;
            this.SecurityTokenSerializer = innerProvider.SecurityTokenSerializer;
            this.TargetAddress = innerProvider.TargetAddress;

            foreach (XmlElement parameter in innerProvider.TokenRequestParameters)
            {
                this.TokenRequestParameters.Add(parameter);
            }

            this.innerProvider.Open();
        }

        /// <summary> 
        /// Gets the security token 
        /// </summary> 
        /// <param name="timeout"></param> 
        /// <returns></returns> 
        protected override System.IdentityModel.Tokens.SecurityToken GetTokenCore(TimeSpan timeout)
        {
            SecurityToken securityToken = null;
            if (this.CacheIssuedTokens)
            {
                securityToken = TokenCacheHelper.GetToken(this.innerProvider.IssuerAddress.Uri);

                if (securityToken == null || !IsServiceTokenTimeValid(securityToken))
                {
                    securityToken = innerProvider.GetToken(timeout);
                    TokenCacheHelper.AddToken(this.innerProvider.IssuerAddress.Uri, securityToken);
                }
            }
            else
            {
                securityToken = innerProvider.GetToken(timeout);
            }

            return securityToken;
        }

        /// <summary> 
        /// Checks the token expiration. 
        /// A more complex algorithm can be used here to determine whether the token is valid or not. 
        /// </summary> 
        private bool IsServiceTokenTimeValid(SecurityToken serviceToken)
        {
            return (DateTime.UtcNow <= serviceToken.ValidTo.ToUniversalTime());
        }

        ~CacheIssuedSecurityTokenProvider()
        {
            this.innerProvider.Close();
        }
    }

}
