// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Security.Tokens;
using System.IdentityModel.Selectors;

namespace TokenCache
{
    /// <summary>
    /// Token Manager to reuse the same SAML token for different channels
    /// </summary>
    public class CacheClientCredentialsSecurityTokenManager : ClientCredentialsSecurityTokenManager
    {
        private static Dictionary<Uri, CacheIssuedSecurityTokenProvider> providers = new Dictionary<Uri, CacheIssuedSecurityTokenProvider>();

        public CacheClientCredentialsSecurityTokenManager(ClientCredentials credentials)
            : base(credentials)
        {
        }

        /// <summary> 
        /// Returns a custom token provider when a issued token is required 
        /// </summary> 
        public override System.IdentityModel.Selectors.SecurityTokenProvider CreateSecurityTokenProvider(System.IdentityModel.Selectors.SecurityTokenRequirement tokenRequirement)
        {
            if (this.IsIssuedSecurityTokenRequirement(tokenRequirement))
            {
                IssuedSecurityTokenProvider baseProvider = (IssuedSecurityTokenProvider)base.CreateSecurityTokenProvider(tokenRequirement);
                CacheIssuedSecurityTokenProvider provider = new CacheIssuedSecurityTokenProvider(baseProvider);
                return provider;
            }
            else
            {
                return base.CreateSecurityTokenProvider(tokenRequirement);
            }
        }
    } 
}
