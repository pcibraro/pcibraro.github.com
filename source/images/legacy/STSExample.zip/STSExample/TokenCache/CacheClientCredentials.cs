// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Security.Tokens;
using System.IdentityModel.Selectors;

namespace TokenCache
{
    /// <summary>
    /// Custom credentials used to return a custom token manager (The token manager to reuse the same SAML token
    /// for different channels)
    /// </summary>
    public class CacheClientCredentials : ClientCredentials
    {
        public CacheClientCredentials()
            : base()
        {
        }

        protected CacheClientCredentials(ClientCredentials other)
            : base(other)
        {
        }

        protected override ClientCredentials CloneCore()
        {
            return new CacheClientCredentials(this);
        }

        /// <summary> 
        /// Returns a custom security token manager 
        /// </summary> 
        /// <returns></returns> 
        public override System.IdentityModel.Selectors.SecurityTokenManager CreateSecurityTokenManager()
        {
            return new CacheClientCredentialsSecurityTokenManager(this);
        }
    } 
}
