﻿// Copyright Pablo Cibraro, 2006. http://weblogs.asp.net/cibrax

using System.ServiceModel;
using System;
using System.Xml.Serialization;
using System.Runtime.Serialization;

[ServiceContract()]
public interface IHelloWorld
{
    [OperationContract(Name = "helloWorld", ProtectionLevel=System.Net.Security.ProtectionLevel.Sign)]
    [XmlSerializerFormat()] 
    string HelloWorld(string message);
}

public interface IHelloWorldChannel : IHelloWorld, System.ServiceModel.IClientChannel
{
}

