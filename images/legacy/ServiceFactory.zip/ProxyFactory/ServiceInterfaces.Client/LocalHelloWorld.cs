using System;
using System.Collections.Generic;
using System.Text;

namespace ServiceInterfaces.Client
{
    class LocalHelloWorld : IHelloWorld
    {
        #region IHelloWorld Members

        public string HelloWorld(string message)
        {
            return String.Format("Local Hello World : {0}", message);
        }

        #endregion
    }
}
