using System;
using System.Collections.Generic;
using System.Text;

using ServiceInterfaces.Core;
using ServiceInterfaces.Core.Configuration;

namespace ServiceInterfaces.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            //Default implementation
            ServiceFactory<IHelloWorld> factory = new ServiceFactory<IHelloWorld>();
            IHelloWorld service = factory.Create();

            Console.WriteLine(service.HelloWorld("John Doe"));

            //Remote implementation
            factory = new ServiceFactory<IHelloWorld>("RemoteImplementation");
            service = factory.Create();

            Console.WriteLine(service.HelloWorld("John Doe"));
        }
    }
}
