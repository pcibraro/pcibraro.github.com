using System;
using System.Collections.Generic;
using System.Text;

using ServiceInterfaces.Core.Configuration;

namespace ServiceInterfaces.Core
{
    public class ServiceFactory<T>
    {
        private string configurationName;

        public ServiceFactory()
        {
        }

        public ServiceFactory(string configurationName)
        {
            this.configurationName = configurationName;
        }
        
        public T Create()
        {
            ServiceProxy proxy = new ServiceProxy(this.configurationName, typeof(T));
            return (T)proxy.GetTransparentProxy();
        }
    } 
}
