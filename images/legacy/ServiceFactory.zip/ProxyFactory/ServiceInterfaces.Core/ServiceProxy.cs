using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Remoting.Messaging;

using ServiceInterfaces.Core.Configuration;

namespace ServiceInterfaces.Core
{
    public class ServiceProxy : System.Runtime.Remoting.Proxies.RealProxy
    {
        private Type type;
        private string configurationName;

        public ServiceProxy(string configurationName, Type type) : base(type) 
        {
            this.type = type;
            this.configurationName = configurationName;
        }

        public override System.Runtime.Remoting.Messaging.IMessage Invoke(System.Runtime.Remoting.Messaging.IMessage imsg) 
        {
            Type implementationType = null;
            string type = this.type.FullName;

            foreach (ServiceInterfaceDefinition definition in ServiceInterfaceConfiguration.Current.Interfaces)
            {
                if ((this.configurationName == null || this.configurationName == definition.Name) && type == definition.Type)
                {
                    implementationType = definition.ImplementationType;
                    break;
                }
            }

            if(implementationType == null)
                throw new Exception("The implementation type can not be null");

            object implementation = Activator.CreateInstance(implementationType); 
            
            ReturnMessage retmsg = null; 

            if (imsg is IMethodCallMessage) 
            { 
                IMethodCallMessage call = imsg as IMethodCallMessage;

                object returnValue = implementationType.InvokeMember(call.MethodName, System.Reflection.BindingFlags.InvokeMethod,
                    null, implementation, call.Args);

                retmsg = new ReturnMessage(returnValue, null, 0, null, call);
            } 

            return retmsg;
        } 

    } 

}
