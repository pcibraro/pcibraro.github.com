using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace ServiceInterfaces.Core.Configuration
{
    class TypeImplementationConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
        {
            return (sourceType == typeof(string));
        }

        public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
        {
            return (destinationType == typeof(Type));
        }

        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            if (value == null)
            {
                throw new ArgumentNullException("value");
            }
            if (value.GetType() != typeof(string))
            {
                throw new ArgumentOutOfRangeException("value", "Invalid type");
            }
            return Type.GetType((string)value, true);

        }

        public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
        {
            if (destinationType == null)
            {
                throw new ArgumentNullException("destinationType");
            }
            if (destinationType != typeof(string))
            {
                throw new ArgumentOutOfRangeException("destinationType", "Invalid type");
            }
            if (value == null)
            {
                throw new ArgumentNullException("value");
            }
            return ((Type)value).ToString();

        }
    }
}
