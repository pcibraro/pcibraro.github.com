using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ServiceInterfaces.Core.Configuration
{
    public class ServiceInterfaceDefinitionCollection : ConfigurationElementCollection
    {
        public ServiceInterfaceDefinitionCollection()
            : base()
        {
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ServiceInterfaceDefinition(); 
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ServiceInterfaceDefinition)element).Name;
        }
    }
}
