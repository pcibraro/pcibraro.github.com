using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ServiceInterfaces.Core.Configuration
{
    public class ServiceInterfaceConfiguration : ConfigurationSection
    {
        const string SectionName = "serviceInterfaces";

        private ConfigurationProperty interfaces = new ConfigurationProperty("interfaces", typeof(ServiceInterfaceDefinitionCollection), null, ConfigurationPropertyOptions.None);
        private ConfigurationPropertyCollection properties = new ConfigurationPropertyCollection();

        private static object Lock = new object();
        private static ServiceInterfaceConfiguration CurrentInstance;

        public ServiceInterfaceConfiguration()
            : base()
        {
            properties.Add(interfaces);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get { return properties; }
        }

        public ServiceInterfaceDefinitionCollection Interfaces
        {
            get
            {
                return (ServiceInterfaceDefinitionCollection)this[this.interfaces];
            }
        }

        public static ServiceInterfaceConfiguration Current
        {
            get
            {
                if (CurrentInstance == null)
                {
                    lock (Lock)
                    {
                        if (CurrentInstance == null)
                        {
                            CurrentInstance = (ServiceInterfaceConfiguration)ConfigurationManager.GetSection(SectionName); 
                        }
                    }
                }

                return CurrentInstance;
            }

        }
    }
}
