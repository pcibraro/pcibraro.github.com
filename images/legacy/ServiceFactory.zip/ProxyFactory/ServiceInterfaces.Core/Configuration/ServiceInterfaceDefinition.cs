using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.ComponentModel;

namespace ServiceInterfaces.Core.Configuration
{
    public class ServiceInterfaceDefinition : ConfigurationElement
    {
        private ConfigurationProperty name = new ConfigurationProperty("name", typeof(string), null, ConfigurationPropertyOptions.IsRequired);
        private ConfigurationProperty implementationType = new ConfigurationProperty("implementationType", typeof(Type), null, new TypeImplementationConverter(), null, ConfigurationPropertyOptions.None);
        private ConfigurationProperty type = new ConfigurationProperty("type", typeof(string), null, ConfigurationPropertyOptions.None);

        private ConfigurationPropertyCollection properties = new ConfigurationPropertyCollection();

        public ServiceInterfaceDefinition()
            : base()
        {
            properties.Add(name);
            properties.Add(implementationType);
            properties.Add(type);
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get { return properties; }
        }

        public string Name
        {
            get { return (string)base[name]; }
        }
                
        public Type ImplementationType
        {
            get { return (Type)base[implementationType]; }
        }

        public string Type
        {
            get { return (string)base[type]; }
        }
    }
}
