using System;
using System.Collections.Generic;
using System.Text;

namespace ServiceInterfaces
{
    public interface IHelloWorld
    {
        string HelloWorld(string message);
    }
}
