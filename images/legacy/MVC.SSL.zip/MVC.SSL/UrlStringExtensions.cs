﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Text.RegularExpressions;
using System.Web.Security;
using System.Configuration;
using Instedd.GeoChat.Mvc;

namespace System.Web.Mvc
{
	 /// <summary>
    /// Provides helper extensions for turning strings into fully-qualified and SSL-enabled Urls.
    /// </summary>
    public static class UrlStringExtensions
    {
        /// <summary>
        /// Takes a relative or absolute url and returns the fully-qualified url path.
        /// </summary>
        /// <param name="text">The url to make fully-qualified. Ex: Home/About</param>
        /// <returns>The absolute url plus protocol, server, & port. Ex: http://localhost:1234/Home/About</returns>
        public static string ToFullyQualifiedUrl( this string text )
        {
            var oldUrl = text;
            var oldUrlArray = ( oldUrl.Contains( "?" ) ? oldUrl.Split( '?' ) : new[]{ oldUrl, "" } );

            var requestUri = HttpContext.Current.Request.Url;
            var localPathAndQuery = requestUri.LocalPath + requestUri.Query;
            var urlBase = requestUri.AbsoluteUri.Substring( 0, requestUri.AbsoluteUri.Length - localPathAndQuery.Length ); 

            var newUrl = VirtualPathUtility.ToAbsolute( oldUrlArray[0] );
            if( !string.IsNullOrEmpty( oldUrlArray[1] ) )
                newUrl += "?" + oldUrlArray[1];

            return urlBase + newUrl;
        }

        /// <summary>
        /// Looks for Html links in the passed string and turns each relative or absolute url and returns the fully-qualified url path.
        /// </summary>
        /// <param name="text">The url to make fully-qualified. Ex: <a href="Home/About">Blah</a></param>
        /// <returns>The absolute url plus protocol, server, & port. Ex: <a href="http://localhost:1234/Home/About">Blah</a></returns>
        public static string ToFullyQualifiedLink( this string text )
        {
            var regex = new Regex(
                "(?<Before><a.*href=\")(?!http)(?<Url>.*?)(?<After>\".+>)",
                RegexOptions.Multiline | RegexOptions.IgnoreCase
                );

            return regex.Replace( text, ( Match m ) =>
                                        m.Groups["Before"].Value +
                                        ToFullyQualifiedUrl( m.Groups["Url"].Value ) +
                                        m.Groups["After"].Value
                );
        }

        /// <summary>
        /// Takes a relative or absolute url and returns the fully-qualified url path using the Https protocol.
        /// </summary>
        /// <param name="text">The url to make fully-qualified. Ex: Home/About</param>
        /// <returns>The absolute url plus server, & port using the Https protocol. Ex: https://localhost:1234/Home/About</returns>
        public static string ToSslUrl( this string text )
        {
			if (IsSslRequired())
			{
				string absoluteUrl = null;
				if (text.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || text.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
					absoluteUrl = text;
				else
					absoluteUrl = ToFullyQualifiedUrl(text);

				return absoluteUrl.Replace("http:", "https:");
			}
			else
			{
				return text;
			}
        }

		/// <summary>
		/// Takes a relative or absolute url and returns the fully-qualified url path using the Http protocol.
		/// </summary>
		/// <param name="text">The url to make fully-qualified. Ex: Home/About</param>
		/// <returns>The absolute url plus server, & port using the Http protocol. Ex: http://localhost:1234/Home/About</returns>
		public static string ToUnsecureUrl(this string text)
		{
			string absoluteUrl = null;
			if (text.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || text.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
				absoluteUrl = text;
			else
				absoluteUrl = ToFullyQualifiedUrl(text);

			return absoluteUrl.Replace("https:", "http:");
		}

        /// <summary>
        /// Looks for Html links in the passed string and turns each relative or absolute url into a fully-qualified url path using the Https protocol.
        /// </summary>
        /// <param name="text">The url to make fully-qualified. Ex: <a href="Home/About">Blah</a></param>
        /// <returns>The absolute url plus server, & port using the Https protocol. Ex: <a href="https://localhost:1234/Home/About">Blah</a></returns>
        public static string ToSslLink( this string text )
        {
			if (IsSslRequired())
			{
				return ToFullyQualifiedLink(text).Replace("http:", "https:");
			}
			else
			{
				return ToFullyQualifiedLink(text);
			}
        }

		private static bool IsSslRequired()
		{
			return Authentication.IsSslRequired();
		}
    }

}
