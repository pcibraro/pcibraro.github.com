﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Mvc;
using Instedd.GeoChat.Mvc;

namespace System.Web.Mvc
{
	public class SslSwitchModule : IHttpModule
	{
		private static Dictionary<string, string> SecureRoutes = new Dictionary<string, string>();

		public void ProcessRequest(HttpContext context)
		{
			if(Authentication.IsSslRequired() && context.Request.HttpMethod.Equals("get", StringComparison.OrdinalIgnoreCase))
			{
				var data = RouteTable.Routes.GetRouteData(new HttpContextWrapper(context));
				if (data != null)
				{
					if (!context.Request.IsSecureConnection)
					{
						if(data.DataTokens["isSecure"] != null && (bool)data.DataTokens["isSecure"])
						{
							//Do redirect to https
							var secureUrl = context.Request.Url.ToString().ToSslUrl();
							context.Response.Redirect(secureUrl, true);
						}
					}
					else
					{
						if (data.DataTokens["isSecure"] == null || !((bool)data.DataTokens["isSecure"]))
						{
							//Do redirect to http
							var unsecureUrl = context.Request.Url.ToString().ToUnsecureUrl();
							context.Response.Redirect(unsecureUrl, true);
						}
					}
				}
			}

		}

		#region IHttpModule Members

		public void Dispose()
		{
		}

		public void Init(HttpApplication context)
		{
			// wireup the event for processing
			context.PreRequestHandlerExecute += new EventHandler(context_PreRequestHandlerExecute);

		}

		void context_PreRequestHandlerExecute(object sender, EventArgs e)
		{
			HttpApplication httpApp = (HttpApplication)sender;
			//process the request
			this.ProcessRequest(httpApp.Context);
		}

		#endregion
	}
}
