﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc.Validation.Controllers
{
	[HandleError]
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		public JsonResult IsLoginAvailable(string login)
		{
			//TODO: Do the validation
			JsonResult result = new JsonResult();
			if (login == "cibrax")
				result.Data = false;
			else
				result.Data = true; 

			return result;
		}

		public ActionResult About()
		{
			ViewData["Title"] = "About Page";

			return View();
		}

		public ViewResult Register(string login, string email, string url, string password)
		{
			return View();
		}
	}
}
