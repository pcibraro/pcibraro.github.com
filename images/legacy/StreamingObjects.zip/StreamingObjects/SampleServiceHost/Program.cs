﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using Service;
using System.ServiceModel.Dispatcher;

namespace SampleServiceHost
{
	class Program
	{
		static void Main(string[] args)
		{
			using (ServiceHost host = new ServiceHost(typeof(SampleService), new Uri("http://localhost:6000")))
			{
				host.Open();

				foreach (ChannelDispatcher cd in host.ChannelDispatchers)
					foreach (EndpointDispatcher ed in cd.Endpoints)
						Console.WriteLine("Service listening at {0}", ed.EndpointAddress.Uri);


				// The service can now be accessed.
				Console.WriteLine("The service is ready.");
				Console.WriteLine("Press <ENTER> to terminate service.");
				Console.WriteLine();
				Console.ReadLine();

				host.Close();
			}
		}
	}
}
