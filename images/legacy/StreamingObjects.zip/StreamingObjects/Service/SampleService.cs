﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml.Serialization;

namespace Service
{
	[ServiceContract]
	public interface ISampleService
	{
		[OperationContract(Action="GetAllCustomers", ReplyAction="GetAllCustomers")]
		Message GetAllCustomers();
	}

	public class SampleService : ISampleService
	{
		#region ISampleService Members

		public Message GetAllCustomers()
		{
			Message message = Message.CreateMessage(MessageVersion.Soap11, "GetAllCustomers", new CustomBodyWriter(GetAllCustomersImpl()));
			return message;
		}

		#endregion

		public IEnumerable<Customer> GetAllCustomersImpl()
		{
			for(long i = 0; i < 50; i++) //All the customers should be read from the database
			{
				yield return new Customer { FirstName = "Foo", LastName = "Bar", Address = "FooBar 123" };
			}

			yield break;
		}

		
	}

}
