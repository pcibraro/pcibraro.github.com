﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace Service
{
	public class CustomBodyWriter : BodyWriter
	{
		private IEnumerable<Customer> customers;

		public CustomBodyWriter(IEnumerable<Customer> customers) 
			: base(false) // False should be passed here to avoid buffering the message 
		{
			this.customers = customers;
		}

		protected override void OnWriteBodyContents(System.Xml.XmlDictionaryWriter writer)
		{
			XmlSerializer serializer = new XmlSerializer(typeof(Customer));
			writer.WriteStartElement("customers");
			foreach (Customer customer in customers)
			{
				serializer.Serialize(writer, customer);
			}
			writer.WriteEndElement();
		}
	}
}
