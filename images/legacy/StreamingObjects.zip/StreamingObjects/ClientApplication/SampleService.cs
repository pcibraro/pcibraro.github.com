﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace ClientApplication
{
	[ServiceContract]
	public interface ISampleService
	{
		[OperationContract(Action = "GetAllCustomers", ReplyAction = "GetAllCustomers")]
		Message GetAllCustomers();
	}

	[XmlRoot("Customer")]
	public class Customer
	{
		public string FirstName { get; set; }

		public string LastName { get; set; }

		public string Address { get; set; }
	}

	[XmlRoot("Customers")]
	public class Customers
	{
	    public Customer[] Customers { get; set; }
	}

	//public interface ISampleService
	//{
	//    [OperationContract]
	//    Customers GetAllCustomers(int page, int count, out int totalCustomers);	
	//}

}
