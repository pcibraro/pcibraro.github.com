﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace ClientApplication
{
	class Program
	{
		static void Main(string[] args)
		{
			ChannelFactory<ISampleService> factory = new ChannelFactory<ISampleService>("localhost");
			ISampleService service = factory.CreateChannel();

			Message message = service.GetAllCustomers();
			
			foreach(Customer customer in GetAllCustomers(message))
			{
				Console.WriteLine(customer.FirstName + " " + customer.LastName);
			}

			Console.ReadLine();
		}

		static IEnumerable<Customer> GetAllCustomers(Message message)
		{
			XmlReader reader = message.GetReaderAtBodyContents();
			if (reader.LocalName != "customers")
			{
				throw new Exception("The service returned an invalid message");
			}

			XmlSerializer serializer = new XmlSerializer(typeof(Customer));
			reader.ReadStartElement("customers");

			while(!reader.EOF && reader.LocalName == "Customer")
			{
				Customer customer = (Customer)serializer.Deserialize(reader);
				yield return customer;
			}

			reader.ReadEndElement();
		}
	}
}
