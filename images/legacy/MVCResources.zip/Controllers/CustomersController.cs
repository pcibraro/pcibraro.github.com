﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication6.Repositories;
using MvcApplication6.Models;
using System.Net;

namespace MvcApplication6.Controllers
{
    public class CustomersController : Controller
    {
        ICustomerRepository repository;

        public CustomersController()
            : this(new CustomerRepository())
        {
        }

        public CustomersController(ICustomerRepository repository)
        {
            this.repository = repository;
        }

        public ActionResult Index(string filter = null)
        {
            IEnumerable<Customer> customers = null;

            if (!string.IsNullOrEmpty(filter))
            {
                customers = this.repository.GetAll()
                    .Where(c => c.FirstName.Contains(filter) || c.LastName.Contains(filter));
            }
            else
            {
                customers = this.repository.GetAll();
            }
            
            return View(customers);
        }

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(Customer customer)
        {
            if(ModelState.IsValid)
                this.repository.Add(customer);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            this.repository.Delete(id);

            if (Request.IsAjaxRequest())
                return new HttpStatusCodeResult((int)HttpStatusCode.OK);

            return RedirectToAction("Index");
        }

    }
}
