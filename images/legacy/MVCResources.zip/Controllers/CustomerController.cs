﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication6.Models;
using MvcApplication6.Repositories;
using System.Net;

namespace MvcApplication6.Controllers
{
    public class CustomerController : Controller
    {
        ICustomerRepository repository;

        public CustomerController()
            : this(new CustomerRepository())
        {
        }

        public CustomerController(ICustomerRepository repository)
        {
            this.repository = repository;
        }

        [HttpGet]
        public ActionResult Get(int id)
        {
            var customer = this.repository.GetAll()
                .Where(c => c.Id == id)
                .FirstOrDefault();

            if (customer == null)
                return new HttpStatusCodeResult((int)HttpStatusCode.NotFound);

            return View(customer);
        }

        [HttpPost]
        public ActionResult Update(Customer customer)
        {
            if (ModelState.IsValid)
                this.repository.Update(customer);

            return RedirectToAction("Index", "Customers");
        }

    }
}
