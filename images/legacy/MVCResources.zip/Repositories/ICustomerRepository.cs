﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcApplication6.Models;

namespace MvcApplication6.Repositories
{
    public interface ICustomerRepository
    {
        Customer[] GetAll();

        void Update(Customer customer);

        void Add(Customer customer);

        void Delete(int id);
    }
}