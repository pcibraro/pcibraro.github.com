﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcApplication6.Models;

namespace MvcApplication6.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        public Customer[] GetAll()
        {
            return new Customer[] {
                new Customer 
                { 
                    Id = 1,
                    FirstName = "foo",
                    LastName = "bar",
                    PhoneNumber = "xxx-xxxxx",
                    Email = "xxx@xxx.com"
                }
            };
        }

        public void Update(Customer customer)
        {
        }

        public void Add(Customer customer)
        {
        }

        public void Delete(int id)
        {
        }
    }
}