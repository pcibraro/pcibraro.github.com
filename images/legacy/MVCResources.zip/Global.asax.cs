﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace MvcApplication6
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }

        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //This map is required so the Add segment is not used as {id}
            routes.MapRoute(
              name: "CustomerAdd",
              url: "Customers/Add",
              defaults: new { controller = "Customers", action = "Add" }
              );

            routes.MapRoute(
               name: "CustomerGet",
               url: "Customers/{id}",
               defaults: new { controller = "Customer", action = "Get" },
               constraints: new { httpMethod = new HttpMethodConstraint("GET") }
               );

            routes.MapRoute(
                name: "CustomerUpdate",
                url: "Customers/{id}",
                defaults: new { controller = "Customer", action = "Update" },
                constraints: new { httpMethod = new HttpMethodConstraint("POST") }
                );

            routes.MapRoute(
                name: "MVC Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );

           
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);

            BundleTable.Bundles.RegisterTemplateBundles();
        }
    }
}