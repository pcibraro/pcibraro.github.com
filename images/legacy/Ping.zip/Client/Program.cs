﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.ServiceModel;
using Client.ServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new ServiceReference.HelloWorldClient();

            var isAvailable = client.InnerChannel.IsAvailable<IHelloWorld>((c) => c.Hello(null));

            Console.WriteLine("Service Available " + isAvailable);

            var response = client.Hello("Cibrax");

            Console.WriteLine(response);
        }
    }
}
