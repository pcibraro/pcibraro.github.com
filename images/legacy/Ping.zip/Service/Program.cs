﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(HelloWorldService), new Uri("http://localhost:8080"));
            host.Open();

            foreach (var endpoint in host.Description.Endpoints)
            {
                Console.WriteLine("Listening at " + endpoint.ListenUri);
            }

            Console.ReadLine();

            host.Close();
        }
    }
}
