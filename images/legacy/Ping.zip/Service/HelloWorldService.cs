﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tellago.ServiceModel;

namespace Service
{
    [PingBehavior]
    public class HelloWorldService : IHelloWorld
    {
        #region IHelloWorld Members

        public string Hello(string name)
        {
            return "Hello " + name;
        }

        #endregion
    }
}
