﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Description;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace Tellago.ServiceModel
{
    internal class PingOperationInvoker : IOperationInvoker
    {
        IOperationInvoker innerInvoker;
        object[] outputs = null;
        object returnValue = null;

        public const string PingHeaderName = "Ping";
        public const string PingHeaderNamespace = "http://tellago.serviceModel";

        public PingOperationInvoker(IOperationInvoker innerInvoker, OperationDescription description)
        {
            this.innerInvoker = innerInvoker;
            outputs = description.SyncMethod.GetParameters()
               .Where(p => p.IsOut)
               .Select(p => DefaultForType(p.ParameterType)).ToArray();

            var returnValue = DefaultForType(description.SyncMethod.ReturnType);
        }

        #region IOperationInvoker Members

        public object[] AllocateInputs()
        {
            return innerInvoker.AllocateInputs();
        }

        public IAsyncResult InvokeBegin(object instance, object[] inputs, AsyncCallback callback, object state)
        {
            return this.innerInvoker.InvokeBegin(instance, inputs, callback, state);
        }

        public object InvokeEnd(object instance, out object[] outputs, IAsyncResult result)
        {
            object returnValue;

            if (Invoke(out returnValue, out outputs))
            {
                return returnValue;
            }
            else
            {
                return this.innerInvoker.InvokeEnd(instance, out outputs, result);
            }
        }

        private static object DefaultForType(Type targetType)
        {
            return targetType.IsValueType ? Activator.CreateInstance(targetType) : null;
        }
        
        public bool IsSynchronous
        {
            get { return this.innerInvoker.IsSynchronous; }
        }

        #endregion

        public object Invoke(object instance, object[] inputs, out object[] outputs)
        {
            object returnValue;

            if (Invoke(out returnValue, out outputs))
            {
                return returnValue;
            }
            else
            {
                return this.innerInvoker.Invoke(instance, inputs, out outputs);
            }
        }

        private bool Invoke(out object returnValue, out object[] outputs)
        {
            object untypedProperty = null;
            if (OperationContext.Current.IncomingMessageProperties.TryGetValue(HttpRequestMessageProperty.Name, out untypedProperty))
            {
                var httpRequestProperty = untypedProperty as HttpRequestMessageProperty;
                if (httpRequestProperty != null)
                {
                    if (httpRequestProperty.Headers[PingHeaderName] != null)
                    {
                        outputs = this.outputs;

                        if (OperationContext.Current.IncomingMessageProperties.TryGetValue(HttpRequestMessageProperty.Name, out untypedProperty))
                        {
                            var httpResponseProperty = untypedProperty as HttpResponseMessageProperty;

                            httpResponseProperty.Headers.Add(PingHeaderName, "Ok");
                        }

                        returnValue = this.returnValue;

                        return true;
                    }
                }
            }           

            var headers = OperationContext.Current.IncomingMessageHeaders;
            if (headers.FindHeader(PingHeaderName, PingHeaderNamespace) > -1)
            {
                outputs = this.outputs;

                MessageHeader<string> header = new MessageHeader<string>("Ok");
                var untyped = header.GetUntypedHeader(PingHeaderName, PingHeaderNamespace);

                OperationContext.Current.OutgoingMessageHeaders.Add(untyped);

                returnValue = this.returnValue;

                return true;
            }            

            returnValue = null;
            outputs = null;

            return false;
        }
    }
}
