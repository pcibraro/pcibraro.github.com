﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.ServiceModel
{
    public static class ClientChannelExtensions
    {
        const string PingNamespace = "http://tellago.serviceModel";
        const string PingName = "Ping";

        public static bool IsAvailable<TChannel>(this IClientChannel channel, Action<TChannel> operation)
        {
            try
            {
                using (OperationContextScope scope = new OperationContextScope(channel))
                {
                    MessageHeader<string> header = new MessageHeader<string>(PingName);
                    var untyped = header.GetUntypedHeader(PingName, PingNamespace);
                    OperationContext.Current.OutgoingMessageHeaders.Add(untyped);

                    try
                    {
                        operation((TChannel)channel);

                        var headers = OperationContext.Current.IncomingMessageHeaders;
                        if (headers.Any(h => h.Name == PingName && h.Namespace == PingNamespace))
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    catch (CommunicationException)
                    {
                        return false;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
