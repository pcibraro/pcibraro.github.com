﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.IdentityModel.Web;
using Microsoft.IdentityModel.Protocols.WSFederation;
using System.Net;
using System.IO;
using System.Runtime.Serialization;
using Messages;
using System.Xml;

namespace ClientConsole
{
	class Program
	{
		static void Main(string[] args)
		{
			string token = GetToken(
				"http://localhost:7481/STS/Service.svc/Tokens",
				"http://localhost:7397/RestServices/Service.svc",
				"cibrax",
				"foo");

			string response = InvokeRPService("http://localhost:7397/RestServices/Service.svc/Claims", token);

			Console.WriteLine(response);
		}

		static string GetToken(string address, string appliesTo, string username, string password)
		{
			RequestSecurityToken request = new RequestSecurityToken
			{
				TokenType = "http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1",
				AppliesTo = appliesTo
			};

			DataContractSerializer requestSerializer = new DataContractSerializer(typeof(RequestSecurityToken));

			WebRequest webRequest = HttpWebRequest.Create(address);
			webRequest.Method = "POST";
			webRequest.ContentType = "application/xml";
			webRequest.Credentials = new NetworkCredential(username, password);

			using (var st = webRequest.GetRequestStream())
			{
				requestSerializer.WriteObject(st, request);
				st.Flush();
			}

			WebResponse webResponse = webRequest.GetResponse();

			DataContractSerializer responseSerializer = new DataContractSerializer(typeof(RequestSecurityTokenResponse));
			using (var st = webResponse.GetResponseStream())
			{
				var response = (RequestSecurityTokenResponse)responseSerializer.ReadObject(st);

				return response.RequestedSecurityToken;
			}
		}

		static string InvokeRPService(string address, string token)
		{
			WebRequest webRequest = HttpWebRequest.Create(address);
			webRequest.Method = "GET";
			webRequest.Headers["Authorization"] = token;
			
			WebResponse webResponse = webRequest.GetResponse();
			using (var st = webResponse.GetResponseStream())
			{
				StreamReader sr = new StreamReader(st);
				return sr.ReadToEnd();
			}
		}
	}
}
