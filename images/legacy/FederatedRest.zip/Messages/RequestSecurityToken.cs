﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Messages
{
	[DataContract(Name="RequestSecurityToken", Namespace="http://schemas.xmlsoap.org/ws/2005/02/trust")]
	public class RequestSecurityToken
	{
		[DataMember(Name="TokenType")]
		public string TokenType
		{
			get; set;
		}

		[DataMember(Name="AppliesTo")]
		public string AppliesTo
		{
			get; set;
		}

		[DataMember(Name="Claims")]
		public List<ClaimTypeRequirement> ClaimRequirements
		{
			get; set;
		}
	}

	[DataContract(Name="ClaimType", Namespace="http://schemas.microsoft.com/ws/2005/05/identity")]
	public class ClaimTypeRequirement
	{
		[DataMember(Name="Uri")]
		public string Uri { get; set; }
		
		[DataMember(Name="Optional")]
		public bool IsOptional { get; set; }
	}
}
