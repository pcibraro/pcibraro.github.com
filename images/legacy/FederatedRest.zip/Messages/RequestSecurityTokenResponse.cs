﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Xml;

namespace Messages
{
	[DataContract(Name = "RequestSecurityTokenResponse", Namespace = "http://schemas.xmlsoap.org/ws/2005/02/trust")]
	public class RequestSecurityTokenResponse
	{
		[DataMember(Name = "TokenType")]
		public string TokenType
		{
			get; set;
		}

		[DataMember(Name = "RequestedSecurityToken")]
		public string RequestedSecurityToken
		{
			get; set;
		}

		[DataMember(Name="Links")]
		public List<Link> Links
		{
			get;
			set;
		}
	}


}
