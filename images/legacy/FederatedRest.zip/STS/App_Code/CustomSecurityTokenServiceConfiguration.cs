using System;
using Microsoft.IdentityModel.Configuration;


public class CustomSecurityTokenServiceConfiguration : SecurityTokenServiceConfiguration
{
	public CustomSecurityTokenServiceConfiguration()
        : base( "RestSTS" )
    {
        SecurityTokenService = typeof(CustomSecurityTokenService);
    }
}

