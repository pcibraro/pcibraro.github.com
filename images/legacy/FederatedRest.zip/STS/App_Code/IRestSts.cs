﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Web;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Messages;

[ServiceContract]
public interface IRestSts
{
	[OperationContract]
	[WebInvoke(UriTemplate="Tokens", Method="POST", RequestFormat=WebMessageFormat.Xml, ResponseFormat=WebMessageFormat.Xml)]
	RequestSecurityTokenResponse IssueToken(RequestSecurityToken request);

	[OperationContract]
	[WebInvoke(Method = "PUT", UriTemplate = "Tokens/{tokenId}", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml)]
	RequestSecurityTokenResponse RenewToken(string tokenId);

	[OperationContract]
	[WebInvoke(Method = "DELETE", UriTemplate = "Tokens/{tokenId}", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml)]
	void CancelToken(string tokenId);

	[OperationContract]
	[WebGet(UriTemplate = "Tokens/{tokenId}", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml)]
	RequestSecurityTokenResponse GetToken(string tokenId);	
}
