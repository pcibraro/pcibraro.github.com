﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.ServiceModel.Web;
using Microsoft.IdentityModel.Web;
using System.IdentityModel.Selectors;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Security.Principal;
using System.IdentityModel.Policy;
using System.ServiceModel.Security;
using System.IdentityModel.Claims;
using Microsoft.IdentityModel.Claims;
using System.Net;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Tokens.Saml11;
using Microsoft.IdentityModel.Tokens.Saml2;

namespace MessageInterceptors
{
	public class SamlAuthenticationInterceptor : RequestInterceptor
	{
		IssuerNameRegistry registry;
		string stsAddress;

		public SamlAuthenticationInterceptor(IssuerNameRegistry registry, string stsAddress)
			: base(false)
		{
			this.registry = registry;
			this.stsAddress = stsAddress;
		}

		protected IssuerNameRegistry IssuerNameRegistry
		{
			get { return registry; }
		}

		protected string StsAddress
		{
			get { return stsAddress; }
		}

		public override void ProcessRequest(ref RequestContext requestContext)
		{
			SecurityToken token = ExtractCredentials(requestContext.RequestMessage);
						
			if (token != null)
			{
				ClaimsIdentityCollection claims = null;

				var handler = FederatedAuthentication.SecurityTokenHandlers[token];
				if (handler is Saml11SecurityTokenHandler)
				{
					var samlHandler = (Saml11SecurityTokenHandler)handler;
					samlHandler.SamlSecurityTokenRequirement.IssuerNameRegistry = registry;

					claims = samlHandler.ValidateToken(token);
				}
				else if (handler is Saml2SecurityTokenHandler)
				{
					var samlHandler = (Saml2SecurityTokenHandler)handler;
					samlHandler.SamlSecurityTokenRequirement.IssuerNameRegistry = registry;

					claims = samlHandler.ValidateToken(token);
				}
				else
				{
					DenyAccess(ref requestContext);
					return;
				}

				var principal = new ClaimsPrincipal(claims);
				InitializeSecurityContext(requestContext.RequestMessage, principal);
			}
			else
			{
				DenyAccess(ref requestContext);	
			}
		}

		private void DenyAccess(ref RequestContext requestContext)
		{
			Message reply = Message.CreateMessage(MessageVersion.None, null);
			HttpResponseMessageProperty responseProperty = new HttpResponseMessageProperty() { StatusCode = HttpStatusCode.Unauthorized };

			responseProperty.Headers.Add("WWW-Authenticate",
				String.Format("Basic realm=\"{0}\"", StsAddress));

			reply.Properties[HttpResponseMessageProperty.Name] = responseProperty;
			requestContext.Reply(reply);

			requestContext = null;
		}

		private SecurityToken ExtractCredentials(Message requestMessage)
		{
			HttpRequestMessageProperty request = (HttpRequestMessageProperty)requestMessage.Properties[HttpRequestMessageProperty.Name];

			string authHeader = request.Headers["Authorization"];

			if (authHeader != null && authHeader.StartsWith("<saml"))
			{
				SecurityTokenSerializer securityTokenSerializer = new SecurityTokenSerializerAdapter(FederatedAuthentication.SecurityTokenHandlers, MessageSecurityVersion.Default.SecurityVersion, false, new SamlSerializer(), null, null);
				return WSFederationAuthenticationModule.GetSecurityToken(authHeader, securityTokenSerializer);
			}

			return null;
		}

		private void InitializeSecurityContext(Message request, IPrincipal principal)
		{
			List<IAuthorizationPolicy> policies = new List<IAuthorizationPolicy>();
			policies.Add(new PrincipalAuthorizationPolicy(principal));
			ServiceSecurityContext securityContext = new ServiceSecurityContext(policies.AsReadOnly());

			if (request.Properties.Security != null)
			{
				request.Properties.Security.ServiceSecurityContext = securityContext;
			}
			else
			{
				request.Properties.Security = new SecurityMessageProperty() { ServiceSecurityContext = securityContext };
			}
		}

		class PrincipalAuthorizationPolicy : IAuthorizationPolicy
		{
			string id = Guid.NewGuid().ToString();
			IPrincipal user;

			public PrincipalAuthorizationPolicy(IPrincipal user)
			{
				this.user = user;
			}

			public ClaimSet Issuer
			{
				get { return ClaimSet.System; }
			}

			public string Id
			{
				get { return this.id; }
			}

			public bool Evaluate(EvaluationContext evaluationContext, ref object state)
			{
				evaluationContext.AddClaimSet(this, new DefaultClaimSet(System.IdentityModel.Claims.Claim.CreateNameClaim(user.Identity.Name)));
				evaluationContext.Properties["Identities"] = new List<IIdentity>(new IIdentity[] { user.Identity });
				evaluationContext.Properties["Principal"] = user;
				return true;
			}
		}
	}
}
