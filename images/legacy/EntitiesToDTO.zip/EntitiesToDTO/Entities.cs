﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntitiesToDTO.Entities
{
	public class Employee 
	{
		public string Name
		{
			get;
			set;
		}

		public Employee Boss
		{
			get;
			set;
		}

		public Company Company
		{
			get;
			set;
		}
	}

	public class Company
	{
		public string CompanyName
		{
			get;
			set;
		}

		public List<Employee> Employees
		{
			get;
			set;
		}
	}
}
