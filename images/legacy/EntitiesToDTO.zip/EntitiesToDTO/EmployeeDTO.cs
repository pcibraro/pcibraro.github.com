﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace EntitiesToDTO.Entities.DataTransferObjects
{
	public partial class EmployeeDTO
	{
		[DataMember(Name = "fullName")]
		public string FullName { get; set; }

		public partial class EmployeeMapper
		{
			partial void DoMapping(Employee fromEntity, EmployeeDTO toDto)
			{
				toDto.FullName = fromEntity.Name + " Foo";
			}
		}
	}
}
