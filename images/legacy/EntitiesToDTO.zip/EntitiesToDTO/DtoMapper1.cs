


using EntitiesToDTO.Entities;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace EntitiesToDTO.Entities.DataTransferObjects
{
    
    [DataContract(Name="employee", Namespace="urn:EntitiesToDTO/Entities")]
    public partial class EmployeeDTO     
    {
            
        [DataMember(Name="name")]
        public System.String Name
        {
            get; set;
        }
                
        [DataMember(Name="boss")]
        public EmployeeDTO Boss
        {
            get; set;
        }
                
        [DataMember(Name="company")]
        public CompanyDTO Company
        {
            get; set;
        }
                        
        public Employee MapTo(EmployeeDTO dto)
		{
			return GetMapper().MapTo(dto);
		}

		public static EmployeeDTO MapFrom(Employee entity)
		{
			return GetMapper().MapTo(entity);
		}
		
        public static EmployeeMapper GetMapper()
        {
            return new EmployeeMapper();   
        }
        
        public partial class EmployeeMapper
		{
			 public EmployeeDTO MapTo(EntitiesToDTO.Entities.Employee entity)
			 {
			    var dto = new EmployeeDTO
                {   
                    Name = entity.Name,
                    Boss = EmployeeDTO.GetMapper().MapTo(entity.Boss),
                    Company = CompanyDTO.GetMapper().MapTo(entity.Company),
                             
                };
			    
			    			    
			    DoMapping(dto, entity);
			    
			    return dto;
			 }
			 
			 public EntitiesToDTO.Entities.Employee MapTo(EmployeeDTO dto)
			 {
			    var entity = new EntitiesToDTO.Entities.Employee
                {   
                    Name = dto.Name,
                    Boss = EmployeeDTO.GetMapper().MapTo(dto.Boss),
                    Company = CompanyDTO.GetMapper().MapTo(dto.Company),
                             
                };
			    
			                    
			    DoMapping(entity, dto);
			    
			    return entity;
			 }
			 
			 partial void DoMapping(EntitiesToDTO.Entities.Employee fromEntity, EmployeeDTO toDto);
			 partial void DoMapping(EmployeeDTO fromDto, EntitiesToDTO.Entities.Employee toEntity);
		}
    }       
        
    [DataContract(Name="company", Namespace="urn:EntitiesToDTO/Entities")]
    public partial class CompanyDTO     
    {
            
        [DataMember(Name="companyName")]
        public System.String CompanyName
        {
            get; set;
        }
                
        [DataMember(Name="employees")]    
        public IList<EmployeeDTO> Employees
        {   
            get;
            internal set;
        }
                            
        public Company MapTo(CompanyDTO dto)
		{
			return GetMapper().MapTo(dto);
		}

		public static CompanyDTO MapFrom(Company entity)
		{
			return GetMapper().MapTo(entity);
		}
		
        public static CompanyMapper GetMapper()
        {
            return new CompanyMapper();   
        }
        
        public partial class CompanyMapper
		{
			 public CompanyDTO MapTo(EntitiesToDTO.Entities.Company entity)
			 {
			    var dto = new CompanyDTO
                {   
                    CompanyName = entity.CompanyName,
                             
                };
			    
			    dto.Employees = entity.Employees.Select(l =>
                        EmployeeDTO.GetMapper().MapTo(l)).ToList();
                			    
			    DoMapping(dto, entity);
			    
			    return dto;
			 }
			 
			 public EntitiesToDTO.Entities.Company MapTo(CompanyDTO dto)
			 {
			    var entity = new EntitiesToDTO.Entities.Company
                {   
                    CompanyName = dto.CompanyName,
                             
                };
			    
			    entity.Employees = dto.Employees.Select(l =>
                        EmployeeDTO.GetMapper().MapTo(l)).ToList();
                                
			    DoMapping(entity, dto);
			    
			    return entity;
			 }
			 
			 partial void DoMapping(EntitiesToDTO.Entities.Company fromEntity, CompanyDTO toDto);
			 partial void DoMapping(CompanyDTO fromDto, EntitiesToDTO.Entities.Company toEntity);
		}
    }       
        
}
