﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using Common;
using System.Runtime.Serialization;

namespace ClientApplication
{
	class Program
	{
		static void Main(string[] args)
		{
			//Lets create a new order
			
			Order order = new Order { Drink = "latte" };
			
			HttpWebRequest createOrderRequest = CreateRequest(new Uri("http://localhost:8000/order"), "POST", null, order);
			string context = GetContext((HttpWebResponse)createOrderRequest.GetResponse());
			order = Execute<Order>(createOrderRequest.GetResponse());

			Console.WriteLine("Order Cost {0}", order.Cost);
			foreach (Next next in order.Next)
			{
				Console.WriteLine("Possible next step {0}", next.Uri);
			}

			//Lets update the existing order....

			order.Drink = "cappuchino";

			Uri updateOrderUri = new Uri(order.Next.Where(n => n.Rel == "http://starbucks.example/order/update").Single().Uri);
			HttpWebRequest updateOrderRequest = CreateRequest(updateOrderUri, "PUT", context, order);
			Order updatedOrder = Execute<Order>(updateOrderRequest.GetResponse());

			Console.WriteLine("Order Cost {0}", updatedOrder.Cost);
			foreach (Next next in updatedOrder.Next)
			{
				Console.WriteLine("Possible next step {0}", next.Uri);
			}

			//Lets have our drink...

			Payment payment = new Payment { Name = "John Doe", CardNumber = "1234567", Expires = "06/08", Amount = updatedOrder.Cost.GetValueOrDefault() };

			Uri payOrderUri = new Uri(order.Next.Where(n => n.Rel == "http://starbucks.example.org/payment").Single().Uri);
			HttpWebRequest payOrderRequest = CreateRequest(payOrderUri, "PUT", context, payment);

			int statusCode = Execute(payOrderRequest.GetResponse());

			if (statusCode == 201)
				Console.WriteLine("Here is your drink!!!");
			else
				Console.WriteLine("Sorry, there was some error while trying to process the payment");
		}

		static HttpWebRequest CreateRequest(Uri address, string method, string context, object contract)
		{
			HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(address);
			webRequest.ContentType = "application/xml";
			webRequest.Timeout = 30000;
			webRequest.Method = method;
			webRequest.CookieContainer = new CookieContainer();
			
			if (context != null)
			{
				Cookie cookie = new Cookie("WscContext", context, address.PathAndQuery, address.Authority);
				webRequest.CookieContainer.Add(cookie);
			}

			DataContractSerializer serializer = new DataContractSerializer(contract.GetType());
			using (Stream stream = webRequest.GetRequestStream())
			{
				serializer.WriteObject(stream, contract);
				stream.Flush();
			}

			return webRequest;
		}

		static string GetContext(HttpWebResponse response)
		{
			if (response.Cookies["WscContext"] != null)
			{
				return response.Cookies["WscContext"].Value;
			}

			return null;
		}

		static T Execute<T>(WebResponse response)
		{
			DataContractSerializer serializer = new DataContractSerializer(typeof(T));
			using (Stream stream = response.GetResponseStream())
			{
				return (T)serializer.ReadObject(stream);	
			}
		}

		static int Execute(WebResponse response)
		{
			using (Stream stream = response.GetResponseStream()) { };
			return (int)((HttpWebResponse)response).StatusCode;
		}
	}
}
