﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using Common;
using System.ServiceModel.Channels;

namespace ClientApplication
{
	[ServiceContract]
	public interface IOrderService   : IClientChannel
	{
		[OperationContract]
		[WebInvoke(Method="POST", UriTemplate="order")]
		Order PlaceOrder(Order order);

		[OperationContract]
		[WebInvoke(Method = "PUT", UriTemplate = "order/{id}")]
		Order UpdateOrder(string id, Order order);

		[OperationContract]
		[WebInvoke(Method="PUT", UriTemplate="payment/order/{id}")]
		void PayOrder(string id, Payment payment);
	}

	
}
