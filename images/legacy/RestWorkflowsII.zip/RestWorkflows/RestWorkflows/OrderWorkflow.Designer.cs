﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace RestWorkflows
{
	partial class OrderWorkflow
	{
		#region Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		[System.Diagnostics.DebuggerNonUserCode]
		private void InitializeComponent()
		{
			this.CanModifyActivities = true;
			System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding1 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding2 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.Activities.TypedOperationInfo typedoperationinfo1 = new System.Workflow.Activities.TypedOperationInfo();
			System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding3 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding4 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.ComponentModel.ActivityBind activitybind5 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding5 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.Activities.TypedOperationInfo typedoperationinfo2 = new System.Workflow.Activities.TypedOperationInfo();
			System.Workflow.ComponentModel.ActivityBind activitybind6 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding6 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.ComponentModel.ActivityBind activitybind7 = new System.Workflow.ComponentModel.ActivityBind();
			System.Workflow.ComponentModel.WorkflowParameterBinding workflowparameterbinding7 = new System.Workflow.ComponentModel.WorkflowParameterBinding();
			System.Workflow.Activities.TypedOperationInfo typedoperationinfo3 = new System.Workflow.Activities.TypedOperationInfo();
			System.Workflow.Activities.WorkflowServiceAttributes workflowserviceattributes1 = new System.Workflow.Activities.WorkflowServiceAttributes();
			this.setDrinkReceived = new System.Workflow.Activities.SetStateActivity();
			this.codePayOrder = new System.Workflow.Activities.CodeActivity();
			this.setOrderPlacedFromUpdate = new System.Workflow.Activities.SetStateActivity();
			this.codeUpdateOrder = new System.Workflow.Activities.CodeActivity();
			this.setOrderPlaced = new System.Workflow.Activities.SetStateActivity();
			this.OnOrderPlacedCode = new System.Workflow.Activities.CodeActivity();
			this.receiveOrderPaid = new System.Workflow.Activities.ReceiveActivity();
			this.receiveOrderUpdate = new System.Workflow.Activities.ReceiveActivity();
			this.receiveOnOrderPlaced = new System.Workflow.Activities.ReceiveActivity();
			this.OnOrderPaid = new System.Workflow.Activities.EventDrivenActivity();
			this.OnOrderUpdated = new System.Workflow.Activities.EventDrivenActivity();
			this.OnOrderPlaced = new System.Workflow.Activities.EventDrivenActivity();
			this.OrderPlaced = new System.Workflow.Activities.StateActivity();
			this.DrinkReceived = new System.Workflow.Activities.StateActivity();
			this.WaitingForOrder = new System.Workflow.Activities.StateActivity();
			// 
			// setDrinkReceived
			// 
			this.setDrinkReceived.Name = "setDrinkReceived";
			this.setDrinkReceived.TargetStateName = "DrinkReceived";
			// 
			// codePayOrder
			// 
			this.codePayOrder.Name = "codePayOrder";
			this.codePayOrder.ExecuteCode += new System.EventHandler(this.codePayOrder_ExecuteCode);
			// 
			// setOrderPlacedFromUpdate
			// 
			this.setOrderPlacedFromUpdate.Name = "setOrderPlacedFromUpdate";
			this.setOrderPlacedFromUpdate.TargetStateName = "OrderPlaced";
			// 
			// codeUpdateOrder
			// 
			this.codeUpdateOrder.Name = "codeUpdateOrder";
			this.codeUpdateOrder.ExecuteCode += new System.EventHandler(this.codeUpdateOrder_ExecuteCode);
			// 
			// setOrderPlaced
			// 
			this.setOrderPlaced.Name = "setOrderPlaced";
			this.setOrderPlaced.TargetStateName = "OrderPlaced";
			// 
			// OnOrderPlacedCode
			// 
			this.OnOrderPlacedCode.Name = "OnOrderPlacedCode";
			this.OnOrderPlacedCode.ExecuteCode += new System.EventHandler(this.OnOrderPlacedCode_ExecuteCode);
			// 
			// receiveOrderPaid
			// 
			this.receiveOrderPaid.Activities.Add(this.codePayOrder);
			this.receiveOrderPaid.Activities.Add(this.setDrinkReceived);
			this.receiveOrderPaid.Name = "receiveOrderPaid";
			activitybind1.Name = "OrderWorkflow";
			activitybind1.Path = "receivedId";
			workflowparameterbinding1.ParameterName = "id";
			workflowparameterbinding1.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
			activitybind2.Name = "OrderWorkflow";
			activitybind2.Path = "orderPayment";
			workflowparameterbinding2.ParameterName = "payment";
			workflowparameterbinding2.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
			this.receiveOrderPaid.ParameterBindings.Add(workflowparameterbinding1);
			this.receiveOrderPaid.ParameterBindings.Add(workflowparameterbinding2);
			typedoperationinfo1.ContractType = typeof(RestWorkflows.IOrderService);
			typedoperationinfo1.Name = "PayOrder";
			this.receiveOrderPaid.ServiceOperationInfo = typedoperationinfo1;
			// 
			// receiveOrderUpdate
			// 
			this.receiveOrderUpdate.Activities.Add(this.codeUpdateOrder);
			this.receiveOrderUpdate.Activities.Add(this.setOrderPlacedFromUpdate);
			this.receiveOrderUpdate.Name = "receiveOrderUpdate";
			activitybind3.Name = "OrderWorkflow";
			activitybind3.Path = "currentOrder";
			workflowparameterbinding3.ParameterName = "(ReturnValue)";
			workflowparameterbinding3.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
			activitybind4.Name = "OrderWorkflow";
			activitybind4.Path = "receivedId";
			workflowparameterbinding4.ParameterName = "id";
			workflowparameterbinding4.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
			activitybind5.Name = "OrderWorkflow";
			activitybind5.Path = "receivedOrder";
			workflowparameterbinding5.ParameterName = "order";
			workflowparameterbinding5.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind5)));
			this.receiveOrderUpdate.ParameterBindings.Add(workflowparameterbinding3);
			this.receiveOrderUpdate.ParameterBindings.Add(workflowparameterbinding4);
			this.receiveOrderUpdate.ParameterBindings.Add(workflowparameterbinding5);
			typedoperationinfo2.ContractType = typeof(RestWorkflows.IOrderService);
			typedoperationinfo2.Name = "UpdateOrder";
			this.receiveOrderUpdate.ServiceOperationInfo = typedoperationinfo2;
			// 
			// receiveOnOrderPlaced
			// 
			this.receiveOnOrderPlaced.Activities.Add(this.OnOrderPlacedCode);
			this.receiveOnOrderPlaced.Activities.Add(this.setOrderPlaced);
			this.receiveOnOrderPlaced.CanCreateInstance = true;
			this.receiveOnOrderPlaced.Name = "receiveOnOrderPlaced";
			activitybind6.Name = "OrderWorkflow";
			activitybind6.Path = "currentOrder";
			workflowparameterbinding6.ParameterName = "(ReturnValue)";
			workflowparameterbinding6.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind6)));
			activitybind7.Name = "OrderWorkflow";
			activitybind7.Path = "receivedOrder";
			workflowparameterbinding7.ParameterName = "order";
			workflowparameterbinding7.SetBinding(System.Workflow.ComponentModel.WorkflowParameterBinding.ValueProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind7)));
			this.receiveOnOrderPlaced.ParameterBindings.Add(workflowparameterbinding6);
			this.receiveOnOrderPlaced.ParameterBindings.Add(workflowparameterbinding7);
			typedoperationinfo3.ContractType = typeof(RestWorkflows.IOrderService);
			typedoperationinfo3.Name = "PlaceOrder";
			this.receiveOnOrderPlaced.ServiceOperationInfo = typedoperationinfo3;
			// 
			// OnOrderPaid
			// 
			this.OnOrderPaid.Activities.Add(this.receiveOrderPaid);
			this.OnOrderPaid.Name = "OnOrderPaid";
			// 
			// OnOrderUpdated
			// 
			this.OnOrderUpdated.Activities.Add(this.receiveOrderUpdate);
			this.OnOrderUpdated.Name = "OnOrderUpdated";
			// 
			// OnOrderPlaced
			// 
			this.OnOrderPlaced.Activities.Add(this.receiveOnOrderPlaced);
			this.OnOrderPlaced.Name = "OnOrderPlaced";
			// 
			// OrderPlaced
			// 
			this.OrderPlaced.Activities.Add(this.OnOrderUpdated);
			this.OrderPlaced.Activities.Add(this.OnOrderPaid);
			this.OrderPlaced.Name = "OrderPlaced";
			// 
			// DrinkReceived
			// 
			this.DrinkReceived.Name = "DrinkReceived";
			// 
			// WaitingForOrder
			// 
			this.WaitingForOrder.Activities.Add(this.OnOrderPlaced);
			this.WaitingForOrder.Name = "WaitingForOrder";
			workflowserviceattributes1.ConfigurationName = "RestWorkflows.OrderWorkflow";
			workflowserviceattributes1.Name = "OrderWorkflow";
			// 
			// OrderWorkflow
			// 
			this.Activities.Add(this.WaitingForOrder);
			this.Activities.Add(this.DrinkReceived);
			this.Activities.Add(this.OrderPlaced);
			this.CompletedStateName = "DrinkReceived";
			this.DynamicUpdateCondition = null;
			this.InitialStateName = "WaitingForOrder";
			this.Name = "OrderWorkflow";
			this.SetValue(System.Workflow.Activities.ReceiveActivity.WorkflowServiceAttributesProperty, workflowserviceattributes1);
			this.CanModifyActivities = false;

		}

		#endregion

		private SetStateActivity setDrinkReceived;
		private CodeActivity codePayOrder;
		private SetStateActivity setOrderPlacedFromUpdate;
		private ReceiveActivity receiveOrderPaid;
		private CodeActivity codeUpdateOrder;
		private StateActivity OrderPlaced;
		private EventDrivenActivity OnOrderUpdated;
		private EventDrivenActivity OnOrderPaid;
		private ReceiveActivity receiveOrderUpdate;
		private StateActivity DrinkReceived;
		private SetStateActivity setOrderPlaced;
		private CodeActivity OnOrderPlacedCode;
		private ReceiveActivity receiveOnOrderPlaced;
		private EventDrivenActivity OnOrderPlaced;
		private StateActivity WaitingForOrder;




















































	}
}
