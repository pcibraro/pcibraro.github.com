﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.ServiceModel.Web;
using Common;
using System.ServiceModel;

namespace RestWorkflows
{
	public sealed partial class OrderWorkflow : StateMachineWorkflowActivity
	{
		public Order receivedOrder;
		public string receivedId;

		public Order currentOrder;
		public Payment orderPayment;

		public OrderWorkflow()
		{
			InitializeComponent();
		}

		private void OnOrderPlacedCode_ExecuteCode(object sender, EventArgs e)
		{
			currentOrder = new Order();
			currentOrder.OrderId = Guid.NewGuid().ToString();
			currentOrder.Cost = (receivedOrder.Drink == "latte") ? 6 : 10;
			currentOrder.Drink = receivedOrder.Drink;
			currentOrder.Next = new Next[] { 
				new Next
				{
					Rel = "http://starbucks.example.org/payment",
					Uri = "http://localhost:8000/payment/order/" + currentOrder.OrderId.ToString(),
				},
				new Next
				{
					Rel = "http://starbucks.example/order/update",
					Uri = "http://localhost:8000/order/" + currentOrder.OrderId.ToString()
				}
			};

			//Persist the order in some place.....
			WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.Created;
		}

		private void codeUpdateOrder_ExecuteCode(object sender, EventArgs e)
		{
			//Do some validations ....;
			currentOrder.OrderId = receivedId;
			currentOrder.Drink = receivedOrder.Drink;
			currentOrder.Cost = (receivedOrder.Drink == "latte") ? 6 : 10;
			currentOrder.Next = new Next[] { 
				new Next
				{
					Rel = "http://starbucks.example.org/payment",
					Uri = "http://localhost:8000/payment/order/" + currentOrder.OrderId.ToString(),
				},
				new Next
				{
					Rel = "http://starbucks.example/order/update",
					Uri = "http://localhost:8000/order/" + currentOrder.OrderId.ToString()
				}
			};

			//Update the order in the storage.....
			WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.OK;
		}

		private void codePayOrder_ExecuteCode(object sender, EventArgs e)
		{
			//Do some validations with the payment ...
			//Persist the payment with the order ...

			WebOperationContext.Current.OutgoingResponse.StatusCode = System.Net.HttpStatusCode.Created;
		}
	}
}
