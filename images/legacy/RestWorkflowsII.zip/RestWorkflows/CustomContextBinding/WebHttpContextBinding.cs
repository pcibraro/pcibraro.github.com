﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel;

namespace Microsoft.ServiceModel.Samples
{
	public class WebHttpContextBinding : WebHttpBinding
	{
		public override BindingElementCollection CreateBindingElements()
		{
			BindingElementCollection elements = base.CreateBindingElements();
			elements.Insert(0, new WebHttpContextBindingElement());

			return elements;
		}
	}
}
