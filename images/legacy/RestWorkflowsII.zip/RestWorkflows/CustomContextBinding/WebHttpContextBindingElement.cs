using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.IO;
using System.ServiceModel.Security;

namespace Microsoft.ServiceModel.Samples
{
	public class WebHttpContextBindingElement : BindingElement, IContextBindingElement
	{
		public WebHttpContextBindingElement()
		{
		}

		public WebHttpContextBindingElement(WebHttpContextBindingElement other)
		{
		}

		public override T GetProperty<T>(BindingContext context)
		{
			if (typeof(T) == typeof(IContextBindingElement))
			{
				return (T)(object)this;
			}

			return context.GetInnerProperty<T>();
		}
		
		public override bool CanBuildChannelFactory<TChannel>(
		    BindingContext context)
		{
			if (typeof(TChannel) != typeof(IRequestChannel))
			{
				return false;
			}

			return context.CanBuildInnerChannelFactory<TChannel>();
		}

		public override bool CanBuildChannelListener<TChannel>(
			BindingContext context)
		{
			if (typeof(TChannel) != typeof(IReplyChannel))
			{
				return false;
			}
			
			return context.CanBuildInnerChannelListener<TChannel>();
		}

		public override IChannelFactory<TChannel> BuildChannelFactory<TChannel>(BindingContext context)
		{
			IChannelFactory<TChannel> innerChannelFactory = context.BuildInnerChannelFactory<TChannel>();

			IChannelFactory<TChannel> channelFactory =
				new WebHttpContextChannelFactory<TChannel>(innerChannelFactory);

			return channelFactory;
		}

		public override IChannelListener<TChannel>
			BuildChannelListener<TChannel>(BindingContext context)
		{
			return new WebHttpContextChannelListener<TChannel>(context);
		}

		public override BindingElement Clone()
		{
			return new WebHttpContextBindingElement(this);
		}

	}
}
