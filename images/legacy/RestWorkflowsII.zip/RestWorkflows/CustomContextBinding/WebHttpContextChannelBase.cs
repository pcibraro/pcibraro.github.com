using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Diagnostics;

namespace Microsoft.ServiceModel.Samples
{
    //This is the abstract base class for all the channel 
    //implementations in DurableInstanceExtension. This class
    //provides the common functionality required for enabling the 
    //durable instancing protocol.
    abstract class WebHttpContextChannelBase : ChannelBase
    {
        protected IChannel innerChannel;

        // If the derived channel is a client side channel,
        // this member holds a reference to the remote endpoint.
        protected EndpointAddress endpointAddress;

        public WebHttpContextChannelBase(ChannelManagerBase channelManager, IChannel innerChannel)
            : base(channelManager)
        {
            this.innerChannel = innerChannel;
        }

       

        #region State machine

        protected override void OnOpen(TimeSpan timeout)
        {
            innerChannel.Open(timeout);
        }

        protected override void OnClose(TimeSpan timeout)
        {
            innerChannel.Close();
        }

        protected override void OnAbort()
        {
            innerChannel.Abort();
        }

        protected override IAsyncResult OnBeginClose(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.innerChannel.BeginClose(timeout, callback, state);
        }

        protected override IAsyncResult OnBeginOpen(TimeSpan timeout, AsyncCallback callback, object state)
        {
            return this.innerChannel.BeginOpen(timeout, callback, state);
        }

        protected override void OnEndClose(IAsyncResult result)
        {
            this.innerChannel.EndClose(result);
        }

        protected override void OnEndOpen(IAsyncResult result)
        {
            this.innerChannel.EndOpen(result);
        }

        #endregion

        
    }
}
