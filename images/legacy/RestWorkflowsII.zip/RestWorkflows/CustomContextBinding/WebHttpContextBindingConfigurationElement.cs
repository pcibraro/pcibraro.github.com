﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Configuration;

namespace Microsoft.ServiceModel.Samples
{
	public class WebHttpContextBindingConfigurationElement : WebHttpBindingElement
	{
		protected override Type BindingElementType
		{
			get
			{
				return typeof(WebHttpContextBinding);
			}
		}
	}
}
