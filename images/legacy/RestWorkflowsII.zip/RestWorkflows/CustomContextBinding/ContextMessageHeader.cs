using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.Xml;
using System.Net.Security;
using System.ServiceModel;

namespace Microsoft.ServiceModel.Samples
{
	internal class ContextMessageHeader : MessageHeader
	{
		private IDictionary<string, string> context;
		public const string ContextHeaderName = "Context";
		public const string ContextHeaderNamespace = "http://schemas.microsoft.com/ws/2006/05/context";
		public const string ContextPropertyElement = "Property";
		public const string ContextPropertyNameAttribute = "name";
		private static ChannelProtectionRequirements encryptAndSignChannelProtectionRequirements;
		private static ChannelProtectionRequirements signChannelProtectionRequirements;

		public ContextMessageHeader(IDictionary<string, string> context)
		{
			if (context == null)
			{
				throw new ArgumentNullException("context");
			}

			this.context = context;
		}

		public static ContextMessageProperty GetContextFromHeaderIfExists(Message message)
		{
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}

			int headerIndex = message.Headers.FindHeader("Context", "http://schemas.microsoft.com/ws/2006/05/context");
			if (headerIndex >= 0)
			{
				return ParseContextHeader(message.Headers.GetReaderAtHeader(headerIndex));
			}

			return null;
		}

		protected override void OnWriteHeaderContents(XmlDictionaryWriter writer, MessageVersion messageVersion)
		{
			if (writer == null)
			{
				throw new ArgumentNullException("writer");
			}
			foreach (KeyValuePair<string, string> pair in this.context)
			{
				writer.WriteStartElement("Property", this.Namespace);
				writer.WriteAttributeString("name", null, pair.Key);
				writer.WriteValue(pair.Value);
				writer.WriteEndElement();
			}
		}

		internal static ContextMessageProperty ParseContextHeader(XmlReader reader)
		{
			if (reader == null)
			{
				throw new ArgumentNullException("reader");
			}
			ContextMessageProperty property = new ContextMessageProperty();
			try
			{
				if (reader.IsEmptyElement)
				{
					return property;
				}
				reader.ReadStartElement("Context", "http://schemas.microsoft.com/ws/2006/05/context");
				while (reader.MoveToContent() == XmlNodeType.Element)
				{
					if ((reader.LocalName != "Property") || (reader.NamespaceURI != "http://schemas.microsoft.com/ws/2006/05/context"))
					{
						throw new ProtocolException(string.Format("XML Schema violation inside of the context header {0}", new object[0]));
					}
					string attribute = reader.GetAttribute("name");
					if (string.IsNullOrEmpty(attribute))
					{
						throw new ProtocolException(string.Format("XML Schema violation inside of the context header {0}", new object[] { attribute }));
					}
					property.Context[attribute] = reader.ReadElementString();
				}
				if (reader.NodeType != XmlNodeType.EndElement)
				{
					throw new ProtocolException(string.Format("XML Schema violation inside of the context header {0}", new object[0]));
				}
			}
			catch (XmlException exception)
			{
				throw new ProtocolException(string.Format("Xml violation format in context header {0}", new object[0]), exception);
			}
			return property;
		}

		public override string Name
		{
			get
			{
				return "Context";
			}
		}

		public override string Namespace
		{
			get
			{
				return "http://schemas.microsoft.com/ws/2006/05/context";
			}
		}
	}
}
