﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Configuration;

namespace Microsoft.ServiceModel.Samples
{
	public class WebHttpContextBindingCollectionElement : StandardBindingCollectionElement<WebHttpContextBinding, WebHttpContextBindingConfigurationElement>
	{
		public WebHttpContextBindingCollectionElement()	 : base()
		{
		}
	}
}
