﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Net;
using System.Xml;
using System.IO;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace Microsoft.ServiceModel.Samples
{
	internal class ServiceContextProtocol : ContextProtocol
	{
		public ServiceContextProtocol()
		{
		}

		public override void OnIncomingMessage(Message message)
		{
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}
			
			this.OnReceiveMessage(message);
		}

		public override void OnOutgoingMessage(Message message, System.ServiceModel.Channels.RequestContext requestContext)
		{
			ContextMessageProperty property;
			if (message == null)
			{
				throw new ArgumentNullException("message");
			}
			if (ContextMessageProperty.TryGet(message, out property))
			{
				OnSendMessage(message, property);
			}
		}

		private void OnReceiveMessage(Message message)
		{
			object value;
			if (message.Properties.TryGetValue(HttpRequestMessageProperty.Name, out value))
			{
				HttpRequestMessageProperty requestProperty = value as HttpRequestMessageProperty;
				if (requestProperty != null)
				{
					ContextMessageProperty property;
					string str = requestProperty.Headers["WscContext"];
					if (!string.IsNullOrEmpty(str) && TryCreateFromHttpHeader(str, out property))
					{
						property.AddOrReplaceInMessage(message);
					}
				}
			}
		}

		private void OnSendMessage(Message message, ContextMessageProperty context)
		{
			object value;
			HttpResponseMessageProperty httpProperty = null;
			if (message.Properties.TryGetValue(HttpResponseMessageProperty.Name, out value))
			{
				httpProperty = value as HttpResponseMessageProperty;
			}
			if (httpProperty == null)
			{
				httpProperty = new HttpResponseMessageProperty();
				message.Properties.Add(HttpResponseMessageProperty.Name, httpProperty);
			}
			string str = EncodeContextAsHttpHeader(context);
			httpProperty.Headers.Add("WscContext", str);
		}

		private bool TryCreateFromHttpHeader(string httpHeader, out ContextMessageProperty context)
		{
			if (httpHeader == null)
				throw new ArgumentNullException("httpHeader");

			try
			{
				context = ContextMessageHeader.ParseContextHeader(XmlReader.Create(new MemoryStream(Convert.FromBase64String(httpHeader))));
			}
			catch (SerializationException exception)
			{
				throw;
			}
			catch (ProtocolException exception2)
			{
				throw;
			}

			return (context != null);
		}

		private string EncodeContextAsHttpHeader(ContextMessageProperty context)
		{
			if (context == null)
			{
				throw new ArgumentNullException("context");
			}
			
			MemoryStream output = new MemoryStream();
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.OmitXmlDeclaration = true;
			XmlWriter writer = XmlWriter.Create(output, settings);
			new ContextMessageHeader(context.Context).WriteHeader(writer, MessageVersion.Default);
			writer.Flush();

			return Convert.ToBase64String(output.GetBuffer(), 0, (int)output.Length);
		}
	}
}
