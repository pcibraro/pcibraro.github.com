﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;

namespace WCF.Testing
{
	public interface IProductRepository
	{
		IQueryable<Product> GetProducts(string category);
	}

	public class InMemoryProductRepository : IProductRepository
	{
		IList<Product> products;

		public InMemoryProductRepository(IList<Product> products)
		{
			this.products = products;
		}

		public IQueryable<Product> GetProducts(string category)
		{
			return products.Where(p => p.Category == category).AsQueryable();
		}
	}
}
