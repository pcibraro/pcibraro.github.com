﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Syndication;
using System.Web.UI;
using System.ServiceModel.Web;
using System.ServiceModel;

namespace WCF.Testing
{
	[ServiceContract]
	public interface IProductCatalog
	{
		[WebGet(UriTemplate = "?category={category}")]
		[OperationContract]
		Atom10FeedFormatter GetProducts(string category);
	}
}
