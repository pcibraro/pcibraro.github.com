﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ServiceModel.Web;
using System.Threading;

namespace WCF.Testing
{
	public class MyWebContext : IDisposable
	{
		private const string TlsName = "webContext";

		public MyWebContext(IWebOperationContext context)
		{
			var tls = Thread.GetNamedDataSlot(TlsName);
			Thread.SetData(tls, context);
		}
		
		public static IWebOperationContext Current
		{
			get
			{
				var tls = Thread.GetNamedDataSlot(TlsName);
				var context = Thread.GetData(tls);

				if (context != null)
				{
					return (IWebOperationContext)context;
				}
				else
				{
					return new WebOperationContextWrapper(WebOperationContext.Current);
				}
			}
		} 

		public void Dispose()
		{
			var tls = Thread.GetNamedDataSlot(TlsName);
			Thread.SetData(tls, null);
		}
	}
}
