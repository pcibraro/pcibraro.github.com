﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Syndication;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.ServiceModel;

namespace WCF.Testing
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	[ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
	public class ProductCatalog : IProductCatalog
	{
		IProductRepository repository;

		public ProductCatalog()
		{
			repository = new InMemoryProductRepository(
				new List<Product>{ 
					new Product { Id = "1", Category = "foo", Name = "Foo1", UnitPrice = 1 },
					new Product { Id = "2", Category = "bar", Name = "bar2", UnitPrice = 2 }
				}
			);
		}

		public ProductCatalog(IProductRepository repository)
		{
			this.repository = repository;
		}
		
		public Atom10FeedFormatter GetProducts(string category)
		{
			var items = new List<SyndicationItem>();
			foreach(var product in repository.GetProducts(category))
			{
				items.Add(new SyndicationItem()
				{
					Id = String.Format(CultureInfo.InvariantCulture, "http://products/{0}", product.Id),
					Title = new TextSyndicationContent(product.Name),
					LastUpdatedTime = new DateTime(2008, 7, 1, 0, 0, 0, DateTimeKind.Utc),
					Authors = 
					{ 
						new SyndicationPerson() 
						{
							Name = "cibrax"
						}
					},
					Content = new TextSyndicationContent(string.Format("Category Id {0} - Price {1}",
						product.Category, product.UnitPrice))
				});
			}
										
			var feed = new SyndicationFeed()
			{
				Id = "http://Products",
				Title = new TextSyndicationContent("Product catalog"),
				Items = items
			};

			MyWebContext.Current.OutgoingResponse.ContentType = "application/atom+xml";
			return feed.GetAtom10Formatter();
		}
	}
}
