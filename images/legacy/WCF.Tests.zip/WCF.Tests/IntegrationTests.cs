﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ServiceModel.Web;
using WCF.Testing;
using System.ServiceModel.Syndication;
using System.Net;
using System.Xml;

namespace WCF.Tests
{
	/// <summary>
	/// </summary>
	[TestClass]
	public class IntegrationTests
	{
		public IntegrationTests()
		{
		}

		[TestMethod]
		public void ShouldGetProductsFeed()
		{
			ProductCatalog catalog = new ProductCatalog(
				new InMemoryProductRepository(
					new List<Product>{ 
					new Product { Id = "1", Category = "foo", Name = "Foo1", UnitPrice = 1 },
					new Product { Id = "2", Category = "bar", Name = "bar2", UnitPrice = 2 }
				}));

			WebServiceHost host = new WebServiceHost(catalog, new Uri("http://localhost:7777/Products"));

			IEnumerable<SyndicationItem> items;

			try
			{
				host.Open();

				items = Consume(new Uri("http://localhost:7777/Products?category=foo"));
			}
			finally
			{
				if (host.State == System.ServiceModel.CommunicationState.Opened)
					host.Close();
				else
					host.Abort();
			}


			Assert.AreEqual(1, items.Count());
			Assert.IsTrue(items.Any(i => i.Id == "http://products/1" && i.Title.Text == "Foo1"));
		}

		private IEnumerable<SyndicationItem> Consume(Uri feedUri)
		{
			WebRequest request = CreateWebRequest(feedUri);
			XmlReaderSettings settings = new XmlReaderSettings { CloseInput = true };
			using (XmlReader reader = XmlReader.Create(request.GetResponse().GetResponseStream(), settings))
			{
				SyndicationFeed feed = SyndicationFeed.Load(reader);
				return feed.Items;
			}
		}

		private WebRequest CreateWebRequest(Uri feedUri)
		{
			HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(feedUri);
			webRequest.ContentType = "application/rss+xml";
			
			webRequest.Timeout = 60 * 1000;

			webRequest.Method = "GET";

			return webRequest;
		}

	}
}
