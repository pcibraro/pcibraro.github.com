﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WCF.Testing;
using Moq;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;

namespace WCF.Tests
{
	[TestClass]
	public class UnitTests
	{
		[TestMethod]
		public void ShouldGetProductsFeed()
		{
			ProductCatalog catalog = new ProductCatalog(
				new InMemoryProductRepository(
					new List<Product>{ 
					new Product { Id = "1", Category = "foo", Name = "Foo1", UnitPrice = 1 },
					new Product { Id = "2", Category = "bar", Name = "bar2", UnitPrice = 2 }
				}));

			Mock<IWebOperationContext> mockContext = new Mock<IWebOperationContext> { DefaultValue = DefaultValue.Mock };
			IEnumerable<SyndicationItem> items;
			using (new MyWebContext(mockContext.Object))
			{
				var formatter = catalog.GetProducts("foo");
				items = formatter.Feed.Items;
			}

			mockContext.VerifySet(c => c.OutgoingResponse.ContentType, "application/atom+xml");
			
			Assert.AreEqual(1, items.Count());
			Assert.IsTrue(items.Any(i => i.Id == "http://products/1" && i.Title.Text == "Foo1"));
		}
	}
}
