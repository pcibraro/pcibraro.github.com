﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;

[ServiceContract]
public interface IService
{
	[OperationContract]
	[WebGet(UriTemplate="User")]
	Atom10FeedFormatter EchoUser();
}
