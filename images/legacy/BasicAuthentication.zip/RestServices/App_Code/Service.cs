﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;
using System.Threading;

public class Service : IService
{
	public Atom10FeedFormatter EchoUser()
	{
		var feed = new SyndicationFeed()
		{
			Id = "http://Claims",
			Title = new TextSyndicationContent("My claims"),
		};

		feed.Items = new List<SyndicationItem> {
			new SyndicationItem()
			{
				Id = Guid.NewGuid().ToString(),
				Title = new TextSyndicationContent(Thread.CurrentPrincipal.Identity.Name),
				LastUpdatedTime = DateTime.UtcNow,
				Authors = 
				{ 
					new SyndicationPerson() 
					{
						Name = "service"
					}
				},
				Content = new TextSyndicationContent(Thread.CurrentPrincipal.Identity.Name)
			}
		};

		WebOperationContext.Current.OutgoingResponse.ContentType = "application/atom+xml";
		return feed.GetAtom10Formatter();
	}
}
