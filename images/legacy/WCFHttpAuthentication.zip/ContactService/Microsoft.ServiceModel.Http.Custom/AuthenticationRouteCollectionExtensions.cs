﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Routing;
using Microsoft.ServiceModel.Http;
using Microsoft.ServiceModel.Http.Interception;
using System.Collections.ObjectModel;
using System.ServiceModel.Activation;
using Microsoft.ServiceModel.Http.Authentication;

namespace Microsoft.ServiceModel.Http.Authentication
{
    public static class AuthenticationRouteCollectionExtensions
    {
        public static void AddServiceRoute<TService>(this RouteCollection routes, string routePrefix, HttpHostConfiguration configuration = null, IAuthenticationInterceptor defaultInterceptor = null, params IAuthenticationInterceptor[] interceptors)
        {
            AddServiceRoute<TService, CustomWebHttpServiceHostFactory>(routes, routePrefix, configuration, defaultInterceptor, interceptors);
        }

        public static void AddServiceRoute<TService, TServiceHostFactory>(this RouteCollection routes, string routePrefix, HttpHostConfiguration configuration = null, IAuthenticationInterceptor defaultInterceptor = null, params IAuthenticationInterceptor[] interceptors) where TServiceHostFactory : ServiceHostFactoryBase, IConfigurableServiceHostFactory, IInterceptorsProvider, new()
        {
            if (routes == null)
            {
                throw new ArgumentNullException("routes");
            }

            var requestInterceptors = new Collection<RequestInterceptor>();
            var authenticationInterceptor = new AuthenticationInterceptor(defaultInterceptor, interceptors);

            requestInterceptors.Add(authenticationInterceptor);

            var route = new ServiceRoute(routePrefix, new TServiceHostFactory() { Configuration = configuration, Interceptors = requestInterceptors }, typeof(TService));
            routes.Add(route);
        }
        
    }
}
