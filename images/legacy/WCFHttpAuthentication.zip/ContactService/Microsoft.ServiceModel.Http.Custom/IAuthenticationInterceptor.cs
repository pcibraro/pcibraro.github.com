﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Security.Principal;

namespace Microsoft.ServiceModel.Http.Authentication
{
    public interface IAuthenticationInterceptor
    {
        string Scheme { get; }
        bool DoAuthentication(HttpRequestMessage request, HttpResponseMessage response, out IPrincipal principal);
    }
}
