﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Claims;
using System.IdentityModel.Policy;
using System.IdentityModel.Tokens;
using System.IO;
using System.Net;
using System.Security.Principal;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.Xml;
using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.ServiceModel.Http.Authentication;
using System.Net.Http;
using System.Reflection;
using Microsoft.ServiceModel.Http.Interception;

namespace Microsoft.ServiceModel.Http.Authentication
{
    public class SamlAuthenticationInterceptor : IAuthenticationInterceptor
    {
        SecurityTokenHandlerCollection handlers = null;

        public SamlAuthenticationInterceptor(SecurityTokenHandlerCollection handlers)
        {
            if (handlers == null)
                throw new ArgumentNullException("handlers");

            this.handlers = handlers;
        }

        public string Scheme
        {
            get { return "saml"; }
        }

        public bool DoAuthentication(HttpRequestMessage request, HttpResponseMessage response, out IPrincipal principal)
        {
            SecurityToken token = ExtractCredentials(request);

            if (token != null)
            {
                ClaimsIdentityCollection claims = handlers.ValidateToken(token);

                principal = new ClaimsPrincipal(claims);

                return true;
            }
            else
            {
                response.StatusCode = HttpStatusCode.Unauthorized;
                response.Content = new StringContent("Access denied");

                principal = null;

                return false;
            }
        }

        private SecurityToken ExtractCredentials(HttpRequestMessage request)
        {
            if (request.Headers.Authorization != null && request.Headers.Authorization.Scheme == "saml")
            {
                XmlTextReader xmlReader = new XmlTextReader(new StringReader(request.Headers.Authorization.Parameter));

                var col = SecurityTokenHandlerCollection.CreateDefaultSecurityTokenHandlerCollection();
                SecurityToken token = col.ReadToken(xmlReader);

                return token;
            }

            return null;
        }
    }

   
}

