﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.ServiceModel.Http.Interception;
using System.Net.Http;
using System.ServiceModel.Channels;
using System.Security.Principal;
using System.IdentityModel.Policy;
using System.ServiceModel;
using System.ServiceModel.Security;
using System.IdentityModel.Claims;

namespace Microsoft.ServiceModel.Http.Authentication
{
    public class AuthenticationInterceptor : RequestInterceptor
    {
        IList<IAuthenticationInterceptor> interceptors;

        public AuthenticationInterceptor(IAuthenticationInterceptor defaultInterceptor, params IAuthenticationInterceptor[] interceptors)
            : base(false)
        {
            if (defaultInterceptor == null)
                throw new ArgumentNullException("defaultInterceptor");

            this.interceptors = interceptors.ToList();
            this.interceptors.Insert(0, defaultInterceptor);
        }

        public override void ProcessRequest(ref RequestContext requestContext)
        {
            var requestMessage = requestContext.RequestMessage;
            
            var request = requestMessage.ToHttpRequestMessage();
            var response = new HttpResponseMessage();

            IPrincipal principal;

            if (request.Headers.Authorization == null)
            {
                this.interceptors[0].DoAuthentication(request, response, out principal);

                var reply = response.ToMessage();
                requestContext.Reply(reply);
                requestContext = null;

                return;
            }

            var scheme = request.Headers.Authorization.Scheme;

            var interceptor = interceptors.FirstOrDefault(i => i.Scheme.Equals(scheme, StringComparison.OrdinalIgnoreCase));
            if (interceptor == null)
            {
                DenyAccess(response, ref requestContext);

                return;
            }

            if (interceptor.DoAuthentication(request, response, out principal))
            {
                InitializeSecurityContext(requestMessage, principal);
            }
            else
            {
                DenyAccess(response, ref requestContext);
            }
        }

        private void DenyAccess(HttpResponseMessage response, ref RequestContext requestContext)
        {
            response.StatusCode = System.Net.HttpStatusCode.Unauthorized;
            response.Content = new StringContent("Access denied");

            var reply = response.ToMessage();
            requestContext.Reply(reply);
            requestContext = null;
        }

        private void InitializeSecurityContext(Message request, IPrincipal principal)
        {
            List<IAuthorizationPolicy> policies = new List<IAuthorizationPolicy>();
            policies.Add(new PrincipalAuthorizationPolicy(principal));
            ServiceSecurityContext securityContext = new ServiceSecurityContext(policies.AsReadOnly());

            if (request.Properties.Security != null)
            {
                request.Properties.Security.ServiceSecurityContext = securityContext;
            }
            else
            {
                request.Properties.Security = new SecurityMessageProperty() { ServiceSecurityContext = securityContext };
            }
        }

        class PrincipalAuthorizationPolicy : IAuthorizationPolicy
        {
            string id = Guid.NewGuid().ToString();
            IPrincipal user;

            public PrincipalAuthorizationPolicy(IPrincipal user)
            {
                this.user = user;
            }

            public ClaimSet Issuer
            {
                get { return ClaimSet.System; }
            }

            public string Id
            {
                get { return this.id; }
            }

            public bool Evaluate(EvaluationContext evaluationContext, ref object state)
            {
                evaluationContext.AddClaimSet(this, new DefaultClaimSet(Claim.CreateNameClaim(user.Identity.Name)));
                evaluationContext.Properties["Identities"] = new List<IIdentity>(new IIdentity[] { user.Identity });
                evaluationContext.Properties["Principal"] = user;
                return true;
            }
        }
    }
}
