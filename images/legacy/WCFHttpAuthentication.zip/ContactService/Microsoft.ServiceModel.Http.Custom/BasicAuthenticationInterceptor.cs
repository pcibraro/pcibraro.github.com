﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Claims;
using System.IdentityModel.Policy;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.Text;
using Microsoft.ServiceModel.Http.Interception;

namespace Microsoft.ServiceModel.Http.Authentication
{
    public class UsernameAndPassword
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class BasicAuthenticationInterceptor : IAuthenticationInterceptor
    {
        Func<UsernameAndPassword, bool> userValidation;
        string realm;

        public BasicAuthenticationInterceptor(Func<UsernameAndPassword, bool> userValidation, string realm)
        {
            if (userValidation == null)
                throw new ArgumentNullException("userValidation");

            if (string.IsNullOrEmpty(realm))
                throw new ArgumentNullException("realm");

            this.userValidation = userValidation;
            this.realm = realm;
        }

        public string Scheme
        {
            get { return "Basic"; }
        }

        public bool DoAuthentication(HttpRequestMessage request, HttpResponseMessage response, out IPrincipal principal)
        {
            string[] credentials = ExtractCredentials(request);
            if (credentials.Length == 0 || !AuthenticateUser(credentials[0], credentials[1]))
            {
                response.StatusCode = HttpStatusCode.Unauthorized;
                response.Content = new StringContent("Access denied");
                response.Headers.WwwAuthenticate.Add(new AuthenticationHeaderValue("Basic", "realm=" + this.realm));

                principal = null;

                return false;
            }
            else
            {
                principal = new GenericPrincipal(new GenericIdentity(credentials[0]), new string[] {});

                return true;
            }
        }

        private string[] ExtractCredentials(HttpRequestMessage request)
        {
            if (request.Headers.Authorization != null && request.Headers.Authorization.Scheme.StartsWith("Basic"))
            {
                string encodedUserPass = request.Headers.Authorization.Parameter.Trim();

                Encoding encoding = Encoding.GetEncoding("iso-8859-1");
                string userPass = encoding.GetString(Convert.FromBase64String(encodedUserPass));
                int separator = userPass.IndexOf(':');

                string[] credentials = new string[2];
                credentials[0] = userPass.Substring(0, separator);
                credentials[1] = userPass.Substring(separator + 1);

                return credentials;
            }

            return new string[] { };
        }

        private bool AuthenticateUser(string username, string password)
        {
            var usernameAndPassword = new UsernameAndPassword
            {
                Username = username,
                Password = password
            };

            if (this.userValidation(usernameAndPassword))
            {
                return true;
            }

            return false;
        }
    }
}

