﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Xml.Linq;
using System.Net;
using Microsoft.IdentityModel.Protocols.WSTrust;
using Microsoft.IdentityModel.SecurityTokenService;
using System.Security.Cryptography.X509Certificates;
using System.IdentityModel.Tokens;
using Microsoft.IdentityModel.Configuration;
using System.Xml;
using Microsoft.IdentityModel.Tokens;
using Microsoft.IdentityModel.Claims;
using System.Threading;
using Microsoft.IdentityModel.Protocols.WSIdentity;

namespace STS
{
	[ServiceContract]
	public class HttpSecurityTokenService
	{
		[OperationContract]
		[WebGet(UriTemplate = "/?applies_to={appliesTo}")]
		public XElement Issue(string appliesTo)
		{
			EndpointAddress epRealm;
			try
			{
				epRealm = new EndpointAddress(appliesTo);
			}
			catch
			{
				WebOperationContext.Current.OutgoingResponse.StatusCode =
				  HttpStatusCode.BadRequest;
				return null;
			}

			RequestSecurityToken rst = new RequestSecurityToken
			{
				AppliesTo = epRealm,
				KeyType = KeyTypes.Bearer
			};

			var sts = CreateSTS();
			var rstr = sts.Issue(CreatePrincipal(), rst);

			StringBuilder sb = new StringBuilder();
			var writer = XmlWriter.Create(sb);

			var col = SecurityTokenHandlerCollection.CreateDefaultSecurityTokenHandlerCollection();
			SecurityToken token = rstr.RequestedSecurityToken.SecurityToken;
			if (token is EncryptedSecurityToken)
				token = ((EncryptedSecurityToken)token).Token;

			col.WriteToken(writer, token);
			writer.Flush();

			WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml";
			return XElement.Parse(sb.ToString());
		}

		private SecurityTokenService CreateSTS()
		{
			X509Certificate2 stsCertificate = CertificateUtil.GetCertificate(
				StoreName.TrustedPeople,
				StoreLocation.LocalMachine,
				"CN=WCFSTS");

			// Create and setup the configuration for our STS
			SigningCredentials signingCreds = new X509SigningCredentials(stsCertificate);
			SecurityTokenServiceConfiguration config =
				new SecurityTokenServiceConfiguration("http://STS", signingCreds);

			return new MySecurityTokenService(config);
		}

		private IClaimsPrincipal CreatePrincipal()
		{
			if (Thread.CurrentPrincipal == null ||
				Thread.CurrentPrincipal.Identity == null ||
				string.IsNullOrEmpty(Thread.CurrentPrincipal.Identity.Name))
			{
				throw new InvalidRequestException("unknown client");
			}

			var identity = new ClaimsIdentity(
				new List<Claim> { new Claim(WSIdentityConstants.ClaimTypes.Name,
                          Thread.CurrentPrincipal.Identity.Name) });

			return new ClaimsPrincipal(new List<IClaimsIdentity> { identity });
		}
	}
}
