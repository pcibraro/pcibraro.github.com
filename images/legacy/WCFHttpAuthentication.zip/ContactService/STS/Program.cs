using System;
using System.IdentityModel.Tokens;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;

using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Protocols.WSTrust;
using Microsoft.IdentityModel.SecurityTokenService;
using Microsoft.IdentityModel.Tokens;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.Collections.ObjectModel;
using Microsoft.ServiceModel.Web;
using System.ServiceModel.Description;

namespace STS
{
    class Program
    {
        static void Main( string[] args )
        {
            // Create the WS-Trust service host with our STS configuration
			using (WebServiceHost host = new WebServiceHost(typeof(HttpSecurityTokenService), new Uri("http://localhost:6000")))
            {
				host.Open();
				foreach (var endpoint in host.Description.Endpoints)
				{
					Console.WriteLine("Listening at " + endpoint.Address.Uri.AbsoluteUri);
				}

				Console.WriteLine("Press a key to quit");
                Console.ReadLine();
                host.Close();
            }
        }

    }
}
