using System;
using System.ServiceModel;

using Microsoft.IdentityModel.Claims;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Protocols.WSTrust;
using Microsoft.IdentityModel.SecurityTokenService;
using System.Security.Cryptography.X509Certificates;

namespace STS
{
	[ServiceBehavior(Namespace="http://schemas.microsoft.com/ws/2008/06/identity/securitytokenservice")]
    public class MySecurityTokenService : SecurityTokenService
    {
        /// <summary>
        /// Creates an instance of the MySecurityTokenService class.
        /// </summary>
        /// <param name="configuration">SecurityTokenServiceConfiguration element.</param>
        public MySecurityTokenService( SecurityTokenServiceConfiguration configuration )
            : base( configuration )
        {
        }

        /// <summary>
        /// This methods returns the configuration for the token issuance request. The configuration
        /// is represented by the Scope class. In our case, we are only capable to issue a token for a
        /// single RP identity represented by CN=WCFServer.
        /// </summary>
        /// <param name="principal">The caller's principal</param>
        /// <param name="request">The incoming RST</param>
        /// <returns>The configuration for the token issuance request.</returns>
        protected override Scope GetScope( IClaimsPrincipal principal, RequestSecurityToken request )
        {
            if (request.AppliesTo == null)
            {
                throw new InvalidRequestException("The appliesTo is null.");
            }

            X509Certificate2 serviceCertificate = CertificateUtil.GetCertificate(
                StoreName.TrustedPeople,
                StoreLocation.LocalMachine,
                "CN=WCFServer");

            X509EncryptingCredentials encryptingCredentials = 
                new X509EncryptingCredentials(serviceCertificate);
            
            Scope scope = new Scope(request.AppliesTo.Uri.AbsoluteUri, 
                SecurityTokenServiceConfiguration.SigningCredentials, 
                encryptingCredentials );

			scope.TokenEncryptionRequired = false;
			scope.SymmetricKeyEncryptionRequired = true;

			return scope;
        }

        /// <summary>
        /// This methods returns the claims to be included in the issued token. 
        /// </summary>
        /// <param name="scope">The scope that was previously returned by GetScope method</param>
        /// <param name="principal">The caller's principal</param>
        /// <param name="request">The incoming RST</param>
        /// <returns>The claims to be included in the issued token.</returns>
        protected override IClaimsIdentity GetOutputClaimsIdentity(IClaimsPrincipal principal, RequestSecurityToken request, Scope scope)
        {
            IClaimsIdentity callerIdentity = (IClaimsIdentity)principal.Identity;

            IClaimsIdentity outputIdentity = new ClaimsIdentity();

            Claim nameClaim = new Claim( System.IdentityModel.Claims.ClaimTypes.Name, callerIdentity.Name );

            Claim ageClaim = new Claim( "http://SOAwareSamples/2008/05/AgeClaim", "25", ClaimValueTypes.Integer );

            outputIdentity.Claims.Add( nameClaim );
            outputIdentity.Claims.Add( ageClaim );

            return outputIdentity;
        }


    }
}
