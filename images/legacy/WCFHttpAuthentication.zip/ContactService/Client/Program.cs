﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Net.Http;
using System.Net;
using System.IO;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            AuthenticationChannel channel = new AuthenticationChannel(
                new HttpClientChannel(),
                new Uri("http://localhost:6000"),
                "http://localhost:8000/ContactManager/",
                new NetworkCredential("cibrax-studio\\cibrax", "jacocibra"),
                false);

            HttpClient client = new HttpClient("http://localhost:8000/ContactManager/");
            client.Channel = channel;

            var response = client.Get("contacts");

            var contacts = response.Content.ReadAsString();

            Console.WriteLine(contacts);
        }

        


    }
}
