﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;
using System.Net;
using System.IO;
using System.Net.Http.Headers;

namespace Client
{
    public class AuthenticationChannel : MessageProcessingChannel
    {
        private Uri address;
        private string appliesTo;
        private ICredentials credentials;
        private bool reuseToken;
        private string cachedToken;

        public AuthenticationChannel(HttpMessageChannel innerChannel, Uri address, string appliesTo, ICredentials credentials, bool reuseToken)
            : base(innerChannel)
        {
            this.address = address;
            this.appliesTo = appliesTo;
            this.credentials = credentials;
            this.reuseToken = reuseToken;
        }

        protected override HttpRequestMessage ProcessRequest(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
        {
            string token = null;

            if (reuseToken && this.cachedToken != null)
            {
                token = this.cachedToken;
            }
            else
            {
                var completeAddress = new Uri(this.address + "/?applies_to=" + this.appliesTo);

                token = InvokeSecurityTokenService(completeAddress, this.credentials);

                if (reuseToken)
                {
                    this.cachedToken = token;
                }
            }

            request.Headers.Authorization = new AuthenticationHeaderValue("saml", token);

            return request;
        }

        protected override HttpResponseMessage ProcessResponse(HttpResponseMessage response, System.Threading.CancellationToken cancellationToken)
        {
            return response;
        }

        static string InvokeSecurityTokenService(Uri address, ICredentials credentials)
        {
            string newToken = null;

            WebRequest webRequest = HttpWebRequest.Create(address);
            webRequest.Method = "GET";
            webRequest.Credentials = credentials;

            WebResponse webResponse = null;
            try
            {
                webResponse = webRequest.GetResponse();
                using (var st = webResponse.GetResponseStream())
                {
                    StreamReader sr = new StreamReader(st);
                    newToken = sr.ReadToEnd();
                }
            }
            finally
            {
                webResponse.Close();
            }

            return newToken;
        }
    }
}
