﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens;

namespace ContactManager
{
    public class CustomIssuerNameRegistry : IssuerNameRegistry
    {
        public CustomIssuerNameRegistry()
            : base()
        {
        }

        public override string GetIssuerName(System.IdentityModel.Tokens.SecurityToken securityToken)
        {
            X509SecurityToken token = securityToken as X509SecurityToken;
            if (token == null)
            {
                throw new SecurityTokenException("Token is not a X509 Security Token");
            }

            if (token.Certificate.SubjectName.Name != "CN=WCFSTS")
            {
                throw new SecurityTokenException("STS not supported");
            }


            return "WCFSTS";
        }
    }
}
