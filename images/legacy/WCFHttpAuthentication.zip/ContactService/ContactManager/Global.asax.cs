﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Routing;
using System.ComponentModel.Composition.Hosting;
using Microsoft.ServiceModel.Http.Authentication;
using Microsoft.IdentityModel.Configuration;
using System.Collections.ObjectModel;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Selectors;

namespace ContactManager
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            var serviceConfiguration = new ServiceConfiguration();
            serviceConfiguration.CertificateValidationMode = System.ServiceModel.Security.X509CertificateValidationMode.None;
            serviceConfiguration.RevocationMode = System.Security.Cryptography.X509Certificates.X509RevocationMode.NoCheck;
            serviceConfiguration.AudienceRestriction = new AudienceRestriction(AudienceUriMode.Never);
            serviceConfiguration.IssuerNameRegistry = new CustomIssuerNameRegistry();

            var basicAuthentication = new BasicAuthenticationInterceptor((u) => true, "ContactManager");
            var samlAuthentication = new SamlAuthenticationInterceptor(serviceConfiguration.SecurityTokenHandlers);

            // use MEF for providing instances
            var catalog = new AssemblyCatalog(typeof(Global).Assembly);
            var container = new CompositionContainer(catalog);
            var configuration = new ContactManagerConfiguration(container);

            RouteTable.Routes.AddServiceRoute<ContactResource>("contact", configuration, basicAuthentication, samlAuthentication);
            RouteTable.Routes.AddServiceRoute<ContactsResource>("contacts", configuration, basicAuthentication, samlAuthentication);
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}