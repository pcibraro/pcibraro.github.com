﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using Microsoft.IdentityModel.Tokens;
using Microsoft.IdentityModel.Configuration;
using Microsoft.IdentityModel.Protocols.WSTrust;
using System.Data.Services;
using Microsoft.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.Collections.ObjectModel;
using System.ServiceModel.Description;

namespace Service
{
    class Program
    {
        static void Main(string[] args)
        {
			DataServiceHost host = new DataServiceHost(typeof(Contacts), 
                new Uri[] { new Uri("http://localhost:8000/") });
            try
            {
				ServiceConfiguration configuration = new ServiceConfiguration();
                configuration.CertificateValidationMode = System.ServiceModel.Security.X509CertificateValidationMode.None;
                configuration.RevocationMode = System.Security.Cryptography.X509Certificates.X509RevocationMode.NoCheck;

				CustomBinding bindingWithInterceptors = CreateBindingWithInterceptor(configuration);

				host.Description.Endpoints.Add(
					new ServiceEndpoint(
						ContractDescription.GetContract(typeof(IRequestHandler)),
						bindingWithInterceptors,
						new EndpointAddress("http://localhost:8000/")));

				host.Description.Endpoints[0].Behaviors.Add(new WebHttpBehavior());

                host.Open();

				foreach (var endpoint in host.Description.Endpoints)
				{
					Console.WriteLine("Listening at " + endpoint.Address.Uri.AbsoluteUri);
				}
				               
                Console.WriteLine("Press a key to quit");
                Console.ReadKey();
            }
            finally
            {
                host.Close();
            }
        }

		private static CustomBinding CreateBindingWithInterceptor(ServiceConfiguration configuration)
		{
			WebHttpBinding binding = new WebHttpBinding();
			CustomBinding customBinding = new CustomBinding(binding.CreateBindingElements());

			Collection<RequestInterceptor> interceptors = new Collection<RequestInterceptor>();
			interceptors.Add(new SamlAuthenticationInterceptor(configuration.SecurityTokenHandlers));

			customBinding.Elements.Insert(0,
			    new RequestInterceptorBindingElement(interceptors));

			return customBinding;
		}
    }
}
