﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Microsoft.ServiceModel.Http.Interception
{
    public class CustomWebHttpServiceHost : WebHttpServiceHost
    {
        public CustomWebHttpServiceHost(object singletonInstance, Collection<RequestInterceptor> interceptors, params Uri[] baseAddresses) 
            : base(singletonInstance, baseAddresses)
        {
            this.Interceptors = interceptors;
        }

        public CustomWebHttpServiceHost(Type serviceType, Collection<RequestInterceptor> interceptors, params Uri[] baseAddresses)
            : base(serviceType, baseAddresses)
        {
            this.Interceptors = interceptors;
        }

        public CustomWebHttpServiceHost(object singletonInstance, HttpHostConfiguration configuration, Collection<RequestInterceptor> interceptors, params Uri[] baseAddresses)
            : base(singletonInstance, configuration, baseAddresses)
        {
            this.Interceptors = interceptors;
        }

        public CustomWebHttpServiceHost(Type serviceType, HttpHostConfiguration configuration, Collection<RequestInterceptor> interceptors, params Uri[] baseAddresses)
            : base(serviceType, configuration, baseAddresses)
        {
            this.Interceptors = interceptors;
        }

        public Collection<RequestInterceptor> Interceptors { get; private set; }

        protected override void OnOpening()
        {
            base.OnOpening();

            foreach (var ep in this.Description.Endpoints)
            {
                CustomBinding customBinding = new CustomBinding(ep.Binding);

                if (this.Interceptors.Count > 0)
                {
                    customBinding.Elements.Insert(0, new RequestInterceptorBindingElement(this.Interceptors));
                }

                ep.Binding = customBinding;
            }

            ServiceAuthorizationBehavior authz = this.Description.Behaviors.Find<ServiceAuthorizationBehavior>();
            authz.PrincipalPermissionMode = PrincipalPermissionMode.Custom;
        }
    }
}
