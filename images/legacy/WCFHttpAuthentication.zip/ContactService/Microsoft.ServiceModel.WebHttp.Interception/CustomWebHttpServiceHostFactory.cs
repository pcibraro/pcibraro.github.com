﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Routing;
using System.ServiceModel.Activation;
using System.Collections.ObjectModel;

namespace Microsoft.ServiceModel.Http.Interception
{
    public interface IInterceptorsProvider
    {
        Collection<RequestInterceptor> Interceptors { get; set; }
    }

    public class CustomWebHttpServiceHostFactory : WebHttpServiceHostFactory, IInterceptorsProvider
    {
        Collection<RequestInterceptor> interceptors;

        public CustomWebHttpServiceHostFactory()
            : base()
        {
            this.interceptors = new Collection<RequestInterceptor>();
        }

        protected override System.ServiceModel.ServiceHost CreateServiceHost(Type serviceType, Uri[] baseAddresses)
        {
            return new CustomWebHttpServiceHost(serviceType, this.Configuration, this.Interceptors, baseAddresses);
        }

        public Collection<RequestInterceptor> Interceptors
        {
            get { return interceptors; }
            set { this.interceptors = value; }
        }
    }

    public static class InterceptionRouteCollectionExtensions
    {
        public static void AddServiceRoute<TService>(this RouteCollection routes, string routePrefix, HttpHostConfiguration configuration = null, Collection<RequestInterceptor> interceptors = null)
        {
            AddServiceRoute<TService, CustomWebHttpServiceHostFactory>(routes, routePrefix, configuration, interceptors);
        }

        public static void AddServiceRoute<TService, TServiceHostFactory>(this RouteCollection routes, string routePrefix, HttpHostConfiguration configuration = null, Collection<RequestInterceptor> interceptors = null) where TServiceHostFactory : ServiceHostFactoryBase, IConfigurableServiceHostFactory, IInterceptorsProvider, new()
        {
            if (routes == null)
            {
                throw new ArgumentNullException("routes");
            }

            if(interceptors == null)
                interceptors = new Collection<RequestInterceptor>();

            var route = new ServiceRoute(routePrefix, new TServiceHostFactory() { Configuration = configuration, Interceptors = interceptors }, typeof(TService));
            routes.Add(route);
        }
        
    }
}
